' Double-click = start P4NG Launcher with no console window
Set sh = CreateObject("WScript.Shell")
dir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = dir
On Error Resume Next
sh.Run "pythonw """ & dir & "\main.py""", 0, False
If Err.Number <> 0 Then
  Err.Clear
  sh.Run "pyw """ & dir & "\main.py""", 0, False
  If Err.Number <> 0 Then MsgBox "pythonw not found. Install Python and tick Add to PATH.", 16, "P4NG Launcher"
End If
