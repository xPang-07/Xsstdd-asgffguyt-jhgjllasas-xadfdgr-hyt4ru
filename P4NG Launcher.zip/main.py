import subprocess, sys, time, os, atexit, json, threading
import ctypes
from pathlib import Path

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(2)
except Exception:
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

import webview
from core.config import RES, DEFAULTS, DATA
from core.app import App
from core.vault import AUTO_PW
from core import updater

# รันด้วย pythonw (ไม่มีหน้าต่าง cmd) → stdout/stderr เป็น None · เก็บ log ลงไฟล์แทน (data/launcher.log)
if sys.stdout is None or sys.stderr is None:
    try:
        DATA.mkdir(parents=True, exist_ok=True)
        _lp = DATA / "launcher.log"
        _lf = open(_lp, "w" if _lp.exists() and _lp.stat().st_size > 1_000_000 else "a",
                   encoding="utf-8", buffering=1)
        if sys.stdout is None: sys.stdout = _lf
        if sys.stderr is None: sys.stderr = _lf
    except Exception:
        pass

_NOWIN = 0x08000000 if os.name == "nt" else 0     # CREATE_NO_WINDOW — subprocess ไม่เด้งหน้าต่างดำ

SELF = ([sys.executable] if (getattr(sys, "frozen", False) or "__compiled__" in globals())
        else [sys.executable, str(Path(sys.argv[0]).resolve())])


def _cleanup_queue():
    try:
        p = DATA / "jobs.json"
        if p.exists():
            p.unlink()
    except Exception:
        pass


def _patch_pywebview_move():
    try:
        from webview.platforms import winforms as _wf
        from ctypes import windll
    except Exception as e:
        print(f"[patch] ข้าม patch: {e}", flush=True)
        return

    targets = []
    _bv = getattr(_wf, "BrowserView", None)
    for owner in (getattr(_bv, "BrowserForm", None),
                  getattr(_wf, "BrowserForm", None),
                  getattr(_wf, "Window", None)):
        if owner is not None and hasattr(owner, "move") and owner not in targets:
            targets.append(owner)
    if not targets:
        print("[patch] ไม่พบคลาสที่มี move() — ข้าม", flush=True)
        return

    SWP_NOSIZE     = 0x0001
    SWP_NOZORDER   = 0x0004
    SWP_SHOWWINDOW = 0x0040

    def _move(self, x, y):
        windll.user32.SetWindowPos(
            self.Handle.ToInt32(),
            0,
            int(x), int(y),
            0, 0,
            SWP_NOSIZE | SWP_NOZORDER | SWP_SHOWWINDOW,
        )

    for T in targets:
        T.move = _move
    print(f"[patch] pywebview move() — ใช้ 0 แทน None สำเร็จ ({', '.join(t.__name__ for t in targets)})", flush=True)


MAIN_TITLE = "P4NG Launcher"


def _set_app_icon():
    """ตั้งไอคอนของหน้าต่างหลัก (แถบงาน / Alt-Tab) จาก ui/img/logo.ico — หน้าต่าง frameless ไม่ได้ไอคอนจากไหนเอง"""
    try:
        u = ctypes.windll.user32
        hwnd = u.FindWindowW(None, MAIN_TITLE)
        if not hwnd:
            return
        ico = str(RES / "ui" / "img" / "logo.ico")
        for kind, metric in ((0, 49), (1, 11)):            # ICON_SMALL/SM_CXSMICON · ICON_BIG/SM_CXICON
            px = u.GetSystemMetrics(metric)
            h = u.LoadImageW(None, ico, 1, px, px, 0x10)   # IMAGE_ICON, LR_LOADFROMFILE
            if h:
                u.SendMessageW(hwnd, 0x80, kind, h)        # WM_SETICON
    except Exception:
        pass

atexit.register(_cleanup_queue)


class Api:
    def __init__(s):
        s._app = App()
        atexit.register(s._app.flush_pending)
        s._q = None
        s._cred = (None, None)

    # ── core ──────────────────────────────────────────────────
    def status(s):
        return {"exists": s._app.vault.path.exists()}

    def unlock(s, pw):
        v = s._app.vault
        if not v.unlock(AUTO_PW):
            s._app.log("WARN", "vault", "เปิด vault.enc ไม่ได้ (ไฟล์เสียหรือคีย์ไม่ตรง)")
            return False
        s._app.purge_creds()
        s._app.audit_vault()
        _cleanup_queue()
        s._app.check_health()
        return True

    def reset_vault(s):
        v = s._app.vault
        try:
            if v.path.exists():
                bak = v.path.with_name(f"vault.enc.bak-{int(time.time())}")
                v.path.replace(bak)
                s._app.log("WARN", "vault", f"สำรอง vault เดิมไว้ที่ {bak.name}")
            v.key = None
            v.data = {}
            v.unlock(AUTO_PW)
            s._app.purge_creds()
            s._app.audit_vault()
            return True
        except Exception as e:
            s._app.log("ERROR", "vault", f"reset ไม่สำเร็จ: {e}")
            return False

    def lock(s):
        _cleanup_queue()
        return s._app.lock_vault()

    def state(s, since=0, cfg_crc=0, acc_sig=0):
        return s._app.state(since, cfg_crc, acc_sig)

    def save_settings(s, d):
        s._app.cfg.data.update({k: v for k, v in d.items() if k in DEFAULTS})
        s._app.cfg.save()
        return True

    # ── อัปเดตแอป (GitHub Releases) ───────────────────────────
    def app_version(s):
        return updater.info()

    def update_check(s):
        return updater.check()

    def update_install(s, force=False):
        """โหลด → ตรวจ → เขียนทับ → รีสตาร์ต · ถ้ามีบัญชีกำลังรันและยังไม่ force จะไม่ทำ (คืน busy=จำนวน)"""
        busy = [a for a in s._app.accts.values()
                if a.active and a.state in ("LAUNCHING", "LOADING", "IN_GAME", "RECONNECTING")]
        if busy and not force:
            return {"ok": False, "busy": len(busy)}
        r = updater.download()
        if not r.get("ok"):
            s._app.log("WARN", "update", f"อัปเดตไม่สำเร็จ: {r.get('error')}")
            return r
        try:
            updater.apply(r["staging"])
        except Exception as e:
            s._app.log("ERROR", "update", f"เปิดตัวอัปเดตไม่ได้: {e}")
            return {"ok": False, "error": f"เปิดตัวอัปเดตไม่ได้: {e}"}
        s._app.log("INFO", "update", "โหลดอัปเดตเสร็จ — กำลังปิดแอปเพื่อเขียนไฟล์ทับแล้วเปิดใหม่")
        threading.Timer(1.0, s._quit_for_update).start()
        return {"ok": True}

    def _quit_for_update(s):
        try:
            s._app.flush_pending()
        except Exception:
            pass
        for w in list(webview.windows):
            try:
                w.destroy()
            except Exception:
                pass
        threading.Timer(8.0, lambda: os._exit(0)).start()      # กันค้าง: ตัวช่วยรอสูงสุด 60 วิ

    # ── accounts ──────────────────────────────────────────────
    def set_account(s, id, patch):
        a = s._app.accts.get(id)
        if a:
            if "password" in patch:
                pw = patch.pop("password")
                if pw is not None:
                    try:
                        s._app.set_password(id, str(pw))
                    except Exception as e:
                        return {"ok": False, "error": str(e)}
            for k, v in patch.items():
                if k in ("fps", "auto", "place_id", "link",
                         "name", "avatar_url", "join_friend",
                         "auto_exec", "script_override", "pinned"):     # ★ NEW
                    setattr(a, k, v)
            s._app.save_accounts()
        return True

    def get_credentials(s, id):
        name, pw = s._app.credentials(id)
        if name is None:
            return {"ok": False, "error": "ไม่พบบัญชี"}
        if not pw:
            return {"ok": False, "no_pw": True, "error": "บัญชีนี้ยังไม่มีรหัสผ่านในระบบ"}
        return {"ok": True, "text": f"{name}:{pw}"}

    def delete_account(s, id):
        try:
            return s._app.delete_account(id)
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def delete_bulk(s, ids):
        n = 0
        errs = []
        for i in ids:
            try:
                r = s._app.delete_account(i)
                if r.get("ok"):
                    n += 1
                else:
                    errs.append(r.get("error", ""))
            except Exception as e:
                errs.append(str(e))
        return {"ok": True, "deleted": n, "errors": errs}

    # ── game info + avatar ────────────────────────────────────
    def game_info(s, place_id):
        try:
            return s._app.call(s._app.rbx.game_info(int(place_id)), 20)
        except Exception as e:
            return {"ok": False, "error": str(e)}


    def open_map_picker(s, initial_place_id=0):
        url = None
        try:
            ip = int(initial_place_id) if initial_place_id else 0
            if ip > 0:
                url = f"https://www.roblox.com/games/{ip}"
        except Exception:
            url = None

        cmd = SELF + ["--map-picker"] + ([url] if url else [])
        log = s._app.log
        try:
            env = dict(os.environ, PYTHONIOENCODING="utf-8")
            r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                               errors="replace", env=env, timeout=1200, creationflags=_NOWIN)
            if r.returncode != 0 or r.stderr.strip():
                log("WARN", "picker", f"exit={r.returncode} {r.stderr.strip()[-400:]}")
            pid = 0
            for line in r.stdout.splitlines():
                if line.startswith("PICKED:"):
                    try:
                        pid = int(line[7:].strip())
                    except Exception:
                        pass
            if not pid:
                err = r.stderr.strip().splitlines()[-1] if r.stderr.strip() else "ไม่ได้เลือกเกม"
                return {"ok": False, "error": err}
            try:
                info = s._app.call(s._app.rbx.game_info(pid), 20)
            except Exception:
                info = {"ok": False}
            return {"ok": True, "place_id": pid, "info": info}
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "หมดเวลา (20 นาที)"}
        except Exception as e:
            log("ERROR", "picker", f"เปิด picker ไม่ได้: {e}")
            return {"ok": False, "error": str(e)}

    def resolve_place(s, text):
        import re
        m = re.search(r"/games/(\d+)", str(text)) or re.fullmatch(r"\s*(\d{5,})\s*", str(text))
        if not m:
            return {"ok": False, "error": "ไม่พบ Place ID ในข้อความ"}
        pid = int(m.group(1))
        try:
            info = s._app.call(s._app.rbx.game_info(pid), 20)
        except Exception:
            info = {"ok": False}
        return {"ok": True, "place_id": pid, "info": info}

    # ── launch / queue ────────────────────────────────────────
    def launch(s, ids):
        a = s._app
        # ★ ลบ: a.launch_executor_if_needed()

        activated = 0
        for i in ids:
            acct = a.accts.get(i)
            if acct and acct.state in ("IDLE", "ERROR", "COOLDOWN"):
                acct.active = True
                acct.stop_req = False
                acct.rc = []
                a.q.add("LAUNCH", i)
                activated += 1
        # จัดหน้าต่างจะถูกสั่งเองหลังแต่ละบัญชีเข้าเกม (core/app.py: _entered) — ไม่สั่งล่วงหน้าตอนกดเริ่ม
        return {"ok": True, "activated": activated}

    def apply_layout(s):
        """จัดหน้าต่างตามค่าที่บันทึกไว้ (ตั้งค่า → หน้าต่าง Roblox)"""
        a = s._app
        try:
            return a.arrange_now()
        except Exception as e:
            a.log("ERROR", "layout", str(e))
            return {"ok": False, "error": str(e)}

    def minimize_all(s):
        """ย่อหน้าต่าง Roblox ของทุกบัญชีที่อยู่ในเกม"""
        a = s._app
        try:
            return a.minimize_all()
        except Exception as e:
            a.log("ERROR", "layout", str(e))
            return {"ok": False, "error": str(e)}

    def stop(s, id):
        a = s._app.accts.get(id)
        if not a:
            return False

        a.active = False
        a.stop_req = True
        a.rc = []

        s._app.q.cancel(id)

        import psutil
        if a.pid and psutil.pid_exists(a.pid):
            try:
                p = psutil.Process(a.pid)
                if (p.name() or "").lower() == "robloxplayerbeta.exe":
                    for c in p.children(recursive=True):
                        try:
                            c.kill()
                        except Exception:
                            pass
                    p.kill()
            except Exception:
                pass
        a.pid = 0

        s._app.tr(a, "IDLE", "ปิดใช้งาน · ออฟไลน์")
        s._app.log("INFO", "core", f"ปิดใช้งาน {a.name}")
        return True

    def set_paused(s, p):
        s._app.q.paused = bool(p)
        s._app.log("WARN", "queue", "พักคิว" if p else "เดินคิวต่อ")
        return True

    def cancel_job(s, job_id):
        try:
            return s._app.q.cancel_job(int(job_id))
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def cancel_all_pending(s):
        try:
            return s._app.q.cancel_all_pending()
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ── credentials ───────────────────────────────────────────
    def _add(s, ck, user=None, pw=None):
        ck = ck.strip().strip('"')
        i = ck.find("_|WARNING")
        if i > 0:
            head, ck = ck[:i].rstrip(":").strip(), ck[i:]
            if ":" in head and not (user and pw):
                user, pw = head.split(":", 1)
        return s._app.add_account(s._app.call(s._app.rbx.me(ck)), ck, pw)

    def add_cookie(s, ck):
        try:
            return {"ok": True, "added": s._add(ck)}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def add_many(s, text):
        n, err = 0, ""
        for line in text.splitlines():
            if line.strip():
                try:
                    s._add(line)
                    n += 1
                except Exception as e:
                    err = str(e)
        return {"ok": n > 0, "added": f"{n} บัญชี", "error": err or "ไม่พบ cookie"}

    def browser_login(s):
        try:
            r = subprocess.run(SELF + ["--login"], capture_output=True, text=True, timeout=600, creationflags=_NOWIN)
            ck = next((l for l in reversed(r.stdout.splitlines())
                       if l.startswith("_|WARNING")), "")
            return {"ok": True, "added": s._add(ck)} if ck else {"ok": False, "error": "ไม่ได้ล็อกอิน"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def browser_login_prefill(s, username, password):
        try:
            r = subprocess.run(
                SELF + ["--login-prefill"],
                input=f"{username}\n{password}",
                capture_output=True, text=True, timeout=300, creationflags=_NOWIN,
            )
            ck = ""
            for line in reversed(r.stdout.splitlines()):
                if line.startswith("COOKIE:"):
                    ck = line[7:].strip()
                    break
            if not ck:
                return {"ok": False, "error": "ปิดหน้าต่างก่อน login"}
            try:
                added = s._add(ck, username, password)
                return {"ok": True, "added": added}
            except Exception as e:
                return {"ok": False, "error": f"ได้ cookie แต่เพิ่มบัญชีไม่ได้: {e}"}
        except subprocess.TimeoutExpired:
            return {"ok": False, "error": "หมดเวลา (5 นาที)"}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def quick_begin(s):
        try:
            s._q = s._app.call(s._app.rbx.quick_begin())
            return {"code": s._q["code"]}
        except Exception as e:
            return {"error": str(e)}

    def quick_finish(s):
        try:
            ck = s._app.call(s._app.rbx.quick_finish(s._q), 200)
            return {"ok": True, "added": s._add(ck)}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def login_password(s, username, password):
        s._cred = (username, password)
        try:
            r = s._app.call(s._app.rbx.login_password(username, password), 30)
            if r.get("ok"):
                ck = r["cookie"]
                try:
                    added = s._add(ck, username, password)
                    return {"ok": True, "added": added}
                except Exception as e:
                    return {"ok": False, "error": f"login สำเร็จแต่เพิ่มบัญชีไม่ได้: {e}"}
            return r
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def login_2fa(s, ticket, code):
        try:
            r = s._app.call(s._app.rbx.login_2fa(ticket, code), 30)
            if r.get("ok"):
                ck = r["cookie"]
                try:
                    u, p = getattr(s, "_cred", (None, None))
                    added = s._add(ck, u, p)
                    return {"ok": True, "added": added}
                except Exception as e:
                    return {"ok": False, "error": f"ยืนยันสำเร็จแต่เพิ่มบัญชีไม่ได้: {e}"}
            return r
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ── ★ NEW: Auto-Exec Script ────────────────────────────────
    def get_script_for_account(s, account_id):
        a = s._app.accts.get(account_id)
        if not a:
            return {"ok": False, "error": "ไม่พบบัญชี"}
        return {
            "ok": True,
            "auto_exec": a.auto_exec,
            "script_override": a.script_override,
            "global": s._app.cfg.data.get("auto_exec_script", ""),
            "enabled": s._app.cfg.data.get("auto_exec_enabled", True),
        }

    # ── ★ NEW: Kill Orphans + Instances ────────────────────────
    def kill_orphans(s):
        try:
            return s._app.kill_orphans_now()
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def roblox_instances(s):
        try:
            return s._app.roblox_instances()
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # ── ตรวจสถานะบัญชี ────────────────────────────────────────
    def check_health(s, ids=None):
        n = s._app.check_health(set(ids) if ids else None)
        if n < 0:
            return {"ok": False, "error": "กำลังตรวจอยู่ รอสักครู่"}
        return {"ok": True, "count": n}


    def kill_roblox(s):
        return s._app.kill_roblox_and_reinit()

    def boot_cleanup(s):
        a = s._app
        if not a.cfg.data.get("force_kill_on_boot", False):
            return {"skipped": True, "killed": 0, "ok": a.rbx_ready,
                    "reason": a.rbx.mutex_reason}
        from core.roblox import _count_roblox
        n = _count_roblox()
        if n == 0:
            if not a.rbx_ready:
                a.rbx_ready = a.rbx.hold_mutex()
            return {"killed": 0, "ok": a.rbx_ready, "reason": a.rbx.mutex_reason}
        threading.Thread(target=a.kill_roblox_and_reinit,
                         daemon=True, name="p4ng-boot-kill").start()
        return {"killed": n, "async": True, "ok": True,
                "reason": "กำลังปิด Roblox เบื้องหลัง…"}




    def resolve_user(s, username):
        try:
            return {"ok": True, **(s._app.call(s._app.rbx.resolve_user(username), 20))}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def open_url(s, url):
        try:
            import webbrowser
            if not isinstance(url, str) or not url.startswith(("http://", "https://")):
                return {"ok": False, "error": "url ไม่ถูกต้อง"}
            webbrowser.open(url)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def test_notify(s):
        a = next(iter(s._app.accts.values()), None)
        if not s._app.cfg.data.get("notify_overlay", True):
            return {"ok": False, "error": "แจ้งเตือนถูกปิดอยู่"}
        ok = s._app.notify("test", a.name if a else "P4NG Launcher",
                           a.avatar_url if a else "", "นี่คือตัวอย่างการแจ้งเตือน")
        return {"ok": ok, "error": "" if ok else "overlay ยังไม่พร้อม"}

    def view_account(s, id):
        """ดึงหน้าต่าง Roblox ของบัญชีขึ้นมาแสดง (restore ถ้าย่ออยู่)"""
        a = s._app.accts.get(int(id))
        if not a:
            return {"ok": False, "error": "ไม่พบบัญชี"}
        if not a.pid:
            return {"ok": False, "error": "บัญชีนี้ยังไม่ได้เปิด Roblox"}
        try:
            import psutil, win32gui, win32con, win32process, ctypes
            if not psutil.pid_exists(a.pid):
                return {"ok": False, "error": "หน้าต่าง Roblox ปิดไปแล้ว"}
            from core import system as S
            h = S.hwnd_of(a.pid)
            if not h:
                # หน้าต่างที่ย่ออยู่อาจไม่ผ่านตัวกรอง visible ของ hwnd_of — ลองหาแบบไม่กรอง
                found = []
                def cb(hh, _):
                    try:
                        _, wp = win32process.GetWindowThreadProcessId(hh)
                        if wp == a.pid and win32gui.GetParent(hh) == 0 and win32gui.GetWindowText(hh):
                            found.append(hh)
                    except Exception:
                        pass
                win32gui.EnumWindows(cb, None)
                h = found[0] if found else None
            if not h:
                return {"ok": False, "error": "ไม่พบหน้าต่าง Roblox"}
            if win32gui.IsIconic(h):
                win32gui.ShowWindow(h, win32con.SW_RESTORE)
            else:
                win32gui.ShowWindow(h, win32con.SW_SHOW)
            # ปลดล็อกการแย่ง foreground (Windows กันโปรเซสอื่นแย่งโฟกัส) ด้วยการ attach input thread
            u = ctypes.windll.user32
            fg = u.GetForegroundWindow()
            cur = ctypes.windll.kernel32.GetCurrentThreadId()
            fg_t = u.GetWindowThreadProcessId(fg, None) if fg else 0
            if fg_t and fg_t != cur:
                u.AttachThreadInput(cur, fg_t, True)
            try:
                win32gui.BringWindowToTop(h)
                win32gui.SetForegroundWindow(h)
            finally:
                if fg_t and fg_t != cur:
                    u.AttachThreadInput(cur, fg_t, False)
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def window_ctl(s, action):
        try:
            import webview as _w
            w = _w.windows[0] if _w.windows else None
            if not w:
                return {"ok": False, "error": "no window"}
            if action == "min":
                w.minimize()
            elif action == "max":
                w.toggle_fullscreen()
            elif action == "close":
                w.destroy()
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}


# ═══════════════════════════════════════════════════════════════
#  LOGIN MODES
# ═══════════════════════════════════════════════════════════════

def login_mode():
    w = webview.create_window("Roblox Login", "https://www.roblox.com/login",
                              width=560, height=780)

    def watch():
        while True:
            time.sleep(1.5)
            try:
                for c in w.get_cookies():
                    m = c.get(".ROBLOSECURITY")
                    if m:
                        print(m.value, flush=True)
                        w.destroy()
                        return
            except Exception:
                pass

    webview.start(watch)


def login_prefill_mode(username, password):
    w = webview.create_window(
        "Roblox Login — P4NG",
        "https://www.roblox.com/login",
        width=560, height=780,
    )

    fill_js = """
    (function(){
        try {
            const U = %s;
            const P = %s;
            const inputs = document.querySelectorAll('input');
            let u = null, p = null;
            for (const i of inputs) {
                const t = (i.type || '').toLowerCase();
                const n = (i.name || '').toLowerCase();
                const id = (i.id || '').toLowerCase();
                if (!u && (n === 'username' || id.includes('username') || (t === 'text' && !u))) u = i;
                if (!p && (t === 'password' || n === 'password' || id.includes('password'))) p = i;
            }
            if (!u || !p) return 'pending';
            const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
            setter.call(u, U);
            u.dispatchEvent(new Event('input', {bubbles:true}));
            u.dispatchEvent(new Event('change', {bubbles:true}));
            setter.call(p, P);
            p.dispatchEvent(new Event('input', {bubbles:true}));
            p.dispatchEvent(new Event('change', {bubbles:true}));
            return 'filled';
        } catch(e) { return 'err:' + e.message; }
    })();
    """ % (json.dumps(username), json.dumps(password))

    submit_js = """
    (function(){
        try {
            const btns = [...document.querySelectorAll('button, input[type=submit]')]
                .filter(b => !b.disabled && b.offsetParent !== null);
            const isLogin = b => {
                const t = ((b.textContent || b.value || '')).toLowerCase().trim();
                return b.getAttribute('data-testid') === 'login-button' || b.id === 'login-button'
                    || t === 'log in' || t === 'login' || t === 'เข้าสู่ระบบ';
            };
            const b = btns.find(isLogin);
            if (b) { b.click(); return 'clicked'; }
            const p = document.querySelector('input[type=password]');
            if (p) {
                p.focus();
                ['keydown','keypress','keyup'].forEach(t =>
                    p.dispatchEvent(new KeyboardEvent(t, {
                        key:'Enter', code:'Enter', keyCode:13, which:13, bubbles:true
                    })));
                return 'enter';
            }
            return 'no-button';
        } catch(e) { return 'err:' + e.message; }
    })();
    """

    def watch():
        filled = False
        tries = 0
        clicks = 0
        since = 0.0
        while True:
            time.sleep(1.0)
            tries += 1
            if not filled and tries < 60:
                try:
                    r = w.evaluate_js(fill_js)
                    if r == 'filled':
                        filled = True
                        since = time.time()
                        time.sleep(0.6)
                        try:
                            w.evaluate_js(submit_js)
                        except Exception:
                            pass
                except Exception:
                    pass
            elif filled and clicks < 6 and time.time() - since > 4 * (clicks + 1):
                clicks += 1
                try:
                    w.evaluate_js(submit_js)
                except Exception:
                    pass
            try:
                for c in w.get_cookies():
                    m = c.get(".ROBLOSECURITY")
                    if m:
                        print("COOKIE:" + m.value, flush=True)
                        w.destroy()
                        return
            except Exception:
                pass

    webview.start(watch)


# ═══════════════════════════════════════════════════════════════
#  MAP PICKER MODE
# ═══════════════════════════════════════════════════════════════

INJECT_JS = r"""
(function(){
    if (window.__p4ng_injected) { updateAll(); return; }
    window.__p4ng_injected = true;

    var ACCENT   = '__ACCENT__';
    var ACCENT_2 = '__ACCENT_2__';

    function onAc(h){
        var x = String(h).replace('#','');
        if (x.length === 3) x = x.split('').map(function(c){return c+c;}).join('');
        var n = parseInt(x, 16), c = [(n>>16)&255, (n>>8)&255, n&255].map(function(v){
            v /= 255; return v <= .03928 ? v/12.92 : Math.pow((v+.055)/1.055, 2.4); });
        var L = .2126*c[0] + .7152*c[1] + .0722*c[2];
        return (1.05/(L+.05) >= (L+.05)/.058) ? '#ffffff' : '#14161d';
    }
    var ON_AC = onAc(ACCENT);
    var FONT = '"Noto Sans Thai","Segoe UI","Leelawadee UI",system-ui,sans-serif';

    function hexA(h, a){
        var x = String(h).replace('#','');
        if (x.length === 3) x = x.split('').map(function(c){return c+c;}).join('');
        var n = parseInt(x, 16);
        return 'rgba(' + ((n>>16)&255) + ',' + ((n>>8)&255) + ',' + (n&255) + ',' + a + ')';
    }

    function ensureStyleTag(){
        if (document.getElementById('p4ng-style')) return;
        var st = document.createElement('style');
        st.id = 'p4ng-style';
        st.textContent =
            '[data-p4ng-hidden="1"]{visibility:hidden!important;' +
            'pointer-events:none!important;opacity:0!important;}';
        document.head.appendChild(st);
    }

    function getPlaceId(){
        try {
            var m = location.pathname.match(/\/games\/(\d+)/);
            return m ? parseInt(m[1], 10) : 0;
        } catch(e){ return 0; }
    }

    function findPlayButton(){
        var sels = [
            '[data-testid="play-button"]',
            '[data-testid="game-play-button"]',
            '[data-testid="playGameButton"]',
            '[data-testid="play-game-button"]',
            'button[class*="play-button"]',
            'a[class*="play-button"]',
            'button[class*="PlayButton"]',
            'a[class*="PlayButton"]',
            '.btn-common-play-game-lg',
            '.btn-growth-lg',
            '#game-detail-page-content button',
        ];
        for (var i=0;i<sels.length;i++){
            var el = document.querySelector(sels[i]);
            if (!el) continue;
            var r = el.getBoundingClientRect();
            if (r.width > 50 && r.height > 22) return el;
        }
        var all = document.querySelectorAll('button, a');
        for (var k=0;k<all.length;k++){
            var t = (all[k].textContent || '').trim().toLowerCase();
            var c = String(all[k].className || '').toLowerCase();
            var d = String(all[k].id || '').toLowerCase();
            if (t === 'play' || t === 'เล่น'
                || t.indexOf('play game') === 0
                || c.indexOf('play-game') !== -1
                || c.indexOf('playbutton') !== -1
                || d.indexOf('play-button') !== -1){
                var rr = all[k].getBoundingClientRect();
                if (rr.width > 60 && rr.height > 24) return all[k];
            }
        }
        return null;
    }

    function ensurePickBtn(){
        var btn = document.getElementById('p4ng-pick-btn');
        if (btn) return btn;
        btn = document.createElement('div');
        btn.id = 'p4ng-pick-btn';
        btn.textContent = 'ใช้แมพนี้';
        btn.style.cssText = [
            'position:fixed','z-index:2147483647',
            'background:' + ACCENT, 'color:' + ON_AC,
            'border:0','border-radius:10px','cursor:pointer',
            'box-shadow:0 8px 24px rgba(0,0,0,.45)',
            'font-family:' + FONT,'font-size:15px','font-weight:600',
            'display:none','align-items:center','justify-content:center',
            'padding:0 14px','box-sizing:border-box',
            'transition:transform .12s,filter .15s,background .15s',
            'user-select:none','white-space:nowrap',
        ].join(';');
        btn.onmouseenter = function(){ this.style.filter = 'brightness(1.1)'; };
        btn.onmouseleave = function(){ this.style.filter = ''; this.style.transform = ''; };
        btn.onmousedown = function(){ this.style.transform = 'scale(.98)'; };
        btn.onclick = function(e){
            e.stopPropagation(); e.preventDefault();
            var pid = getPlaceId(); if (!pid) return;
            btn.textContent = 'กำลังเลือก…';
            btn.style.pointerEvents = 'none';
            try {
                if (window.pywebview && window.pywebview.api
                    && window.pywebview.api.pick){
                    window.pywebview.api.pick(pid).then(function(){
                        btn.textContent = 'เลือกแล้ว';
                        btn.style.background = '#3ddc97';
                        btn.style.color = '#07281a';
                    }).catch(function(err){
                        btn.textContent = 'ผิดพลาด: ' + ((err && err.message) || 'error');
                        btn.style.pointerEvents = 'auto';
                    });
                } else {
                    btn.textContent = 'ไม่พบ bridge';
                }
            } catch(err){
                btn.textContent = 'ผิดพลาด: ' + err.message;
                btn.style.pointerEvents = 'auto';
            }
        };
        document.body.appendChild(btn);
        return btn;
    }

    /* แถบบนสไตล์ titlebar ของแอป: ย้อนกลับ + ชื่อ + คำอธิบาย */
    function ensureBackBtn(){
        var bar = document.getElementById('p4ng-back-btn');
        if (bar) return bar;
        bar = document.createElement('div');
        bar.id = 'p4ng-back-btn';
        bar.style.cssText = [
            'position:fixed','top:12px','left:50%','transform:translateX(-50%)','z-index:2147483647',
            'display:flex','align-items:center','gap:12px','padding:6px 14px 6px 6px',
            'background:rgba(26,28,37,.94)','color:#f1f2f8',
            'border:1px solid rgba(255,255,255,.13)','border-radius:14px',
            'box-shadow:0 16px 40px -12px rgba(0,0,0,.7)',
            'backdrop-filter:blur(14px)','-webkit-backdrop-filter:blur(14px)',
            'font-family:' + FONT,'font-size:13px','user-select:none','white-space:nowrap',
        ].join(';');
        var back = document.createElement('button');
        back.type = 'button';
        back.textContent = '← ย้อนกลับ';
        back.style.cssText = 'height:32px;padding:0 12px;border:1px solid rgba(255,255,255,.13);border-radius:10px;'
            + 'background:#212430;color:#f1f2f8;font:500 13px ' + FONT + ';cursor:pointer;transition:background .15s';
        back.onmouseenter = function(){ this.style.background = '#2a2e3b'; };
        back.onmouseleave = function(){ this.style.background = '#212430'; };
        back.onclick = function(e){
            e.stopPropagation(); e.preventDefault();
            try {
                if (history.length > 1) history.back();
                else location.href = 'https://www.roblox.com/discover';
            } catch(_){ location.href = 'https://www.roblox.com/discover'; }
        };
        var dot = document.createElement('i');
        dot.style.cssText = 'width:8px;height:8px;border-radius:50%;background:' + ACCENT + ';flex:none';
        var tx = document.createElement('span');
        tx.innerHTML = '<b style="font-weight:600">P4NG · เลือกเกม</b> '
            + '<span style="color:#a4aabd">เปิดหน้าเกมที่ต้องการ แล้วกด “ใช้แมพนี้” แทนปุ่ม Play</span>';
        bar.append(back, dot, tx);
        document.body.appendChild(bar);
        return bar;
    }

    function positionPickBtn(){
        var btn = ensurePickBtn();
        var pid = getPlaceId();

        if (!pid){
            btn.style.display = 'none';
            return;
        }

        var play = findPlayButton();

        if (!play){
            btn.style.display = 'flex';
            btn.style.left = 'auto';
            btn.style.top = 'auto';
            btn.style.right = '28px';
            btn.style.bottom = '28px';
            btn.style.width = 'auto';
            btn.style.height = 'auto';
            btn.style.padding = '14px 26px';
            btn.style.fontSize = '16px';
            return;
        }

        if (play.getAttribute('data-p4ng-hidden') !== '1'){
            play.setAttribute('data-p4ng-hidden', '1');
        }

        var r = play.getBoundingClientRect();
        var inView = r.bottom > 0 && r.top < window.innerHeight
                     && r.right > 0 && r.left < window.innerWidth
                     && r.width > 0 && r.height > 0;

        if (!inView){
            btn.style.display = 'none';
            return;
        }

        var pad = 3;
        btn.style.display = 'flex';
        btn.style.left   = (r.left - pad) + 'px';
        btn.style.top    = (r.top  - pad) + 'px';
        btn.style.width  = (r.width  + pad * 2) + 'px';
        btn.style.height = (r.height + pad * 2) + 'px';
        btn.style.right  = 'auto';
        btn.style.bottom = 'auto';
        btn.style.padding = '0 12px';
        btn.style.fontSize = '15px';
    }

    function updateAll(){
        ensureStyleTag();
        ensureBackBtn();
        positionPickBtn();
    }

    var last = location.href;
    setInterval(function(){
        if (location.href !== last){
            last = location.href;
            setTimeout(updateAll, 350);
        }
        positionPickBtn();
    }, 400);

    try {
        new MutationObserver(function(){ positionPickBtn(); })
            .observe(document.documentElement, { childList:true, subtree:true });
    } catch(e){}

    window.addEventListener('resize', positionPickBtn);
    window.addEventListener('scroll', positionPickBtn, true);
    document.addEventListener('scroll', positionPickBtn, true);

    updateAll();
})();
"""


def _read_accent():
    accent, accent_2 = "#9d7bff", "#7f5ce6"
    try:
        sp = DATA / "settings.json"
        if sp.exists():
            d = json.loads(sp.read_text("utf-8"))
            accent = d.get("accent") or accent
            accent_2 = d.get("accent_2") or accent_2
    except Exception:
        pass
    return accent, accent_2


def map_picker_mode(initial_url=None):
    result = {"place_id": None}
    accent, accent_2 = _read_accent()
    js = INJECT_JS.replace("__ACCENT__", accent).replace("__ACCENT_2__", accent_2)

    class MapApi:
        def pick(s, place_id):
            try:
                pid = int(place_id)
                result["place_id"] = pid
                print(f"PICKED:{pid}", flush=True)
            except Exception:
                pass
            return True

    url = initial_url or "https://www.roblox.com/discover"
    w = webview.create_window(
        "P4NG · เลือกเกม",
        url,
        width=1200, height=820,
        js_api=MapApi(),
    )

    def watch():
        while True:
            time.sleep(1.2)
            if result["place_id"]:
                time.sleep(0.4)
                try:
                    w.destroy()
                except Exception:
                    pass
                return
            try:
                w.evaluate_js(js)
            except Exception:
                pass

    threading.Thread(target=watch, daemon=True).start()
    webview.start()


def _setup_overlay(app, main_win):
    try:
        from core.overlay import Overlay, TITLE, W
        ov = Overlay(app)
        kw = dict(js_api=ov.js_api(), width=W, height=100, min_size=(100, 40),
                  frameless=True, on_top=True, hidden=True, resizable=False,
                  easy_drag=False, background_color="#0b0b11")
        url = str(RES / "ui" / "overlay.html")
        try:
            win = webview.create_window(TITLE, url, focus=False, **kw)
        except TypeError:
            win = webview.create_window(TITLE, url, **kw)
        ov.attach(win)
        app.notifier = ov.push
        main_win.events.closed += ov.close
    except Exception as e:
        print(f"[overlay] ปิดใช้งาน: {e}", flush=True)


if __name__ == "__main__":
    if "--login" in sys.argv:
        login_mode()
        sys.exit(0)

    if "--login-prefill" in sys.argv:
        lines = sys.stdin.read().split("\n", 1)
        user = lines[0].strip() if len(lines) > 0 else ""
        pw = lines[1].rstrip("\n") if len(lines) > 1 else ""
        if not user or not pw:
            print("ERROR:missing credentials", flush=True)
            sys.exit(1)
        login_prefill_mode(user, pw)
        sys.exit(0)

    if "--map-picker" in sys.argv:
        idx = sys.argv.index("--map-picker")
        url = sys.argv[idx + 1] if idx + 1 < len(sys.argv) else None
        map_picker_mode(url)
        sys.exit(0)

    _cleanup_queue()
    _patch_pywebview_move()

    api = Api()
    main_win = webview.create_window(
        MAIN_TITLE,
        str(RES / "ui" / "index.html"),
        js_api=api,
        width=1280, height=800, min_size=(980, 640),
        background_color="#0d0a13",
        frameless=True,
        easy_drag=False,
    )
    _setup_overlay(api._app, main_win)
    try:                                       # ให้แถบงานแยกกลุ่มเป็น P4NG (ไม่รวมกับไอคอน python) + ใส่ไอคอนแอป
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("P4NG.Launcher")
        main_win.events.shown += _set_app_icon
    except Exception:
        pass
    webview.start()