#!/usr/bin/env python3
"""สร้าง zip สำหรับอัปโหลดเป็น Release (repo สาธารณะ) — python tools/make_release.py

ทำให้:
  • อ่านเลขเวอร์ชันจาก core/version.py แล้วตั้งชื่อไฟล์ dist/P4NG_Launcher-v<VERSION>.zip
  • ตัดของที่ห้ามหลุดออก: data/, portable.txt, update/, update_token.txt, .git, __pycache__, *.pyc, *.zip/*.rar, dist/
  • หยุดทันทีถ้าเจอไฟล์อ่อนไหว (vault / accounts / cookie / log / token) หรือ UPDATE_TOKEN ในโค้ดไม่ว่าง
"""
import re, sys, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKIP_DIRS = {"data", "update", "dist", "build", ".git", "__pycache__", "node_modules"}
SKIP_FILES = {"portable.txt", "update_token.txt"}
SKIP_EXT = {".pyc", ".zip", ".rar", ".7z"}
DANGER_NAMES = {"accounts.json", "settings.json", "launcher.log"}
DANGER_EXT = {".enc", ".log", ".bak"}
DANGER_WORDS = ("cookie", "token", "password", "secret")      # ชื่อไฟล์ (ที่ไม่ใช่ .py/.js/.md) ที่ถ้าโผล่ = น่าจะพลาด


def dangerous(rel):
    n = rel.name.lower()
    return (n in DANGER_NAMES or rel.suffix.lower() in DANGER_EXT or ".enc." in n
            or (rel.suffix.lower() not in {".py", ".js", ".md", ".css", ".html"} and any(w in n for w in DANGER_WORDS)))


def main():
    ver_src = (ROOT / "core" / "version.py").read_text(encoding="utf-8")
    m = re.search(r'^VERSION\s*=\s*"([^"]+)"', ver_src, re.M)
    if not m:
        sys.exit("อ่าน VERSION จาก core/version.py ไม่ได้")
    ver = m.group(1)
    if re.search(r'^UPDATE_TOKEN\s*=\s*"[^"]+"', ver_src, re.M):
        sys.exit("UPDATE_TOKEN ใน core/version.py ไม่ว่าง — ล้างก่อนปล่อย (repo สาธารณะ)")
    if 'UPDATE_REPO = "OWNER/REPO"' in ver_src:
        print("⚠ UPDATE_REPO ยังเป็น OWNER/REPO — แอปที่ได้จะตรวจอัปเดตไม่ได้")

    files = []
    for p in sorted(ROOT.rglob("*")):
        rel = p.relative_to(ROOT)
        if not p.is_file() or set(rel.parts[:-1]) & SKIP_DIRS:
            continue
        if p.name in SKIP_FILES or p.suffix.lower() in SKIP_EXT:
            continue
        files.append(rel)

    bad = [str(r) for r in files if dangerous(r)]
    if bad:
        sys.exit("พบไฟล์ที่ไม่ควรอยู่ในแพ็กเกจ: " + ", ".join(bad))
    if not any(r.as_posix() == "main.py" for r in files):
        sys.exit("ไม่พบ main.py — รันจากโฟลเดอร์โปรเจกต์หรือเปล่า")

    out = ROOT / "dist" / f"P4NG_Launcher-v{ver}.zip"
    out.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for r in files:
            z.write(ROOT / r, r.as_posix())
    print(f"สร้างแล้ว: {out}  ({len(files)} ไฟล์, {out.stat().st_size // 1024} KB)")
    print(f"ขั้นต่อไป: สร้าง Release ใน repo ปล่อยไฟล์ → tag = v{ver} → แนบ zip นี้เป็น asset")


if __name__ == "__main__":
    main()
