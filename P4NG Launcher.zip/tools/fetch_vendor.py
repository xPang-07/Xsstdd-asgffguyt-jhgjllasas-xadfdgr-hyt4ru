#!/usr/bin/env python3
"""(ไม่บังคับ) สร้าง ui/vendor.js ใหม่จาก CDN — ปกติไม่ต้องรัน เพราะ vendor.js แนบมาในโปรเจกต์แล้ว (Import ใช้ได้เลย)
อัปเดตเวอร์ชัน: แก้เลขในตาราง แล้วรัน  python tools/fetch_vendor.py
Tooltip เขียนเองใน app.js ไม่ต้องใช้ Tippy/Popper
"""
import sys, urllib.request
from pathlib import Path

UI = Path(__file__).resolve().parent.parent / "ui"
CDN = "https://cdn.jsdelivr.net/npm"
JS = [
    ("GSAP — animation", "gsap@3.12.5/dist/gsap.min.js"),
    ("Lucide — ไอคอน",   "lucide@0.468.0/dist/umd/lucide.min.js"),
]


def get(path):
    with urllib.request.urlopen(f"{CDN}/{path}", timeout=30) as r:
        data = r.read().decode("utf-8")
    if len(data) < 300:
        raise ValueError(f"ไฟล์เล็กผิดปกติ ({len(data)} ตัวอักษร)")
    return data


if __name__ == "__main__":
    try:
        parts = [f"/* ── {n} · {p} ── */\n" + get(p) for n, p in JS]
    except Exception as e:
        sys.exit(f"ดาวน์โหลดไม่สำเร็จ: {e}")
    (UI / "vendor.js").write_text("\n;\n".join(parts) + "\n", "utf-8")
    print("ok -> ui/vendor.js")
