@echo off
setlocal
rem ============================================================
rem  P4NG Launcher - Setup
rem  Double-click to install everything the app needs.
rem  Usage:  Setup.bat          full setup (+ desktop shortcut)
rem          Setup.bat /auto    silent-ish mode, used by Start.bat
rem ============================================================
cd /d "%~dp0"
set "AUTO="
if /i "%~1"=="/auto" set "AUTO=1"

echo.
echo === P4NG Launcher - Setup ===

rem ---- [1/4] find Python ----
echo.
echo [1/4] Checking Python...
set "PYC="
where python >nul 2>nul && set "PYC=python"
if not defined PYC where py >nul 2>nul && set "PYC=py"
if not defined PYC goto :nopython

%PYC% -c "import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)" >nul 2>nul
if errorlevel 1 goto :oldpython
for /f "delims=" %%v in ('%PYC% -c "import sys; print(sys.version.split()[0])"') do echo   OK  Python %%v

rem ---- [2/4] install libraries ----
echo.
echo [2/4] Installing libraries (this may take a minute)...
%PYC% -m pip --version >nul 2>nul
if errorlevel 1 %PYC% -m ensurepip --upgrade
%PYC% -m pip install --disable-pip-version-check -r "%~dp0requirements.txt"
if errorlevel 1 goto :pipfail

%PYC% -c "import webview, httpx, psutil, win32gui, cryptography, argon2" >nul 2>nul
if errorlevel 1 goto :importfail
echo   OK  All libraries are ready

rem ---- [3/4] WebView2 ----
echo.
echo [3/4] Checking WebView2 Runtime...
set "WV2="
reg query "HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>nul && set "WV2=1"
if not defined WV2 reg query "HKLM\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>nul && set "WV2=1"
if not defined WV2 reg query "HKCU\Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" /v pv >nul 2>nul && set "WV2=1"
if defined WV2 echo   OK  WebView2 found
if not defined WV2 echo   !!  WebView2 Runtime not found. If the app does not open, install it from:
if not defined WV2 echo       https://developer.microsoft.com/microsoft-edge/webview2/

if defined AUTO goto :done

rem ---- [4/4] desktop shortcut ----
echo.
echo [4/4] Creating desktop shortcut...
set "PYW="
for /f "delims=" %%i in ('where pythonw 2^>nul') do if not defined PYW set "PYW=%%i"
if not defined PYW for /f "delims=" %%i in ('where pyw 2^>nul') do if not defined PYW set "PYW=%%i"
if not defined PYW goto :noshortcut
set "P4_TARGET=%PYW%"
set "P4_MAIN=%~dp0main.py"
set "P4_ROOT=%~dp0"
set "P4_ICON=%~dp0ui\img\logo.ico"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\P4NG Launcher.lnk'); $s.TargetPath=$env:P4_TARGET; $s.Arguments='\"'+$env:P4_MAIN+'\"'; $s.WorkingDirectory=$env:P4_ROOT; if(Test-Path $env:P4_ICON){$s.IconLocation=$env:P4_ICON}; $s.Save()"
if errorlevel 1 goto :noshortcut
echo   OK  Shortcut "P4NG Launcher" created on Desktop
goto :done

:noshortcut
echo   !!  Could not create the shortcut. Use Start.bat to open the app instead.

:done
echo.
echo Setup finished. To open the app: double-click Start.bat
if defined AUTO exit /b 0
echo.
choice /c YN /m "Open the app now"
if errorlevel 2 goto :end
if /i "%PYC%"=="py" (start "" pyw "%~dp0main.py") else (start "" pythonw "%~dp0main.py")
:end
endlocal
exit /b 0

:nopython
echo   X  Python not found.
echo      Install Python 3.10 or newer from https://www.python.org/downloads/
echo      and tick "Add python.exe to PATH" during install.
goto :fail

:oldpython
echo   X  Python 3.10 or newer is required.
goto :fail

:pipfail
echo   X  pip install failed. Check your internet connection and run Setup.bat again.
goto :fail

:importfail
echo   X  Some libraries still cannot be imported. Try:  %PYC% -m pip install -r requirements.txt
goto :fail

:fail
echo.
if not defined AUTO pause
exit /b 1
