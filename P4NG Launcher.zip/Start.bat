@echo off
rem P4NG Launcher - double-click to start the app
rem If libraries are missing, Setup.bat runs automatically first
cd /d "%~dp0"

set "PYC="
where python >nul 2>nul && set "PYC=python"
if not defined PYC where py >nul 2>nul && set "PYC=py"
if not defined PYC goto :setup

%PYC% -c "import webview, httpx, psutil, win32gui, cryptography, argon2" >nul 2>nul
if errorlevel 1 goto :setup
goto :run

:setup
call "%~dp0Setup.bat" /auto
if errorlevel 1 (
  pause
  exit /b 1
)
set "PYC="
where python >nul 2>nul && set "PYC=python"
if not defined PYC where py >nul 2>nul && set "PYC=py"

:run
if /i "%PYC%"=="py" (start "" pyw "%~dp0main.py") else (start "" pythonw "%~dp0main.py")
