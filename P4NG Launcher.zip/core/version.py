"""เลขเวอร์ชันของแอป + repo ที่ใช้ตรวจอัปเดต

ออกเวอร์ชันใหม่: แก้ VERSION ให้ตรงกับ tag ของ Release (เช่น VERSION = "1.0.1" ↔ tag v1.0.1)
แล้วอัปโหลดไฟล์ .zip ของโปรเจกต์เป็น asset ของ Release นั้น
"""
VERSION = "1.0.0"

# ★ แก้เป็น "ชื่อผู้ใช้/ชื่อrepo" บน GitHub ของคุณ เช่น "p4ng/launcher"
UPDATE_REPO = "xPang-07/Xsstdd-asgffguyt-jhgjllasas-xadfdgr-hyt4ru"

# repo แบบ private: ใส่ token แบบ "อ่านอย่างเดียว" (GitHub → Settings → Developer settings → Fine-grained tokens
# → เลือกเฉพาะ repo นี้ · Permissions: Contents = Read-only · ตั้งวันหมดอายุ) หรือวางไว้ในไฟล์
# %APPDATA%\P4NG Launcher\update_token.txt (ไฟล์นี้ชนะค่าในโค้ด) · repo public ปล่อยว่างไว้
# ⚠ token ที่ฝังในโค้ดที่แจกเพื่อน เพื่อนอ่านได้ — ใช้ token สิทธิ์ต่ำสุดและแยกเฉพาะ repo นี้เท่านั้น
UPDATE_TOKEN = ""
