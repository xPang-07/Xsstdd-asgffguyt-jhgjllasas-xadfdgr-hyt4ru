"""
รับสัญญาณจาก api.lua (รันในเกมผ่าน executor)
    POST /                เข้าเกม   {username, userId?, placeId, jobId, gameId}
    POST /api/disconnect หลุด      {username, userId?, reason, error_code}
    POST /api/desc        ข้อความ   {username, desc}
    GET  /                health check
    GET  /api/script      ★ NEW — ดึง script สำหรับบัญชีนี้
"""
import json, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

PORTS = (3030, 3031, 3032)
MAX_BODY = 4096

_server = None


class _Handler(BaseHTTPRequestHandler):
    app = None

    def log_message(self, *a):
        pass

    def _reply(self, code, obj):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _local(self):
        host = (self.headers.get("Host") or "").split(":")[0].lower()
        if host not in ("127.0.0.1", "localhost", "::1", "[::1]"):
            return False
        if self.command == "POST":
            if self.headers.get("Origin") or self.headers.get("Referer"):
                return False
        return True

    def _json(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            d = json.loads(self.rfile.read(n)) if 0 < n <= MAX_BODY else None
        except Exception:
            return None
        return d if isinstance(d, dict) else None

    def do_GET(self):
        if not self._local():
            return self._reply(403, {"ok": False})
        parsed = urlparse(self.path)
        path = parsed.path.rstrip("/") or "/"

        # ★ NEW — executor ดึง script
        if path == "/api/script":
            qs = parse_qs(parsed.query)
            try:
                uid = int(qs.get("uid", ["0"])[0])
            except (ValueError, TypeError):
                uid = 0
            try:
                script = self.app.get_script_for(uid)
            except Exception as e:
                self.app.log("WARN", "api", f"get_script_for({uid}): {e}")
                script = ""
            try:
                delay = float(self.app.cfg.data.get("auto_exec_delay", 2) or 0)
            except (TypeError, ValueError):
                delay = 2.0
            return self._reply(200, {"ok": True, "script": script or "", "delay": delay})

        self._reply(200, {"ok": True, "service": "P4NG"})

    def do_POST(self):
        if not self._local():
            return self._reply(403, {"ok": False})
        path = urlparse(self.path).path.rstrip("/") or "/"
        handler = {
            "/": self.app.on_beat,
            "/api/disconnect": self.app.on_drop,
            "/api/desc": self.app.on_desc,
        }.get(path)
        d = self._json()
        if not handler:
            return self._reply(404, {"ok": False})
        if d is None:
            return self._reply(400, {"ok": False})
        try:
            self.app.loop.call_soon_threadsafe(handler, d)
        except RuntimeError:
            return self._reply(503, {"ok": False})
        self._reply(200, {"ok": True, "service": "P4NG"})


def start(app, port=None):
    global _server
    stop()
    handler = None
    for p in ((port,) if port else PORTS):
        try:
            handler = ThreadingHTTPServer(
                ("127.0.0.1", p),
                type("_H", (_Handler,), {"app": app}),
            )
            port = p
            break
        except OSError as e:
            app.log("WARN", "api", f"พอร์ต {p} ใช้ไม่ได้: {e}")
    if not handler:
        app.log("ERROR", "api",
                f"เปิดพอร์ต {', '.join(map(str, PORTS))} ไม่ได้")
        return 0
    threading.Thread(target=handler.serve_forever,
                     daemon=True, name="p4ng-api").start()
    _server = handler
    note = "" if port == PORTS[0] else " (สำรอง)"
    app.log("INFO", "api", f"รับ heartbeat ที่ 127.0.0.1:{port}{note}")
    return port


def stop():
    global _server
    if _server:
        try:
            _server.shutdown(); _server.server_close()
        except Exception:
            pass
        _server = None