import asyncio, json, random, threading, time
from dataclasses import dataclass, field
from .config import DATA

PRI = {"KILL": 0, "REJOIN": 1, "LAUNCH": 2, "APPLY_LAYOUT": 3}
BACKOFF = [10, 30, 90]


class Fatal(Exception):
    pass


class Cancelled(Exception):
    pass


@dataclass
class Job:
    id: int
    type: str
    acc: int
    pri: int
    nb: float
    key: str
    state: str = "PENDING"
    attempts: int = 0
    max_attempts: int = 3
    created_at: float = field(default_factory=time.time)


class Queue:
    def __init__(s, app):
        s.app = app
        s.jobs = []
        s.jid = 1
        s.busy = False
        s.next_at = 0.0
        s.paused = False
        s.fails = 0
        s.done = []
        s.lock = threading.RLock()

    def add(s, type, acc=0, delay=0):
        key = f"{type}:{acc}"
        with s.lock:
            if any(j.key == key for j in s.jobs):
                s.app.log("DEBUG", "queue", f"ข้าม {key} (มีอยู่แล้ว)")
                return
            s.jobs.append(Job(s.jid, type, acc, PRI[type], time.time() + delay, key))
            s.jid += 1
        a = s.app.accts.get(acc)
        s.app.log("INFO", "queue",
                  f"เข้าคิว {type}" + (f" → {a.name}" if a else "")
                  + f" (priority {PRI[type]})")
        if a and type in ("LAUNCH", "REJOIN"):
            s.app.tr(a, "QUEUED", "รอ launch lane ว่าง")
        s.persist()

    def cancel(s, acc):
        with s.lock:
            s.jobs = [j for j in s.jobs if j.acc != acc or j.state == "RUNNING"]
        s.persist()

    def cancel_job(s, job_id):
        with s.lock:
            target = next((j for j in s.jobs if j.id == job_id), None)
            if not target:
                return {"ok": False, "error": "ไม่พบงานนี้ (อาจเสร็จหรือถูกยกเลิกแล้ว)"}
            a = s.app.accts.get(target.acc) if target.acc else None
            if target.state == "RUNNING" and a:
                a.stop_req = True
            s.jobs = [x for x in s.jobs if x is not target]
            info = {"type": target.type, "acc": target.acc,
                    "name": a.name if a else "—"}
        s.app.log("WARN", "queue",
                  f"ยกเลิกงาน #{job_id} ({info['type']}) → {info['name']}")
        s.persist()
        return {"ok": True, "cancelled": info}

    def cancel_all_pending(s):
        with s.lock:
            pending = [j for j in s.jobs if j.state == "PENDING"]
            s.jobs = [j for j in s.jobs if j.state != "PENDING"]
            n = len(pending)
        if n:
            s.app.log("WARN", "queue", f"ยกเลิกงานที่รอทั้งหมด {n} งาน")
        s.persist()
        return {"ok": True, "count": n}

    def persist(s):
        try:
            (DATA / "jobs.json").write_text(json.dumps(
                [[j.type, j.acc] for j in s.jobs if j.type in ("LAUNCH", "REJOIN")]
            ))
        except OSError:
            pass

    def restore(s):
        p = DATA / "jobs.json"
        try:
            for t, i in json.loads(p.read_text()):
                if i in s.app.accts:
                    s.add(t, i)
        except Exception:
            pass

    async def run(s):
        while True:
            await asyncio.sleep(.3)
            if s.paused:
                continue
            now = time.time()
            with s.lock:
                due = sorted(
                    [j for j in s.jobs if j.state == "PENDING" and j.nb <= now],
                    key=lambda j: (j.pri, j.id),
                )
            heavy = [j for j in due if j.type in ("LAUNCH", "REJOIN")]

            if not s.busy and now >= s.next_at and heavy:
                s.busy = True
                heavy[0].state = "RUNNING"
                asyncio.create_task(s.exec(heavy[0], True))

            for j in due:
                if j.state != "PENDING":
                    continue
                if j.type == "KILL":
                    j.state = "RUNNING"
                    asyncio.create_task(s.exec(j, False))
                elif (j.type == "APPLY_LAYOUT" and not s.busy
                      and not any(h.type in ("LAUNCH", "REJOIN") for h in s.jobs)):
                    j.state = "RUNNING"
                    asyncio.create_task(s.exec(j, False))

    async def exec(s, j, heavy):
        app = s.app
        a = app.accts.get(j.acc)
        c = app.cfg.data
        try:
            _t0 = time.time()
            with s.lock:
                waiting = sum(1 for x in s.jobs if x.state == "PENDING")
            app.log("INFO", "queue",
                    f"งาน #{j.id} เริ่ม {j.type}" + (f" [{a.name}]" if a else "")
                    + f" · รอคิวอยู่อีก {waiting} งาน")
            await asyncio.wait_for(app.handle(j), 240)
            with s.lock:
                # ★ FIX #10: ใช้ filter แทน remove() — กัน ValueError กรณีถูก cancel ก่อนหน้านี้
                s.jobs = [x for x in s.jobs if x is not j]
            s.fails = 0
            app.log("INFO", "queue", f"งาน #{j.id} {j.type}" + (f" [{a.name}]" if a else "")
                    + f" สำเร็จ · ใช้เวลา {time.time() - _t0:.1f} วิ")
            s.done.insert(0, {"t": time.strftime("%H:%M:%S"),
                              "type": j.type, "acc": j.acc})
            del s.done[8:]
            if heavy:
                d = random.uniform(c["dmin"], max(c["dmin"], c["dmax"]))
                s.next_at = time.time() + d
                app.log("INFO", "queue", f"เว้นช่วง {d:.0f} วิ ก่อนเปิดเกมบัญชีถัดไป")

        except Cancelled:
            with s.lock:
                s.jobs = [x for x in s.jobs if x is not j]
            if a:
                await app.h_kill(a)
                if a.active:
                    app.tr(a, "IDLE", "ผู้ใช้สั่งหยุด")

        except Fatal as e:
            with s.lock:
                s.jobs = [x for x in s.jobs if x is not j]
            app.log("ERROR", "queue", f"งาน #{j.id} {j.type}" + (f" [{a.name}]" if a else "")
                    + f" ล้มเหลวแบบแก้เองไม่ได้: {e}")
            if a:
                a.active = False
                app.tr(a, "ERROR", str(e))

        except Exception as e:
            if a and a.stop_req:
                with s.lock:
                    s.jobs = [x for x in s.jobs if x is not j]
                if a:
                    await app.h_kill(a)
                    if a.active:
                        app.tr(a, "IDLE", "ผู้ใช้สั่งหยุด")
                return

            j.attempts += 1
            if j.attempts < j.max_attempts:
                d = BACKOFF[j.attempts - 1] * random.uniform(.8, 1.3)
                j.state = "PENDING"
                j.nb = time.time() + d
                app.log("WARN", "queue", f"งาน #{j.id} {j.type}" + (f" [{a.name}]" if a else "")
                        + f" พลาด ({type(e).__name__}) · ลองใหม่ครั้งที่ {j.attempts + 1}/{j.max_attempts} ใน {d:.0f} วิ")
                if a:
                    app.tr(a, "QUEUED",
                           f"retry {j.attempts}/{j.max_attempts} ใน {d:.0f} วิ: {e}")
            else:
                with s.lock:
                    s.jobs = [x for x in s.jobs if x is not j]
                if a:
                    app.tr(a, "ERROR", f"{e} (เกิน retry)")
                s.fails += 1
                if s.fails >= 3:
                    s.paused = True
                    s.fails = 0
                    app.log("ERROR", "queue", "ล้มเหลวติดกัน 3 ครั้ง — พักคิว 60 วิ")
                    asyncio.get_running_loop().call_later(
                        60, lambda: setattr(s, "paused", False))

        finally:
            if heavy:
                s.busy = False
            s.persist()