import asyncio, os, random, re, threading, time, urllib.parse
import ctypes
from ctypes import wintypes
from pathlib import Path
import httpx, psutil

LOCAL = Path(os.environ.get("LOCALAPPDATA", "")) / "Roblox"
SETTINGS = LOCAL / "GlobalBasicSettings_13.xml"

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")

ROBLOX_MAIN     = "robloxplayerbeta.exe"
ROBLOX_LAUNCHER = "robloxplayerlauncher.exe"
ROBLOX_CRASH    = "robloxcrashhandler.exe"
ROBLOX_NAMES    = {ROBLOX_MAIN, ROBLOX_LAUNCHER, ROBLOX_CRASH, "robloxplayerbeta"}


class RbxError(Exception):
    pass


def _count_roblox():
    try:
        return len(pids())
    except Exception:
        return 0


def kill_all_roblox():
    """ฆ่าทุกอย่างที่เกี่ยวข้องกับ Roblox (main + launcher + crashhandler)"""
    n = 0
    try:
        for p in psutil.process_iter(["name"]):
            name = (p.info.get("name") or "").lower()
            if name in ROBLOX_NAMES:
                try:
                    p.kill()
                    n += 1
                except Exception:
                    pass
        if n:
            time.sleep(1.5)
    except Exception:
        pass
    return n


# ══════════════════════════════════════════════════════════════
#  ตรวจว่าหน้าต่างหลักของ Roblox PID นี้อยู่หน้า Home
# ══════════════════════════════════════════════════════════════
def _window_titles_of(pid):
    """คืน list ของ (visible, area, title) ของหน้าต่าง top-level ของ pid"""
    try:
        import win32gui, win32process
    except Exception:
        return []
    out = []

    def cb(h, _):
        if win32gui.GetParent(h) != 0:
            return
        try:
            _, wpid = win32process.GetWindowThreadProcessId(h)
        except Exception:
            return
        if wpid != pid:
            return
        try:
            l, t, r, b = win32gui.GetWindowRect(h)
            area = max(1, r - l) * max(1, b - t)
        except Exception:
            area = 1
        try:
            visible = bool(win32gui.IsWindowVisible(h))
        except Exception:
            visible = False
        try:
            title = win32gui.GetWindowText(h) or ""
        except Exception:
            title = ""
        out.append((visible, area, title))

    try:
        win32gui.EnumWindows(cb, None)
    except Exception:
        return []
    return out


# title ที่ถือว่า "อยู่หน้า Home"
HOME_TITLES = frozenset({
    "roblox", "roblox player", "robloxplayerbeta",
})


def is_on_home_screen(pid):
    """True ถ้า Roblox นี้ค้างอยู่หน้า Home (ยังไม่เข้าเกม)
    - หน้า Home title = 'Roblox' ล้วน ๆ
    - ในเกม   title = '<ชื่อเกม> - Roblox'
    - หา title ไม่ได้ / อ่านไม่ได้ → False (ไม่ฆ่า เดี๋ยวพลาด)
    """
    wins = _window_titles_of(pid)
    if not wins:
        return False
    wins.sort(key=lambda x: (x[0], x[1]), reverse=True)
    title = (wins[0][2] or "").strip().lower()
    if not title:
        return False
    return title in HOME_TITLES


def get_main_title(pid):
    """คืน title ของหน้าต่างหลัก (ใช้ debug/แสดงผล)"""
    wins = _window_titles_of(pid)
    if not wins:
        return ""
    wins.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return wins[0][2] or ""


def window_snapshot(pidset):
    """EnumWindows รอบเดียวสำหรับหลาย PID → {pid: (title_lower, minimized, any_visible)}
    (เดิมเรียก EnumWindows แยกต่อ PID ต่อการตรวจ = บัญชี x หน้าต่างทั้งระบบ x 2 ทุกรอบ)
    title = ของหน้าต่างหลักที่ visible/ใหญ่สุด เหมือน is_on_home_screen · อ่านไม่ได้ = ''"""
    want = set(pidset)
    if not want:
        return {}
    try:
        import win32gui, win32process
    except Exception:
        return {}
    wins = {}

    def cb(h, _):
        try:
            if win32gui.GetParent(h) != 0:
                return True
            _, wpid = win32process.GetWindowThreadProcessId(h)
            if wpid not in want:
                return True
            l, t, r, b = win32gui.GetWindowRect(h)
            wins.setdefault(wpid, []).append((
                bool(win32gui.IsWindowVisible(h)), max(1, r - l) * max(1, b - t),
                win32gui.GetWindowText(h) or "", bool(win32gui.IsIconic(h))))
        except Exception:
            pass
        return True

    try:
        win32gui.EnumWindows(cb, None)
    except Exception:
        return {}
    out = {}
    for pid, ws in wins.items():
        ws.sort(key=lambda x: (x[0], x[1]), reverse=True)
        # (title, minimized, any_visible) — any_visible=False = ซ่อนอยู่ (เช่น ถาดระบบ)
        out[pid] = ((ws[0][2] or "").strip().lower(), any(w[3] for w in ws),
                    any(w[0] and not w[3] for w in ws))
    return out


class Rbx:
    def __init__(s):
        s.http = httpx.AsyncClient(timeout=15, headers={"User-Agent": UA})
        s.last = 0.0
        s.lock = asyncio.Lock()
        s.mutex = None
        s.event = None
        s.mutex_reason = ""
        s._extra_event = None        # ★ เก็บ handle event ที่เปิดจากของเดิม (ห้าม close)

    # ══════════════════════════════════════════════════════════════
    #  ★★★ MULTI-INSTANCE — ไม่ต้องปิด Roblox ก่อนเปิดแอป ★★★
    # ══════════════════════════════════════════════════════════════
    def hold_mutex(s):
        """ยึด mutex + event สำหรับ multi-instance
        หลักการ:
          1. ถ้ายังไม่มี Roblox → สร้าง mutex+event ใหม่ เป็นเจ้าของ
          2. ถ้ามี Roblox รันอยู่ → เปิด handle ของเดิม (ไม่แย่ง ownership)
             และ force-signal event เดิม → instance ใหม่จะแยกออกทันที
          3. เก็บ handle ไว้ทั้ง mutex และ event จนแอปปิด → Roblox instance ใหม่
             ที่เข้ามาจะเจอ signal นี้แล้วเปิดหน้าต่างใหม่ ไม่ join กับตัวเก่า
        """
        s.mutex_reason = ""
        try:
            k32 = ctypes.WinDLL("kernel32", use_last_error=True)
            k32.CreateMutexW.restype = wintypes.HANDLE
            k32.CreateMutexW.argtypes = [wintypes.LPVOID, wintypes.BOOL, wintypes.LPCWSTR]
            k32.CreateEventW.restype = wintypes.HANDLE
            k32.CreateEventW.argtypes = [wintypes.LPVOID, wintypes.BOOL, wintypes.BOOL,
                                         wintypes.LPCWSTR]
            k32.OpenEventW.restype = wintypes.HANDLE
            k32.OpenEventW.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.LPCWSTR]
            k32.SetEvent.restype = wintypes.BOOL
            k32.SetEvent.argtypes = [wintypes.HANDLE]

            n_rbx = _count_roblox()
            ERROR_ALREADY_EXISTS = 183
            EVENT_MODIFY_STATE = 0x0002

            # ── Mutex ─────────────────────────────────────────────
            # ไม่มี Roblox → เป็นเจ้าของ mutex ใหม่ (bInitialOwner=True)
            # มี Roblox   → เปิด handle ของเดิม (bInitialOwner=False ไม่แย่ง)
            ctypes.set_last_error(0)
            s.mutex = k32.CreateMutexW(None, n_rbx == 0, "ROBLOX_singletonMutex")
            err_m = ctypes.get_last_error()

            # ── Event ★★★ หัวใจของ multi-instance ★★★ ───────────
            # bManualReset = True
            # bInitialState = TRUE ← signaled ตั้งแต่แรกสร้าง
            ctypes.set_last_error(0)
            s.event = k32.CreateEventW(None, True, True, "ROBLOX_singletonEvent")
            err_e = ctypes.get_last_error()

            existed = (err_m == ERROR_ALREADY_EXISTS or err_e == ERROR_ALREADY_EXISTS)

            # ── ★ KEY FIX: force-signal event เดิมถ้ามี Roblox รันอยู่ ──
            if existed and n_rbx > 0:
                try:
                    ev = k32.OpenEventW(EVENT_MODIFY_STATE, False, "ROBLOX_singletonEvent")
                    if ev:
                        k32.SetEvent(ev)
                        s._extra_event = ev     # เก็บ handle ไว้ (ห้าม close)
                except Exception:
                    pass

            if existed and n_rbx > 0:
                s.mutex_reason = (
                    f"ยึด mutex+event สำเร็จ · พบ Roblox {n_rbx} ตัวรันอยู่ "
                    f"(ไม่ต้องปิด) — instance ใหม่จะแยกออกทันที"
                )
            elif existed:
                s.mutex_reason = "mutex/event ค้างจากรอบก่อน — P4NG ยึดไว้ให้แล้ว"
            else:
                s.mutex_reason = "สร้าง mutex+event ใหม่ (P4NG ถือ) — พร้อม multi-instance"
            return True

        except Exception as e:
            s.mutex_reason = f"ctypes error: {e}"
            try:
                import win32event
                s.mutex = win32event.CreateMutex(None, False, "ROBLOX_singletonMutex")
                s.event = win32event.CreateEvent(None, True, True, "ROBLOX_singletonEvent")
                return True
            except Exception:
                return False

    async def req(s, method, url, cookie=None, csrf_retry=True, **kw):
        async with s.lock:
            w = s.last + random.uniform(.6, 1.4) - time.time()
            if w > 0:
                await asyncio.sleep(w)
            s.last = time.time()

        h = kw.pop("headers", {})
        if cookie:
            h["Cookie"] = f".ROBLOSECURITY={cookie}"

        for i in range(3):
            if (method.upper() == "POST"
                    and "content" not in kw
                    and "json" not in kw
                    and "data" not in kw):
                kw["json"] = {}

            r = await s.http.request(method, url, headers=h, **kw)
            s.http.cookies.clear()

            if r.status_code == 429:
                await asyncio.sleep(2 ** (i + 2) + random.random())
                continue

            if (r.status_code == 403 and csrf_retry
                    and "x-csrf-token" in r.headers
                    and "X-CSRF-TOKEN" not in h):
                h["X-CSRF-TOKEN"] = r.headers["x-csrf-token"]
                continue

            return r

        raise RbxError("โดน rate limit (429)")

    async def me(s, ck):
        r = await s.req("GET", "https://users.roblox.com/v1/users/authenticated", ck)
        if r.status_code != 200:
            raise RbxError("cookie หมดอายุหรือไม่ถูกต้อง")
        return r.json()

    async def check_account(s, ck, uid):
        out = {"cookie": None, "banned": None}
        if ck:
            try:
                r = await s.req("GET", "https://users.roblox.com/v1/users/authenticated", ck)
                if r.status_code == 200:
                    out["cookie"] = True
                elif r.status_code == 401:
                    out["cookie"] = False
            except Exception:
                pass
        if uid:
            try:
                r = await s.req("GET", f"https://users.roblox.com/v1/users/{uid}")
                if r.status_code == 200:
                    out["banned"] = bool(r.json().get("isBanned"))
            except Exception:
                pass
        return out

    async def ticket(s, ck):
        last_err = None
        for attempt in range(3):
            try:
                r = await s.req(
                    "POST", "https://auth.roblox.com/v1/authentication-ticket", ck,
                    headers={
                        "Referer": "https://www.roblox.com/",
                        "Origin": "https://www.roblox.com",
                        "Content-Type": "application/json",
                    },
                )
                t = r.headers.get("rbx-authentication-ticket")
                if t:
                    return t

                if r.status_code in (429, 502, 503, 504):
                    last_err = RbxError(f"Roblox ไม่ตอบสนอง (HTTP {r.status_code}) — ลองใหม่")
                    await asyncio.sleep(2 ** attempt + random.random())
                    continue

                if r.status_code == 401:
                    raise RbxError("cookie หมดอายุ — เพิ่มบัญชีใหม่ที่หน้าบัญชี")
                if r.status_code == 403:
                    raise RbxError("CSRF token ไม่ผ่าน — ลองใหม่อีกครั้ง")
                if r.status_code == 415:
                    raise RbxError("HTTP 415 — Roblox ปฏิเสธรูปแบบ request")
                raise RbxError(f"ขอ ticket ไม่ได้ (HTTP {r.status_code}) — cookie อาจหมดอายุ")
            except RbxError:
                raise
            except Exception as e:
                last_err = RbxError(str(e))
                if attempt < 2:
                    await asyncio.sleep(2 ** attempt)
        raise last_err or RbxError("ขอ ticket ไม่สำเร็จหลังลอง 3 ครั้ง")

    async def presence(s, ck, uid):
        r = await s.req("POST", "https://presence.roblox.com/v1/presence/users",
                        ck, json={"userIds": [uid]})
        return r.json()["userPresences"][0] if r.status_code == 200 else None

    def launch_uri(s, ticket, place, link="", follow_id=0):
        bid = random.randint(10 ** 10, 10 ** 11 - 1)
        if follow_id:
            url = ("https://assetgame.roblox.com/game/PlaceLauncher.ashx?request=RequestFollowUser"
                   f"&browserTrackerId={bid}&userId={int(follow_id)}")
        else:
            req = f"RequestPrivateGame&linkCode={link}" if link else "RequestGame"
            url = (f"https://assetgame.roblox.com/game/PlaceLauncher.ashx?request={req}"
                   f"&browserTrackerId={bid}&placeId={place}&isPlayTogetherGame=false")
        return (f"roblox-player:1+launchmode:play+gameinfo:{ticket}"
                f"+launchtime:{int(time.time() * 1000)}"
                f"+placelauncherurl:{urllib.parse.quote(url, safe='')}"
                f"+browsertrackerid:{bid}"
                "+robloxLocale:en_us+gameLocale:en_us+channel:+LaunchExp:InApp")

    async def quick_begin(s):
        r = await s.req("POST",
                        "https://apis.roblox.com/auth-token-service/v1/login/create")
        return r.json()

    async def quick_finish(s, d, timeout=180):
        end = time.time() + timeout
        while time.time() < end:
            r = await s.req(
                "POST", "https://apis.roblox.com/auth-token-service/v1/login/status",
                json={"code": d["code"], "privateKey": d["privateKey"]},
            )
            if r.json().get("status") == "Validated":
                break
            await asyncio.sleep(3)
        else:
            raise RbxError("หมดเวลา Quick Login")

        r = await s.req(
            "POST", "https://auth.roblox.com/v2/login",
            json={"ctype": "AuthToken", "cvalue": d["code"], "password": d["privateKey"]},
        )
        ck = r.cookies.get(".ROBLOSECURITY")
        if not ck:
            for sc in r.headers.get_list("set-cookie"):
                m = re.search(r"\.ROBLOSECURITY=([^;]+)", sc)
                if m:
                    ck = m.group(1)
                    break
        if not ck:
            raise RbxError("Quick Login ไม่ได้ cookie")
        return ck

    async def login_password(s, username, password):
        try:
            headers = {
                "Content-Type": "application/json",
                "Referer": "https://www.roblox.com/login",
                "Origin": "https://www.roblox.com",
            }
            payload = {"ctype": "Username", "cvalue": username, "password": password}
            r = await s.req("POST", "https://auth.roblox.com/v2/login",
                            headers=headers, json=payload, csrf_retry=True)
            return s._parse_login_response(r)
        except RbxError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    async def login_2fa(s, ticket, code):
        try:
            headers = {
                "Content-Type": "application/json",
                "Referer": "https://www.roblox.com/login",
                "Origin": "https://www.roblox.com",
            }
            payload = {"actionType": "Login", "code": str(code), "ticket": ticket}
            r = await s.req(
                "POST", "https://auth.roblox.com/v2/two-step-verification/login",
                headers=headers, json=payload, csrf_retry=True)
            return s._parse_login_response(r)
        except RbxError as e:
            return {"ok": False, "error": str(e)}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    async def resolve_user(s, username):
        r = await s.req("POST", "https://users.roblox.com/v1/usernames/users",
                        json={"usernames": [username], "excludeBannedUsers": False})
        d = (r.json().get("data") or []) if r.status_code == 200 else []
        if not d:
            raise RbxError(f"ไม่พบผู้ใช้ {username}")
        return {"id": d[0]["id"], "name": d[0]["name"]}


    async def game_info(s, place_id):
        try:
            r = await s.req("GET",
                f"https://apis.roblox.com/universes/v1/places/{int(place_id)}/universe")
            if r.status_code != 200:
                return {"ok": False, "error": f"ไม่พบ place {place_id}"}
            uni_id = r.json().get("universeId")
            if not uni_id:
                return {"ok": False, "error": "ไม่พบ universe"}

            r2 = await s.req("GET",
                f"https://games.roblox.com/v1/games?universeIds={uni_id}")
            if r2.status_code != 200:
                return {"ok": False, "error": "ดึงข้อมูลเกมไม่ได้"}
            data = r2.json().get("data") or []
            if not data:
                return {"ok": False, "error": "ไม่พบข้อมูลเกม"}
            g = data[0]

            r3 = await s.req("GET",
                f"https://thumbnails.roblox.com/v1/games/icons"
                f"?universeIds={uni_id}&size=256x256&format=Png&isCircular=false")
            icon = ""
            if r3.status_code == 200:
                d = r3.json().get("data") or []
                if d:
                    icon = d[0].get("imageUrl", "")

            banner = ""                                   # ภาพหน้าเกมแนวนอน (ถ้าดึงไม่ได้ UI จะใช้ icon เบลอแทน)
            try:
                r4 = await s.req("GET",
                    f"https://thumbnails.roblox.com/v1/games/multiget/thumbnails"
                    f"?universeIds={uni_id}&countPerUniverse=1&defaults=true"
                    f"&size=768x432&format=Png&isCircular=false")
                if r4.status_code == 200:
                    d = r4.json().get("data") or []
                    th = (d[0].get("thumbnails") or []) if d else []
                    if th:
                        banner = th[0].get("imageUrl", "")
            except Exception:
                pass

            return {
                "ok": True,
                "place_id": int(place_id),
                "banner": banner,
                "universe_id": uni_id,
                "name": g.get("name", ""),
                "icon": icon,
                "creator": (g.get("creator") or {}).get("name", ""),
                "playing": g.get("playing", 0),
                "visits": g.get("visits", 0),
            }
        except Exception as e:
            return {"ok": False, "error": str(e)}

    async def avatar_url(s, user_id):
        try:
            r = await s.req("GET",
                f"https://thumbnails.roblox.com/v1/users/avatar-headshot"
                f"?userIds={int(user_id)}&size=150x150&format=Png&isCircular=true")
            if r.status_code == 200:
                d = r.json().get("data") or []
                if d:
                    return d[0].get("imageUrl", "")
        except Exception:
            pass
        return ""

    def _parse_login_response(s, r):
        if r.status_code == 200:
            ck = r.cookies.get(".ROBLOSECURITY")
            if not ck:
                for sc in r.headers.get_list("set-cookie"):
                    m = re.search(r"\.ROBLOSECURITY=([^;]+)", sc)
                    if m:
                        ck = m.group(1)
                        break
            if ck:
                return {"ok": True, "cookie": ck}
            return {"ok": False, "error": "ไม่ได้รับ cookie"}
        if r.status_code == 429:
            return {"ok": False, "error": "โดน rate limit — รอสักครู่แล้วลองใหม่"}
        try:
            d = r.json()
        except Exception:
            d = {}
        tsd = d.get("twoStepVerificationData") or {}
        if tsd.get("ticket"):
            return {"ok": False, "need_2fa": True,
                    "ticket": tsd["ticket"],
                    "mediaType": tsd.get("mediaType", "Email")}
        errs = d.get("errors") or []
        if errs:
            code = errs[0].get("code", 0)
            msg = errs[0].get("message", "")
            if code == 1:
                return {"ok": False, "error": "username หรือ password ไม่ถูกต้อง"}
            if code == 2:
                return {"ok": False, "error": "บัญชีโดน rate limit — รอ 1-2 นาที"}
            if code == 5:
                return {"ok": False, "error": "บัญชีถูกล็อก — ไปปลดล็อกที่ roblox.com ก่อน"}
            if code == 6:
                return {"ok": False, "error": "บัญชีนี้โดน CAPTCHA — ใช้ Cookie แทน"}
            return {"ok": False, "error": f"{msg} (code {code})"}
        return {"ok": False, "error": f"login ล้มเหลว (HTTP {r.status_code})"}


_PID_LOCK = threading.Lock()
_PID_CACHE = {"t": 0.0, "rbx": set(), "other": set()}
_FULL_SCAN_EVERY = 10.0     # วินาที — Windows รีไซเคิล PID เร็ว จึงต้องสแกนเต็มแก้แคชเป็นระยะ


def _name_of(pid):
    try:
        return (psutil.Process(pid).name() or "").lower()
    except psutil.Error:
        return None


def pids(full=False):
    """PID ของ RobloxPlayerBeta ทั้งหมด

    เดิมวน process_iter(['name']) ทุกโปรเซสในเครื่องทุกครั้ง (sweep ทุก 5 วิ + wait_new_pid ทุก 0.5 วิ)
    ตอนนี้: psutil.pids() (เบา) แล้วอ่านชื่อเฉพาะ PID ที่เพิ่งโผล่มา · PID ที่รู้ว่าเป็น Roblox ตรวจชื่อซ้ำ
    (กันถูก reuse) · สแกนเต็มทุก _FULL_SCAN_EVERY วิ หรือเมื่อ full=True
    """
    with _PID_LOCK:
        c, now = _PID_CACHE, time.time()
        cur = set(psutil.pids())
        if full or now - c["t"] > _FULL_SCAN_EVERY:
            rbx = {p.pid for p in psutil.process_iter(["name"])
                   if (p.info.get("name") or "").lower() == ROBLOX_MAIN}
            c.update(t=now, rbx=rbx, other=cur - rbx)
            return set(rbx)
        rbx = {pid for pid in c["rbx"] & cur if _name_of(pid) == ROBLOX_MAIN}
        other = c["other"] & cur
        for pid in cur - other - rbx:                 # PID ใหม่ที่ยังไม่เคยจัดกลุ่ม
            n = _name_of(pid)
            if n == ROBLOX_MAIN:
                rbx.add(pid)
            elif n is not None:
                other.add(pid)
        c["rbx"], c["other"] = rbx, other
        return set(rbx)


async def wait_new_pid(before, timeout=45):
    end = time.time() + timeout
    n = 0
    while time.time() < end:
        n += 1
        for pid in (pids(full=(n % 6 == 0)) - before):      # สแกนเต็มทุก ~3 วิ กัน PID reuse
            try:
                p = psutil.Process(pid)
                if (p.name() or "").lower() == ROBLOX_MAIN:
                    return pid
            except psutil.Error:
                continue
        await asyncio.sleep(.5)
    raise RbxError("Roblox ไม่เปิดภายในเวลาที่กำหนด")


def _set_xml(txt, tag, name, val):
    pat = re.compile(rf'(<{tag} name="{name}">)[^<]*(</{tag}>)')
    if pat.search(txt):
        return pat.sub(lambda m: f"{m.group(1)}{val}{m.group(2)}", txt, count=1)
    return txt.replace("</Properties>",
                       f'<{tag} name="{name}">{val}</{tag}></Properties>', 1)


def write_settings(fps, quality):
    if not SETTINGS.exists():
        raise RbxError("ไม่พบ GlobalBasicSettings_13.xml — เปิด Roblox ปกติหนึ่งครั้งก่อน")
    txt = SETTINGS.read_text("utf-8")
    for tag, name, val in (("int", "FramerateCap", fps),
                           ("int", "GraphicsQualityLevel", quality),
                           ("token", "SavedQualityLevel", quality)):
        txt = _set_xml(txt, tag, name, val)
    tmp = SETTINGS.with_suffix(".tmp")
    tmp.write_text(txt, "utf-8")
    tmp.replace(SETTINGS)

# ══════════════════════════════════════════════════════════════
#  ★ NEW: ตรวจว่า Roblox หน้าต่างย่ออยู่หรือไม่
# ══════════════════════════════════════════════════════════════
def is_minimized(pid):
    """True ถ้าหน้าต่างหลักของ PID นี้ย่ออยู่"""
    try:
        import win32gui, win32process
    except Exception:
        return False

    found = [False]

    def cb(h, _):
        if win32gui.GetParent(h) != 0:
            return True
        try:
            _, wpid = win32process.GetWindowThreadProcessId(h)
        except Exception:
            return True
        if wpid != pid:
            return True
        if win32gui.IsIconic(h):
            found[0] = True
            return False
        return True

    try:
        win32gui.EnumWindows(cb, None)
    except Exception:
        pass
    return found[0]

