"""Overlay แจ้งเตือนมุมขวาล่างจอ (หน้าต่าง pywebview แยก · always-on-top · ไม่แย่งโฟกัส)

★ FIX #12: ดึง HWND จาก pywebview โดยตรง แทน FindWindowW(ชื่อ) — กันชนกับหน้าต่างชื่อเดียวกัน
"""
import ctypes, json, sys, threading, time

TITLE = "P4NG Overlay"
W, PAD, ROW, GAP, FOOT, RADIUS = 364, 1, 96, 0, 0, 16
MAX_VISIBLE = 3
MAX_QUEUE = 50
TTL = {"drop": 9.0, "join": 6.0, "test": 6.0}

GWL_EXSTYLE = -20
WS_EX_TOOLWINDOW, WS_EX_NOACTIVATE, WS_EX_APPWINDOW = 0x80, 0x08000000, 0x40000
HWND_TOPMOST = -1
SWP_NOACTIVATE, SWP_FRAMECHANGED, SWP_SHOWWINDOW = 0x10, 0x20, 0x40
SW_HIDE = 0
SPI_GETWORKAREA = 0x30
DWMWA_WINDOW_CORNER_PREFERENCE, DWMWA_BORDER_COLOR = 33, 34
DWMWCP_ROUND = 2
BORDER_RGB = (0x2F, 0x2F, 0x37)

_IS_WIN = sys.platform == "win32"
if _IS_WIN:
    from ctypes import wintypes
    _u = ctypes.windll.user32
    _g = ctypes.windll.gdi32
    _u.FindWindowW.restype = wintypes.HWND
    _u.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    _u.GetWindowLongW.restype = ctypes.c_long
    _u.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
    _u.SetWindowLongW.restype = ctypes.c_long
    _u.SetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
    _u.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                ctypes.c_int, ctypes.c_int, wintypes.UINT]
    _u.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    _u.SetWindowRgn.argtypes = [wintypes.HWND, wintypes.HANDLE, wintypes.BOOL]
    _u.SystemParametersInfoW.argtypes = [wintypes.UINT, wintypes.UINT,
                                         ctypes.c_void_p, wintypes.UINT]
    _g.CreateRoundRectRgn.restype = wintypes.HANDLE
    _g.CreateRoundRectRgn.argtypes = [ctypes.c_int] * 6
    try:
        _dwm = ctypes.windll.dwmapi
        _dwm.DwmSetWindowAttribute.argtypes = [wintypes.HWND, wintypes.DWORD,
                                               ctypes.c_void_p, wintypes.DWORD]
        _dwm.DwmSetWindowAttribute.restype = ctypes.c_long
    except Exception:
        _dwm = None


def _scale():
    try:
        return max(1.0, _u.GetDpiForSystem() / 96.0)
    except Exception:
        return 1.0


class _JsApi:
    def __init__(s, ov):
        s._ov = ov

    def dismiss(s, id):
        s._ov.dismiss(id)
        return True


class Overlay:
    def __init__(s, app):
        s.app = app
        s.win = None
        s.lock = threading.Lock()
        s.items = []
        s.cur_n = 0
        s.dwm = False
        s.ready = False
        s.hwnd = 0
        s.shown = False
        s.last = None
        s.dirty = False
        s.stopped = False
        s._seq = 0

    def js_api(s):
        return _JsApi(s)

    def attach(s, win):
        s.win = win
        win.events.loaded += s._on_loaded
        threading.Thread(target=s._loop, daemon=True).start()

    def _on_loaded(s):
        s.ready = True
        # ★ FIX #12: ตอนนี้ native พร้อมแล้ว — ดึง HWND ตรง ๆ จาก pywebview
        if not s.hwnd:
            try:
                n = s.win.native
                h = None
                if hasattr(n, "Handle"):
                    h = n.Handle
                elif hasattr(n, "_handle"):
                    h = n._handle
                if h is not None:
                    s.hwnd = int(h)
            except Exception:
                pass

    def close(s):
        s.stopped = True
        try:
            if s.win:
                s.win.destroy()
        except Exception:
            pass

    def push(s, kind, name, avatar="", text=""):
        with s.lock:
            s._seq += 1
            s.items.append({"id": s._seq, "kind": kind, "name": name, "avatar": avatar,
                            "text": text, "ttl": TTL.get(kind, 6.0), "exp": None})
            if len(s.items) > MAX_QUEUE:
                del s.items[MAX_VISIBLE]
            s.dirty = True

    def dismiss(s, id):
        with s.lock:
            n = len(s.items)
            s.items = [i for i in s.items if i["id"] != id]
            if len(s.items) != n:
                s.dirty = True

    def _enabled(s):
        return bool(s.app.cfg.data.get("notify_overlay", True))

    def _loop(s):
        while not s.stopped:
            time.sleep(0.2)
            if not s.ready:
                continue
            try:
                now = time.time()
                with s.lock:
                    n = len(s.items)
                    if not s._enabled():
                        s.items = []
                    else:
                        s.items = [i for i in s.items if i["exp"] is None or i["exp"] > now]
                        for i in s.items[:MAX_VISIBLE]:
                            if i["exp"] is None:
                                i["exp"] = now + i["ttl"]
                                s.dirty = True
                    changed = s.dirty or len(s.items) != n
                    s.dirty = False
                if changed:
                    s._render(now)
            except Exception as e:
                try:
                    s.app.log("WARN", "overlay", f"render ไม่สำเร็จ: {e}")
                except Exception:
                    pass

    def _render(s, now):
        with s.lock:
            items = list(s.items)
        vis = items[:MAX_VISIBLE]
        if not vis:
            s.last = {"items": []}
            s._js(s.last)
            if s.shown:
                time.sleep(0.3)
            s._hide()
            s.cur_n = 0
            return
        cfg = s.app.cfg.data
        s.last = {
            "accent": cfg.get("accent", "#9d7bff"),
            "accent2": cfg.get("accent_2", "#7f5ce6"),
            "items": [{"id": i["id"], "kind": i["kind"], "name": i["name"],
                       "avatar": i["avatar"], "text": i["text"]} for i in vis],
        }
        h = PAD * 2 + len(vis) * ROW
        first = not s.shown
        if s.shown and len(vis) < s.cur_n:
            s._js(s.last)
            time.sleep(0.55)
            s._place(h)
        else:
            s._place(h)
            s._js(s.last)
        s.cur_n = len(vis)
        if first:
            time.sleep(0.25)
            s._js(s.last)
            s._check(len(vis))

    def _js(s, payload):
        payload = dict(payload, dwm=s.dwm)
        try:
            s.win.evaluate_js("window.P4 && P4.render(%s)"
                              % json.dumps(payload, ensure_ascii=False))
        except Exception:
            pass

    def _find(s):
        if not _IS_WIN:
            return 0
        # ★ FIX #12: ถ้าได้ HWND จาก pywebview แล้ว ไม่ต้อง FindWindow
        if not s.hwnd:
            s.hwnd = _u.FindWindowW(None, TITLE) or 0
        if s.hwnd:
            ex = _u.GetWindowLongW(s.hwnd, GWL_EXSTYLE)
            ex = (ex | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE) & ~WS_EX_APPWINDOW
            _u.SetWindowLongW(s.hwnd, GWL_EXSTYLE, ex)
            s._dwm_style()
        return s.hwnd

    def _dwm_style(s):
        s.dwm = False
        if not (_IS_WIN and _dwm and s.hwnd):
            return
        try:
            pref = ctypes.c_int(DWMWCP_ROUND)
            ok1 = _dwm.DwmSetWindowAttribute(
                s.hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, ctypes.byref(pref), 4) == 0
            r, g, b = BORDER_RGB
            col = ctypes.c_uint(r | (g << 8) | (b << 16))
            ok2 = _dwm.DwmSetWindowAttribute(
                s.hwnd, DWMWA_BORDER_COLOR, ctypes.byref(col), 4) == 0
            s.dwm = bool(ok1 and ok2)
        except Exception:
            s.dwm = False
        try:
            _u.SetWindowRgn(s.hwnd, None, True)
        except Exception:
            pass

    def _place(s, h_css):
        hwnd = s._find()
        if not s.shown:
            try:
                s.win.show()
            except Exception as e:
                s.app.log("WARN", "overlay", f"show ไม่สำเร็จ: {e}")
            s.shown = True
            hwnd = s._find()
        if not hwnd:
            return
        sc = _scale()
        w, h = int(W * sc), int(h_css * sc)
        wa = wintypes.RECT()
        _u.SystemParametersInfoW(SPI_GETWORKAREA, 0, ctypes.byref(wa), 0)
        m = int(16 * sc)
        x, y = wa.right - w - m, wa.bottom - h - m
        _u.SetWindowPos(hwnd, HWND_TOPMOST, x, y, w, h,
                        SWP_NOACTIVATE | SWP_FRAMECHANGED | SWP_SHOWWINDOW)

    def _hide(s):
        if s.shown:
            try:
                s.win.hide()
            except Exception:
                if _IS_WIN and s.hwnd:
                    _u.ShowWindow(s.hwnd, SW_HIDE)
        s.shown = False

    def _check(s, want):
        try:
            n = s.win.evaluate_js("document.querySelectorAll('.row').length")
            if n != want:
                s.app.log("WARN", "overlay",
                          f"การ์ดที่วาด {n} ≠ {want} (P4 พร้อม: "
                          f"{s.win.evaluate_js('typeof window.P4')})")
        except Exception as e:
            s.app.log("WARN", "overlay", f"ตรวจหน้า overlay ไม่ได้: {e}")