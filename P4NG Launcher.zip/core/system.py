import ctypes
import math
import time
from ctypes import wintypes

PROF = {
    "Ultra Low":   (0x40,   True,  1),
    "Balanced":    (0x4000, False, 3),
    "Performance": (0x20,   False, 8),
}

MIN_W = 160
MIN_H = 90
# ค่าเริ่มต้นของตารางหน้าต่าง (ผู้ใช้ปรับได้ที่ ตั้งค่า → หน้าต่าง Roblox)
GRID_COLS = 8
GRID_ROWS = 6
CELL_W = 200
CELL_H = 150
OVERFLOW_STEP = 28      # บัญชีที่เกินจำนวนช่อง: วนกลับไปช่องแรกแล้วเหลื่อมลงมุมทแยงเท่านี้ px


def _main_window_of(pid):
    import win32gui, win32process, win32con
    out = []

    def cb(h, _):
        if not win32gui.IsWindowVisible(h):
            return
        if win32gui.GetParent(h) != 0:
            return
        style = win32gui.GetWindowLong(h, win32con.GWL_STYLE)
        cap = bool(style & win32con.WS_CAPTION)
        try:
            _, wpid = win32process.GetWindowThreadProcessId(h)
        except Exception:
            return
        if wpid != pid:
            return
        try:
            l, t, r, b = win32gui.GetWindowRect(h)
            w, hgt = r - l, b - t
            if w < 100 or hgt < 100:
                return
        except Exception:
            return
        out.append((cap, w * hgt, h))

    win32gui.EnumWindows(cb, None)
    if not out:
        return None
    return max(out, key=lambda x: (x[0], x[1]))[2]


hwnd_of = _main_window_of


def _in_place(h, x, y, w, hh):
    """True ถ้าหน้าต่างอยู่ตำแหน่ง/ขนาดเป้าหมายอยู่แล้ว (เทียบกรอบที่เห็นจริงของ DWM) → ไม่ต้อง SetWindowPos ซ้ำ"""
    import win32gui
    try:
        if win32gui.IsIconic(h):
            return False
        r = wintypes.RECT()
        if ctypes.windll.dwmapi.DwmGetWindowAttribute(
                wintypes.HWND(h), 9, ctypes.byref(r), ctypes.sizeof(r)) != 0:
            return False
        return (abs(r.left - x) <= 1 and abs(r.top - y) <= 1
                and abs((r.right - r.left) - w) <= 1 and abs((r.bottom - r.top) - hh) <= 1)
    except Exception:
        return False


def _place(h, x, y, w, hh):
    """★ FIX #14: sleep สั้น ๆ หลัง ShowWindow เพื่อให้ DWM คำนวณ frame ก่อนวัด offset"""
    import win32gui, win32con
    if _in_place(h, x, y, w, hh):
        return True
    flags = win32con.SWP_NOACTIVATE | win32con.SWP_SHOWWINDOW
    try:
        win32gui.ShowWindow(h, win32con.SW_RESTORE)
        win32gui.SetWindowPos(h, win32con.HWND_TOP, x, y, w, hh, flags)
        time.sleep(0.015)
        r = wintypes.RECT()
        if ctypes.windll.dwmapi.DwmGetWindowAttribute(
                wintypes.HWND(h), 9, ctypes.byref(r), ctypes.sizeof(r)) == 0:
            l, t, rr, b = win32gui.GetWindowRect(h)
            dl, dt, dr, db = r.left - l, r.top - t, rr - r.right, b - r.bottom
            if dl or dt or dr or db:
                win32gui.SetWindowPos(h, win32con.HWND_TOP,
                                      x - dl, y - dt, w + dl + dr, hh + dt + db,
                                      flags)
        return True
    except Exception:
        return False


def minimize(pids):
    """ย่อหน้าต่าง Roblox ของ pid ที่ให้มา (ไม่ปิดเกม) · คืนจำนวนที่ย่อได้"""
    import win32gui, win32con
    n = 0
    for pid in pids:
        try:
            for h in _main_window_of(pid):
                if not win32gui.IsIconic(h):
                    win32gui.ShowWindow(h, win32con.SW_SHOWMINNOACTIVE)
                n += 1
                break
        except Exception:
            pass
    return n


def arrange(pids, cols=GRID_COLS, rows=GRID_ROWS, cell_w=CELL_W, cell_h=CELL_H, monitor=0):
    """จัดหน้าต่าง Roblox เป็นตาราง (โหมดเดียว)

    - บัญชีลำดับแรกอยู่มุมซ้ายบนของพื้นที่ทำงานเสมอ แล้วเรียงซ้าย→ขวา, บน→ล่าง
    - ขนาดช่อง = cell_w x cell_h (px) ตามที่ตั้งค่า · ถ้าตารางที่ใช้จริงกว้าง/สูงเกินจอ จะย่อทุกช่องตามสัดส่วนให้พอดี
    - ถ้าบัญชีมากกว่า cols*rows ช่อง จะวนกลับไปช่องแรกแล้วเหลื่อมลงมุมทแยงทีละ OVERFLOW_STEP px
    """
    import win32api

    n = len(pids)
    if n == 0:
        return 0
    cols = max(1, int(cols or GRID_COLS))
    rows = max(1, int(rows or GRID_ROWS))
    cell_w = max(MIN_W, int(cell_w or CELL_W))
    cell_h = max(MIN_H, int(cell_h or CELL_H))

    ms = win32api.EnumDisplayMonitors()
    if not ms:
        return 0
    mi = win32api.GetMonitorInfo(ms[min(max(0, int(monitor or 0)), len(ms) - 1)][0])
    L, T, R, B = mi["Work"]
    W, H = R - L, B - T

    cap = cols * rows
    used_cols = min(cols, n)
    used_rows = min(rows, math.ceil(n / cols))
    layers = (n - 1) // cap
    need_w = used_cols * cell_w + layers * OVERFLOW_STEP
    need_h = used_rows * cell_h + layers * OVERFLOW_STEP
    k = min(1.0, W / need_w, H / need_h)
    cw, ch = max(MIN_W, int(cell_w * k)), max(MIN_H, int(cell_h * k))

    placed = 0
    for i, pid in enumerate(pids):
        h = _main_window_of(pid)
        if not h:
            continue
        layer, slot = divmod(i, cap)
        r, c = divmod(slot, cols)
        x = L + c * cw + layer * OVERFLOW_STEP
        y = T + r * ch + layer * OVERFLOW_STEP
        placed += _place(h, x, y, cw, ch)
    return placed


def optimize(pid, profile):
    import psutil
    prio, eco, _ = PROF.get(profile, PROF["Balanced"])
    try:
        psutil.Process(pid).nice(prio)
    except Exception:
        pass
    if eco:
        _eco(pid)


def _eco(pid):
    class ST(ctypes.Structure):
        _fields_ = [("Version", wintypes.ULONG),
                    ("ControlMask", wintypes.ULONG),
                    ("StateMask", wintypes.ULONG)]

    k = ctypes.windll.kernel32
    h = k.OpenProcess(0x0200, False, pid)
    if h:
        try:
            s = ST(1, 1, 1)
            k.SetProcessInformation(h, 4, ctypes.byref(s), ctypes.sizeof(s))
        finally:
            k.CloseHandle(h)


def trim(pid):
    k = ctypes.windll.kernel32
    h = k.OpenProcess(0x0100 | 0x0400, False, pid)
    if h:
        try:
            ctypes.windll.psapi.EmptyWorkingSet(h)
        finally:
            k.CloseHandle(h)