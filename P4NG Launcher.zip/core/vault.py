import json, os
from argon2.low_level import hash_secret_raw, Type
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

# รหัสฝังในโค้ด — ใช้เพื่อปลดล็อก vault แบบ local use
# (ใครได้ไฟล์ vault.enc ไป + อ่านซอร์สก็ถอดได้ — ยอมรับความเสี่ยงนี้)
AUTO_PW = "__p4ng_auto__"


class Vault:
    """vault.enc = salt(16) + nonce(12) + AES-GCM(json)
    key = Argon2id(AUTO_PW)
    """
    def __init__(s, path):
        s.path = path
        s.key = None
        s.salt = b""
        s.data = {}

    def _key(s, pw, salt):
        return hash_secret_raw(pw.encode(), salt, time_cost=3, memory_cost=65536,
                               parallelism=2, hash_len=32, type=Type.ID)

    def unlock(s, pw):
        if s.path.exists():
            raw = s.path.read_bytes()
            if len(raw) < 29:
                return False
            salt, nonce, ct = raw[:16], raw[16:28], raw[28:]
            key = s._key(pw, salt)
            try:
                s.data = json.loads(AESGCM(key).decrypt(nonce, ct, None))
            except (InvalidTag, ValueError):
                return False
            s.key, s.salt = key, salt
        else:
            s.salt = os.urandom(16)
            s.key = s._key(pw, s.salt)
            s.data = {}
            s.flush()
        return True


    def flush(s):
        if s.key is None:
            raise RuntimeError("vault ยังไม่ปลดล็อก — เปิดแอปใหม่/ปลดล็อกก่อนเพิ่มบัญชี")
        nonce = os.urandom(12)
        ct = AESGCM(s.key).encrypt(nonce, json.dumps(s.data).encode(), None)
        tmp = s.path.with_suffix(".tmp")
        tmp.write_bytes(s.salt + nonce + ct)
        os.replace(tmp, s.path)