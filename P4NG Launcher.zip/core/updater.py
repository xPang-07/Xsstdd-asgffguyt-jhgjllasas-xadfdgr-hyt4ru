"""ระบบอัปเดตจาก GitHub Releases

ลำดับ:  check() → download() → apply() (เปิดตัวช่วยแยกกระบวนการ แล้วปิดแอปให้ตัวช่วยเขียนไฟล์ทับ + เปิดใหม่)
- ไฟล์ข้อมูลผู้ใช้ (%APPDATA%\\P4NG Launcher) ไม่ถูกแตะ · โหมด portable: โฟลเดอร์ data/ + portable.txt ถูกข้าม
- ดาวน์โหลดเฉพาะจากโดเมนของ GitHub · ตรวจ sha256 เมื่อ GitHub ให้ค่ามา · กัน zip-slip
"""
import hashlib, os, re, shutil, subprocess, sys, zipfile
from pathlib import Path

import httpx

from .config import DATA, BASE
from .version import VERSION, UPDATE_REPO, UPDATE_TOKEN

UPD = DATA / "update"
UA = f"P4NG-Launcher/{VERSION}"
ALLOWED_HOSTS = ("github.com", "githubusercontent.com")
MAX_BYTES = 200 * 1024 * 1024
_NOWIN = 0x08000000 if os.name == "nt" else 0
_DETACH = (0x00000008 | 0x00000200) if os.name == "nt" else 0       # DETACHED_PROCESS | NEW_PROCESS_GROUP

_last = {}          # ผลตรวจล่าสุด


def parse_ver(v):
    """'v1.2.3-beta' → (1,2,3) · อ่านไม่ได้ → None"""
    m = re.match(r"^\s*v?(\d+)(?:\.(\d+))?(?:\.(\d+))?", str(v or ""))
    return tuple(int(x or 0) for x in m.groups()) if m else None


def _host_ok(url):
    try:
        h = httpx.URL(str(url)).host.lower()
    except Exception:
        return False
    return any(h == d or h.endswith("." + d) for d in ALLOWED_HOSTS)


def _token():
    """token อ่าน-อย่างเดียวสำหรับ repo private: ไฟล์ DATA/update_token.txt ก่อน แล้วค่อยค่าในโค้ด"""
    try:
        t = (DATA / "update_token.txt").read_text(encoding="utf-8").strip()
        if t:
            return t
    except OSError:
        pass
    return (UPDATE_TOKEN or "").strip()


def _hdr(accept):
    h = {"Accept": accept, "User-Agent": UA}
    t = _token()
    if t:
        h["Authorization"] = f"Bearer {t}"
        h["X-GitHub-Api-Version"] = "2022-11-28"
    return h


def info():
    return {"version": VERSION, "repo": UPDATE_REPO, "configured": "/" in UPDATE_REPO and UPDATE_REPO != "OWNER/REPO",
            "portable": (BASE / "portable.txt").exists(), "private": bool(_token())}


def check():
    """ถาม GitHub ว่ามีเวอร์ชันใหม่กว่าไหม → {ok, newer, current, latest, notes, page, asset?} หรือ {ok:False, error}"""
    cur = {"current": VERSION}
    if not info()["configured"]:
        return {"ok": False, "error": "ยังไม่ได้ตั้ง UPDATE_REPO ใน core/version.py", **cur}
    try:
        r = httpx.get(f"https://api.github.com/repos/{UPDATE_REPO}/releases/latest",
                      headers=_hdr("application/vnd.github+json"),
                      timeout=12, follow_redirects=True)
    except httpx.HTTPError as e:
        return {"ok": False, "error": f"เชื่อมต่อ GitHub ไม่ได้: {type(e).__name__}", **cur}
    if r.status_code == 401:
        return {"ok": False, "error": "token ไม่ถูกต้องหรือหมดอายุ", **cur}
    if r.status_code == 404:
        hint = "token ไม่มีสิทธิ์เข้า repo นี้" if _token() else "ถ้าเป็น repo private ต้องใส่ token"
        return {"ok": False, "error": f"ไม่พบ Release (repo ผิด/ยังไม่ได้ปล่อยเวอร์ชันแรก · {hint})", **cur}
    if r.status_code != 200:
        return {"ok": False, "error": f"GitHub ตอบ {r.status_code}", **cur}
    try:
        j = r.json()
    except ValueError:
        return {"ok": False, "error": "อ่านคำตอบจาก GitHub ไม่ได้", **cur}

    tag = str(j.get("tag_name") or "")
    lv, cv = parse_ver(tag), parse_ver(VERSION)
    if not lv:
        return {"ok": False, "error": f"tag “{tag}” ไม่ใช่เลขเวอร์ชัน", **cur}
    asset = None
    for a in j.get("assets") or []:
        if str(a.get("name", "")).lower().endswith(".zip"):
            d = str(a.get("digest") or "")
            asset = {"name": a["name"], "url": a.get("browser_download_url"), "api_url": a.get("url"),
                     "size": a.get("size") or 0,
                     "sha256": d.split(":", 1)[1].lower() if d.startswith("sha256:") else ""}
            break
    out = {"ok": True, "current": VERSION, "latest": tag.lstrip("vV"), "newer": bool(cv and lv > cv),
           "notes": str(j.get("body") or "")[:1500], "page": j.get("html_url") or "", "asset": asset}
    _last.clear(); _last.update(out)
    return out


def _safe_extract(zf, dest):
    root = dest.resolve()
    for m in zf.infolist():
        p = (dest / m.filename).resolve()
        if p != root and root not in p.parents:
            raise ValueError(f"ไฟล์ใน zip มี path ผิดปกติ: {m.filename}")
    zf.extractall(dest)


def _find_root(d):
    for p in [d, *sorted(x for x in d.iterdir() if x.is_dir())]:
        if (p / "main.py").is_file() and (p / "core").is_dir():
            return p
    return None


def download():
    """โหลด + ตรวจ + แตก zip ไว้ที่ DATA/update/staging → {ok, staging} / {ok:False,error}"""
    a = _last.get("asset")
    if not (_last.get("newer") and a and a.get("url")):
        return {"ok": False, "error": "ไม่มีไฟล์อัปเดตให้โหลด (Release ต้องแนบไฟล์ .zip)"}
    # มี token → ต้องโหลดผ่าน API (asset url) · ไม่มี → ลิงก์ดาวน์โหลดสาธารณะ
    dl = a.get("api_url") if _token() and a.get("api_url") else a["url"]
    if not _host_ok(dl):
        return {"ok": False, "error": "ลิงก์ดาวน์โหลดไม่ได้อยู่บน GitHub"}
    shutil.rmtree(UPD, ignore_errors=True)
    UPD.mkdir(parents=True, exist_ok=True)
    pkg, staging = UPD / "pkg.zip", UPD / "staging"
    h, n = hashlib.sha256(), 0
    try:
        # httpx ตัด Authorization ทิ้งเองเมื่อ redirect ไปโดเมนอื่น (ลิงก์ที่เซ็นแล้วของ githubusercontent)
        with httpx.stream("GET", dl, headers=_hdr("application/octet-stream"), timeout=30, follow_redirects=True) as r:
            if r.status_code != 200:
                return {"ok": False, "error": f"โหลดไม่สำเร็จ ({r.status_code})"}
            if not _host_ok(r.url):
                return {"ok": False, "error": "ถูก redirect ไปนอก GitHub — ยกเลิก"}
            with open(pkg, "wb") as f:
                for chunk in r.iter_bytes(65536):
                    n += len(chunk)
                    if n > MAX_BYTES:
                        return {"ok": False, "error": "ไฟล์ใหญ่ผิดปกติ — ยกเลิก"}
                    h.update(chunk); f.write(chunk)
    except httpx.HTTPError as e:
        return {"ok": False, "error": f"โหลดไม่สำเร็จ: {type(e).__name__}"}
    if a.get("sha256") and h.hexdigest() != a["sha256"]:
        return {"ok": False, "error": "sha256 ไม่ตรงกับที่ GitHub แจ้ง — ยกเลิก"}
    try:
        with zipfile.ZipFile(pkg) as zf:
            _safe_extract(zf, staging)
    except (zipfile.BadZipFile, ValueError) as e:
        return {"ok": False, "error": f"zip ใช้ไม่ได้: {e}"}
    root = _find_root(staging)
    if not root:
        return {"ok": False, "error": "ใน zip ไม่พบ main.py + core/ (ไม่ใช่แพ็กเกจแอป)"}
    return {"ok": True, "staging": str(root)}


def apply(staging):
    """เปิดตัวช่วย (แยกกระบวนการ) ให้รอแอปปิด → สำรอง+เขียนทับ → เปิดใหม่ · เรียกแล้วต้องปิดแอปทันที"""
    helper = UPD / "apply_update.py"
    shutil.copy2(Path(__file__).with_name("apply_update.py"), helper)
    main_py = Path(sys.argv[0]).resolve()
    cmd = [sys.executable, str(helper), str(os.getpid()), staging, str(BASE), sys.executable, str(main_py), str(UPD)]
    subprocess.Popen(cmd, cwd=str(UPD), creationflags=_NOWIN | _DETACH, close_fds=True,
                     stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return True
