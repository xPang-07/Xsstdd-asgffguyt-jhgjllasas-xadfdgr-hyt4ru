import re, time, collections, threading
from .config import LOGS

KEEP_DAYS = 7
RED = [re.compile(r"_\|WARNING:-DO-NOT-SHARE[^\s\"']+"), re.compile(r"(?i)(ROBLOSECURITY=)[^;\s]+"),
       re.compile(r"(?i)(ticket[\"':= ]+)[A-Za-z0-9+/=_-]{20,}")]


def redact(m):
    for r in RED:
        m = r.sub(lambda x: (x.group(1) + "***") if x.lastindex else "***", m)
    return m


def _prune():
    cut = time.time() - KEEP_DAYS * 86400
    for f in LOGS.glob("p4ng-*.log"):
        try:
            if f.stat().st_mtime < cut:
                f.unlink()
        except OSError:
            pass


class Logger:
    def __init__(s):
        s.buf = collections.deque(maxlen=500)
        s.lock = threading.Lock()
        s.n = 0
        s._day = ""
        s._fh = None
        _prune()

    def _file(s):
        day = time.strftime("%Y%m%d")
        if day != s._day or s._fh is None:
            if s._fh:
                s._fh.close()
            s._fh = open(LOGS / f"p4ng-{day}.log", "a", encoding="utf-8", buffering=1)
            s._day = day
        return s._fh

    def __call__(s, level, tag, msg):
        with s.lock:
            s.n += 1
            e = {"i": s.n, "t": time.strftime("%H:%M:%S"), "l": level, "tag": tag, "m": redact(str(msg))}
            s.buf.append(e)
            try:
                s._file().write(f"{e['t']} {level} [{tag}] {e['m']}\n")
            except OSError:
                s._fh = None

    def tail(s, n=200):
        with s.lock:
            return list(s.buf)[-n:]

    def since(s, i):
        """เฉพาะ log ที่ใหม่กว่า index i (ให้ UI ดึงแบบ delta)"""
        with s.lock:
            return [e for e in s.buf if e["i"] > i]
