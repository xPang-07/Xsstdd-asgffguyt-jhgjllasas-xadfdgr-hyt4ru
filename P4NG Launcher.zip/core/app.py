import asyncio, json, os, threading, time, zlib
from dataclasses import dataclass, field
import psutil
from .config import Store, DEFAULTS, DATA
from .log import Logger
from .vault import Vault
from .roblox import (Rbx, pids, wait_new_pid, write_settings,
                     kill_all_roblox, _count_roblox, is_on_home_screen,
                     is_minimized, window_snapshot, HOME_TITLES, ROBLOX_MAIN)
from .queue_engine import Queue, Fatal, Cancelled
from . import heartbeat, system as S


OK = {
    "IDLE": {"QUEUED"},
    "QUEUED": {"AUTHENTICATING"},
    "AUTHENTICATING": {"LAUNCHING", "QUEUED"},
    "LAUNCHING": {"LOADING", "IN_GAME", "RECONNECTING", "QUEUED"},
    "LOADING": {"IN_GAME", "RECONNECTING", "QUEUED"},
    "IN_GAME": {"RECONNECTING"},
    "RECONNECTING": {"QUEUED", "COOLDOWN"},
    "COOLDOWN": {"QUEUED"},
    "ERROR": {"QUEUED"},
}
PERSIST = ("id", "name", "user_id", "fps", "auto", "place_id", "link",
           "avatar_url", "join_friend", "auto_exec", "script_override", "pinned")


def dur(sec):
    """ระยะเวลาแบบอ่านง่าย: 45 วิ · 3 นาที 12 วิ · 1 ชม. 5 นาที"""
    sec = int(max(0, sec))
    if sec < 60:
        return f"{sec} วิ"
    if sec < 3600:
        return f"{sec // 60} นาที {sec % 60} วิ"
    return f"{sec // 3600} ชม. {sec % 3600 // 60} นาที"


@dataclass
class Acct:
    id: int
    name: str
    user_id: int = 0
    fps: int | None = None
    auto: bool = True
    place_id: int = 0
    link: str = ""
    avatar_url: str = ""
    join_friend: str = ""
    active: bool = False
    state: str = "IDLE"
    reason: str = "ยังไม่ได้เปิด"
    since: float = field(default_factory=time.time)
    pid: int = 0
    cpu: float = 0
    ram: float = 0
    rc: list = field(default_factory=list)
    stop_req: bool = False
    joined: bool = False
    gen: int = 0
    last_beat: float = 0.0
    desc: str = ""
    health: str = ""
    # ★ NEW — auto-exec script
    auto_exec: bool = True
    script_override: str = ""
    pinned: bool = False                          # ปักหมุด/ติดดาว — แสดงไว้บนสุดของรายการ


def _migrate(raw):
    raw.pop("mode", None)                         # ไม่มีระบบโหมดแล้ว — ทุกบัญชีตั้งค่าได้ครบเหมือนกัน
    if "auto" not in raw:
        raw["auto"] = True
    if "auto_exec" not in raw:
        raw["auto_exec"] = True
    if "script_override" not in raw:
        raw["script_override"] = ""
    return raw


class App:
    def __init__(s):
        s.log = Logger()
        s.cfg = Store("settings.json", DEFAULTS)
        if s.cfg.data.get("schema", 0) < 4:       # v4: เหลือโหมดจัดหน้าต่างเดียว (grid เริ่มซ้ายบน) → เก็บเป็นการตั้งค่า
            s.cfg.data.pop("layout", None)
            s.cfg.data.update(grid_cols=8, grid_rows=6, cell_w=200, cell_h=150, schema=4)
            s.cfg.save()
        if s.cfg.data.get("schema", 0) < 5:       # v5: รวมตัวเลือก kill orphan เป็นสวิตช์เดียว auto_clean
            d = s.cfg.data
            d["auto_clean"] = bool(d.get("kill_stale_home", True) or d.get("kill_minimized_orphans", True))
            for k in ("kill_stale_home", "stale_home_secs", "kill_minimized_orphans", "orphan_scan_interval"):
                d.pop(k, None)
            d["schema"] = 5
            s.cfg.save()
        if s.cfg.data.get("schema", 0) < 6:       # v6: ยกเลิกโหมด ฟาร์ม/ปกติ · เหลือ quality กราฟิกค่าเดียว (เดิมฟาร์ม = 1)
            d = s.cfg.data
            for k in ("mode", "normal_quality"):
                d.pop(k, None)
            d["quality"] = 1
            d["schema"] = 6
            s.cfg.save()
        s.store = Store("accounts.json", {"accounts": []})
        s._save_lock = threading.RLock()
        s._save_timer = None
        s.vault = Vault(DATA / "vault.enc")
        s.lock = threading.RLock()
        s.rc = 0
        s._unk_beat = {}
        s.notifier = None

        for k in ("probe", "stale"):
            s.cfg.data.pop(k, None)

        s.accts = {}
        for raw in s.store.data["accounts"]:
            raw = _migrate(dict(raw))
            keep = {k: raw[k] for k in PERSIST if k in raw}
            s.accts[raw["id"]] = Acct(**keep)

        s.rbx = Rbx()
        s.rbx_ready = s.rbx.hold_mutex()

        if s.rbx_ready:
            s.log("INFO", "core", f"multi-instance: {s.rbx.mutex_reason}")
        else:
            s.log("WARN", "core", f"multi-instance ไม่พร้อม: {s.rbx.mutex_reason}")

        s.loop = asyncio.new_event_loop()
        s.q = Queue(s)
        s._exec_launched = False
        s._health_busy = False
        s._health_lock = threading.Lock()
        s._procs = {}

        s._spawned = set()
        s._home_seen = {}
        s._sweep_stop = threading.Event()

        threading.Thread(target=s._run, daemon=True).start()
        s.api_port = heartbeat.start(s)
        threading.Thread(target=s._prefetch_avatars, daemon=True).start()
        threading.Thread(target=s._sweep_loop, daemon=True,
                         name="p4ng-sweep").start()
        s.log("INFO", "core", f"P4NG Core พร้อมทำงาน · {len(s.accts)} บัญชี · Place {s.cfg.data.get('place_id') or 'ยังไม่ตั้ง'}"
              f" · FPS {s.cfg.data.get('fps')} · เว้นช่วง {s.cfg.data.get('dmin')}–{s.cfg.data.get('dmax')} วิ")

    def _run(s):
        asyncio.set_event_loop(s.loop)
        s.loop.create_task(s.q.run())
        s.loop.run_forever()

    def call(s, coro, timeout=60):
        return asyncio.run_coroutine_threadsafe(coro, s.loop).result(timeout)

    def tr(s, a, new, reason):
        with s.lock:
            if (new != a.state and new not in OK.get(a.state, ())
                    and new not in ("IDLE", "ERROR")):
                s.log("WARN", "state", f"{a.name}: {a.state}→{new} ไม่อนุญาต ({reason})")
                return False
            old, spent = a.state, time.time() - (a.since or time.time())
            if new != a.state:
                a.since = time.time()
            a.state, a.reason = new, reason
        if new == old:
            msg = f"{new} · {reason}"
        else:
            msg = f"{old} → {new} · {reason}"
            if old == "IN_GAME":
                msg += f" · อยู่ในเกมมา {dur(spent)}"
            elif old in ("AUTHENTICATING", "LAUNCHING", "LOADING") and new != "ERROR":
                msg += f" · ขั้น {old} ใช้ {dur(spent)}"
        s.log("ERROR" if new == "ERROR"
              else "WARN" if new == "COOLDOWN"
              else "INFO", a.name, msg)
        return True

    def fps(s, a):
        return a.fps if a.fps is not None else s.cfg.data["fps"]

    def save_accounts(s, now=False):
        """เขียน accounts.json — รวมการเรียกที่ติดกันเป็นครั้งเดียว (debounce 0.4 วิ)
        now=True = เขียนทันที (ใช้ตอนปิดแอป) · ข้อมูลในหน่วยความจำอัปเดตทันทีเสมอ"""
        with s._save_lock:
            if now:
                if s._save_timer:
                    s._save_timer.cancel()
                    s._save_timer = None
                s._write_accounts()
                return
            if s._save_timer:
                return                                # มีรอบเขียนรออยู่แล้ว จะเก็บค่าล่าสุดตอนเขียน
            s._save_timer = threading.Timer(0.4, s._flush_accounts)
            s._save_timer.daemon = True
            s._save_timer.start()

    def flush_pending(s):
        """ตอนปิดแอป: เขียนเฉพาะเมื่อมีรอบ debounce ค้างอยู่ (กันเขียนทับไฟล์ด้วยรายการว่างถ้าโหลดบัญชียังไม่เสร็จ)"""
        with s._save_lock:
            if s._save_timer:
                s._save_timer.cancel()
                s._save_timer = None
                s._write_accounts()

    def _flush_accounts(s):
        with s._save_lock:
            s._save_timer = None
            s._write_accounts()

    def _write_accounts(s):
        with s.lock:
            s.store.data["accounts"] = [{k: getattr(a, k) for k in PERSIST}
                                        for a in s.accts.values()]
        s.store.save()

    def _prefetch_avatars(s):
        time.sleep(2)
        got = False
        for a in list(s.accts.values()):
            if not a.avatar_url and a.user_id:
                try:
                    url = s.call(s.rbx.avatar_url(a.user_id), 20)
                    if url:
                        a.avatar_url = url
                        got = True
                except Exception:
                    pass
        if got:
            s.save_accounts()                    # เซฟครั้งเดียวหลังดึงครบ (เดิมเขียนไฟล์ทุกบัญชี)

    # ══════════════════════════════════════════════════════════
    #  Sweep service
    # ══════════════════════════════════════════════════════════
    def _track_pid(s, pid):
        if pid:
            with s.lock:
                s._spawned.add(pid)

    def _untrack_pid(s, pid):
        with s.lock:
            s._spawned.discard(pid)
            s._home_seen.pop(pid, None)

    def _kill_pid(s, pid, why):
        try:
            p = psutil.Process(pid)
            if (p.name() or "").lower() != ROBLOX_MAIN:
                s._untrack_pid(pid)
                return
            for c in p.children(recursive=True):
                try:
                    c.kill()
                except Exception:
                    pass
            p.kill()
            s.log("WARN", "sweep", f"ลบ Roblox PID {pid} — {why}")
        except psutil.NoSuchProcess:
            pass
        except Exception as e:
            s.log("WARN", "sweep", f"kill PID {pid} ไม่สำเร็จ: {e}")
        s._untrack_pid(pid)

    # ตรวจ Roblox ที่ตกค้าง — ผู้ใช้ตั้งได้แค่เปิด/ปิด (auto_clean) ค่าที่เหลือเป็นค่าคงที่
    SWEEP_EVERY = 5.0     # วินาทีระหว่างรอบสแกน (1 วิ ระหว่างรอยืนยันหน้า Home)
    HOME_GRACE = 60       # วินาทีที่ค้างหน้า Home ระหว่างโหลดเกมได้ก่อนถูกปิด
    HOME_NOW = 2.0        # ต้องเห็น Home ติดกันกี่วินาที (กันกระพริบ) ก่อน end task
    HIDDEN_SECS = 10.0    # Roblox ไม่ผูกบัญชี + ไม่มีหน้าต่างที่มองเห็น (ซ่อนในถาด) ต่อเนื่องกี่วินาที → end task
    HIDDEN_MIN_AGE = 20.0 # อายุ process ขั้นต่ำ (กันฆ่าตัวที่เพิ่งเปิดและยังไม่สร้างหน้าต่าง)
    BEAT_LOST = 25.0      # IN_GAME ที่เงียบเกินนี้ + เห็นหน้า Home → end task

    def _sweep(s):
        """สแกนทุก SWEEP_EVERY วิ:
          1. ล้าง PID ซ้ำระหว่างบัญชี · ฆ่า orphan ที่แอปเปิดเองแต่ไม่มีบัญชีผูกอยู่
          2. (auto_clean) ฆ่า Roblox ที่ย่ออยู่ + ไม่ผูกบัญชี / ค้างหน้า Home / ไม่ใช่ของแอป
          3. IN_GAME ที่ heartbeat หาย + กลับหน้า Home → end task + เชื่อมใหม่/ปิดตามโหมด
        EnumWindows ทำรอบเดียวต่อสแกน และ "ข้ามเลย" เมื่อทุกบัญชีมี heartbeat ปกติ
        คืน True ถ้ามีหน้าต่างที่กำลังรอยืนยัน Home (ให้ loop สแกนถี่ขึ้น)"""
        live = pids()
        clean = bool(s.cfg.data.get("auto_clean", True))
        with s.lock:
            s._spawned &= live
            spawned = set(s._spawned)
            tracked = set()
            by_pid = {}
            seen = set()
            for a in s.accts.values():
                if not a.pid:
                    continue
                if a.pid in seen:                     # PID ซ้ำ 2 บัญชี
                    s.log("WARN", "sweep", f"PID {a.pid} ผูก 2 บัญชี — ล้างออกจาก {a.name}")
                    a.pid = 0
                    continue
                seen.add(a.pid)
                by_pid[a.pid] = a
                if a.active and a.state in ("LAUNCHING", "LOADING", "IN_GAME", "RECONNECTING"):
                    tracked.add(a.pid)
            home_seen = s._home_seen
            hid_seen = s.__dict__.setdefault("_hid_seen", {})

        if not clean:
            for pid in live:
                if pid in spawned and pid not in tracked:
                    s._kill_pid(pid, "orphan (ไม่มีบัญชีผูกอยู่)")
            for k in [k for k in home_seen if k not in live]:
                home_seen.pop(k, None)
            return False

        now = time.time()
        # เลือกเฉพาะ PID ที่ "ต้องดูหน้าต่าง" จริง ๆ
        need = set()
        for pid in live:
            if pid in tracked:
                a = by_pid.get(pid)
                if not a:
                    continue
                if a.state in ("LAUNCHING", "LOADING") or (
                        a.state == "IN_GAME" and a.last_beat and now - a.last_beat > s.BEAT_LOST):
                    need.add(pid)
            elif pid not in spawned:
                need.add(pid)
        snap = window_snapshot(need) if need else {}
        pending = False

        def home(pid):
            t = snap.get(pid)
            return bool(t and t[0] in HOME_TITLES)

        def home_for(pid, secs):
            """True เมื่อเห็นหน้า Home ต่อเนื่องครบ secs วินาที"""
            nonlocal pending
            if not home(pid):
                home_seen.pop(pid, None)
                return False
            first = home_seen.setdefault(pid, now)
            if now - first >= secs:
                return True
            pending = True
            return False

        for pid in live:
            if pid in tracked:
                a = by_pid.get(pid)
                if not a:
                    home_seen.pop(pid, None)
                    continue
                if a.state in ("LAUNCHING", "LOADING"):
                    if home_for(pid, s.HOME_GRACE):
                        secs = int(now - home_seen.get(pid, now))
                        s.log("WARN", "sweep", f"{a.name} ค้างหน้า Home {secs} วิ → end task")
                        s._drop(a, f"ค้างหน้า Home {secs} วิ (ไม่ได้เข้าเกม)")
                    continue
                if a.state == "IN_GAME":
                    lost = bool(a.last_beat) and now - a.last_beat > s.BEAT_LOST
                    if lost and home_for(pid, s.HOME_NOW):
                        secs = int(now - a.last_beat)
                        s.log("WARN", "sweep", f"{a.name} กลับหน้า Home (ไม่มี heartbeat {secs} วิ) → end task")
                        s._drop(a, f"หลุดกลับหน้า Home (ไม่มี heartbeat {secs} วิ)")
                    elif not lost:
                        home_seen.pop(pid, None)
                    continue
                home_seen.pop(pid, None)
                continue
            if pid in spawned:                       # orphan ที่แอปเปิดเอง
                s._kill_pid(pid, "orphan (ไม่มีบัญชีผูกอยู่)")
                continue
            t = snap.get(pid)                         # ไม่ผูกบัญชี (ผู้ใช้เปิดเอง)
            if t and t[1]:
                s._kill_pid(pid, "หน้าต่างย่อ + ไม่ผูกบัญชี")
            elif home_for(pid, s.HOME_NOW):
                s._kill_pid(pid, "หน้า Home (ไม่ได้อยู่ใน place ใด ๆ)")
            elif not (t and t[2]):
                # ไม่มีหน้าต่างที่มองเห็นเลย (ซ่อนอยู่ในถาดระบบ / ไม่มีหน้าต่าง) → ดูไม่ได้ว่าอยู่ Home
                # จึงนับเวลาเอง · ถ้าครบ HIDDEN_SECS ต่อเนื่อง และ process เก่าพอ → end task
                first = hid_seen.setdefault(pid, now)
                if now - first >= s.HIDDEN_SECS:
                    try:
                        age = now - psutil.Process(pid).create_time()
                    except psutil.Error:
                        age = 0.0
                    if age >= s.HIDDEN_MIN_AGE:
                        s._kill_pid(pid, f"ซ่อนอยู่ในถาด/ไม่มีหน้าต่าง {int(now - first)} วิ + ไม่ผูกบัญชี")
                        hid_seen.pop(pid, None)
                else:
                    pending = True
            else:
                hid_seen.pop(pid, None)

        for k in [k for k in home_seen if k not in live]:
            home_seen.pop(k, None)
        for k in [k for k in hid_seen if k not in live or k in tracked]:
            hid_seen.pop(k, None)
        return pending

    def _drop(s, a, why):
        try:
            s.loop.call_soon_threadsafe(s.on_dead, a, why)
        except RuntimeError:
            pass

    def _sweep_loop(s):
        wait = s.SWEEP_EVERY
        while not s._sweep_stop.wait(wait):
            try:
                pending = s._sweep()
                wait = 1.0 if pending else s.SWEEP_EVERY
            except Exception as e:
                s.log("WARN", "sweep", f"ตรวจ orphan ไม่สำเร็จ: {e}")


    # ══════════════════════════════════════════════════════════
    #  ★ NEW — Kill Orphans (เรียกจากปุ่ม UI)
    # ══════════════════════════════════════════════════════════
    def kill_orphans_now(s):
        live = pids()
        tracked = {a.pid for a in s.accts.values()
                   if a.pid and a.active
                   and a.state in ("LAUNCHING", "LOADING", "IN_GAME", "RECONNECTING")}

        killed = 0
        for pid in live:
            if pid in tracked:
                continue
            s._kill_pid(pid, "kill_orphans_now (ปุ่ม Kill)")
            killed += 1

        s.log("WARN", "sweep", f"Kill Now: ปิด {killed} instances")
        return {"ok": True, "killed": killed}

    def roblox_instances(s):
        from .roblox import get_main_title
        out = []
        for pid in pids():
            try:
                p = psutil.Process(pid)
                acct = next((a for a in s.accts.values() if a.pid == pid), None)
                out.append({
                    "pid": pid,
                    "title": get_main_title(pid) or "",
                    "home": is_on_home_screen(pid),
                    "minimized": is_minimized(pid),
                    "account": acct.name if acct else None,
                    "state": acct.state if acct else "ORPHAN",
                    "ram_mb": round(p.memory_info().rss / 1048576, 1),
                })
            except Exception:
                pass
        return {"ok": True, "instances": out}

    # ══════════════════════════════════════════════════════════
    #  ★ NEW — Auto-Exec Script
    # ══════════════════════════════════════════════════════════
    def get_script_for(s, user_id: int) -> str:
        if not user_id:
            return ""
        a = next((x for x in s.accts.values() if x.user_id == user_id), None)
        if not a:
            return ""
        if a.script_override:
            return a.script_override
        if not a.auto_exec:
            return ""
        if not s.cfg.data.get("auto_exec_enabled", True):
            return ""
        return s.cfg.data.get("auto_exec_script", "") or ""

    # ── lifecycle ───────────────────────────────────────────
    def notify(s, kind, name, avatar="", text=""):
        cb = s.notifier
        if not cb or not s.cfg.data.get("notify_overlay", True):
            return False
        try:
            cb(kind, name, avatar or "", text or "")
            return True
        except Exception as e:
            s.log("WARN", "notify", f"แจ้งเตือนไม่สำเร็จ: {e}")
            return False

    def _find(s, d):
        try:
            uid = int(d.get("userId") or 0)
        except (TypeError, ValueError):
            uid = 0
        name = str(d.get("username") or "").lower()
        accts = list(s.accts.values())
        return (next((a for a in accts if uid and a.user_id == uid), None)
                or next((a for a in accts if name and a.name.lower() == name), None))

    def on_beat(s, d):
        a = s._find(d)
        if not a:
            who = str(d.get("username") or d.get("userId") or "?")
            now = time.time()
            if now - s._unk_beat.get(who, 0) > 120:
                s._unk_beat[who] = now
                s.log("WARN", "api", f"ได้รับสัญญาณจาก “{who}” แต่ไม่มีบัญชีนี้ในแอป (ตรวจชื่อ/uid ของบัญชี)")
            return
        if not a.active:
            return
        a.last_beat = time.time()
        if a.state == "LAUNCHING":
            a.joined = True
        elif a.state == "LOADING":
            s._entered(a)

    def _entered(s, a):
        t0 = getattr(a, "t_launch", 0)
        s.tr(a, "IN_GAME", "api.lua แจ้งเข้าเกมแล้ว"
             + (f" · รวม {dur(time.time() - t0)} ตั้งแต่เริ่มเปิด" if t0 else "")
             + f" · PID {a.pid}")
        with s.lock:
            s._home_seen.pop(a.pid, None)

        s.notify("join", a.name, a.avatar_url, "เข้าเกมแล้ว")
        if s.cfg.data.get("auto_arrange", True):
            s.q.add("APPLY_LAYOUT", delay=0.8)
        if s.cfg.data.get("auto_minimize", False):
            s.loop.call_later(3.0 if s.cfg.data.get("auto_arrange", True) else 1.5,
                              lambda acc=a: s.minimize_account(acc))

    def minimize_account(s, a):
        """ย่อหน้าต่าง Roblox ของบัญชีที่เพิ่งเข้าเกม (ตั้งค่า auto_minimize) · เกมไม่ถูกปิด"""
        if not (a.active and a.state == "IN_GAME" and a.pid and psutil.pid_exists(a.pid)):
            return
        try:
            ok = S.minimize([a.pid])
        except Exception as e:
            s.log("WARN", "layout", f"{a.name}: ย่อหน้าต่างไม่สำเร็จ: {e}")
            return
        s.log("INFO", "layout", f"{a.name}: ย่อหน้าต่างอัตโนมัติ" if ok
              else f"{a.name}: ไม่พบหน้าต่างให้ย่อ")

    def minimize_all(s):
        """ย่อหน้าต่างทุกบัญชีที่อยู่ในเกมตอนนี้"""
        ps = [x.pid for x in s.accts.values()
              if x.state == "IN_GAME" and x.pid and psutil.pid_exists(x.pid)]
        n = S.minimize(ps) if ps else 0
        s.log("INFO", "layout", f"ย่อหน้าต่าง {n}/{len(ps)} ตัว")
        return {"ok": n > 0, "placed": n, "total": len(ps)}

    def on_drop(s, d):
        a = s._find(d)
        if not (a and a.active and a.state in ("LOADING", "IN_GAME")):
            return
        why = f"หลุดจากเกม: {str(d.get('reason') or 'Unknown')[:160]}"
        if d.get("error_code") is not None:
            why += f" (code {d['error_code']})"
        s.on_dead(a, why)

    def on_desc(s, d):
        a = s._find(d)
        if a and a.active:
            a.desc = str(d.get("desc") or "")[:160]

    def on_dead(s, a, why):
        up = f" · อยู่ในสถานะ {a.state} มา {dur(time.time() - a.since)}" if a.since else ""
        s.log("WARN", a.name, why + up + (f" · PID {a.pid}" if a.pid else ""))
        s.notify("drop", a.name, a.avatar_url, why)
        s._kill(a)
        a.gen += 1
        a.desc = ""
        a.last_beat = 0.0
        s.reconnect(a, why)

    def _watch_exit(s, a, pid, gen):
        def run():
            try:
                psutil.Process(pid).wait()
            except psutil.Error:
                pass
            try:
                s.loop.call_soon_threadsafe(s._on_exit, a.id, pid, gen)
            except RuntimeError:
                pass
        threading.Thread(target=run, daemon=True, name=f"p4ng-wait-{pid}").start()

    def _on_exit(s, acc_id, pid, gen):
        a = s.accts.get(acc_id)
        if (a and a.active and a.pid == pid and a.gen == gen
                and a.state in ("LOADING", "IN_GAME")):
            s.on_dead(a, "process Roblox ถูกปิด")

    def _load_timeout(s, acc_id, gen):
        a = s.accts.get(acc_id)
        if a and a.active and a.gen == gen and a.state == "LOADING":
            s.on_dead(a, f"ไม่ได้รับสัญญาณเข้าเกมภายใน {s.cfg.data.get('load_timeout', 120)} วิ")

    def reconnect(s, a, why):
        if not a.active:
            s.tr(a, "IDLE", f"{why} · ปิดใช้งานแล้ว")
            return
        if not (a.auto and s.cfg.data["auto"]):
            s.tr(a, "ERROR", f"{why} (auto-reconnect ปิดอยู่)")
            return
        now = time.time()
        a.rc = [t for t in a.rc if now - t < 60] + [now]
        s.rc += 1
        s.tr(a, "RECONNECTING", why)
        if len(a.rc) > s.cfg.data["maxrc"]:
            s.tr(a, "COOLDOWN",
                 f"reconnect เกิน {s.cfg.data['maxrc']} ครั้ง/นาที พัก 30 วิ")
            s.loop.call_later(
                30,
                lambda: s.q.add("REJOIN", a.id)
                if a.state == "COOLDOWN" and a.active else None
            )
            return
        s.q.add("REJOIN", a.id)

    async def handle(s, j):
        a = s.accts.get(j.acc)
        if j.type in ("LAUNCH", "REJOIN"):
            place = a.place_id or s.cfg.data.get("place_id")
            s.log("INFO", a.name,
                  f"{'เข้าเกมใหม่' if j.type == 'REJOIN' else 'เริ่มเปิดเกม'} · Place {place} · "
                  f"ครั้งที่ {j.attempts + 1}/{j.max_attempts}")
            a.t_launch = time.time()
            await s.h_launch(a)
        elif j.type == "KILL":
            await s.h_kill(a)
            s.tr(a, "IDLE", "ผู้ใช้สั่งหยุด")
        elif j.type == "APPLY_LAYOUT":
            await s.loop.run_in_executor(None, s.arrange_now, True)

    def _kill(s, a):
        pid, a.pid = a.pid, 0
        s._untrack_pid(pid)
        if not pid:
            return
        try:
            p = psutil.Process(pid)
            if (p.name() or "").lower() != ROBLOX_MAIN:
                return
            for c in p.children(recursive=True):
                try:
                    c.kill()
                except psutil.Error:
                    pass
            p.kill()
        except psutil.NoSuchProcess:
            pass
        except psutil.Error:
            pass

    async def h_kill(s, a):
        s._kill(a)

    async def h_launch(s, a):
        if not a.active:
            raise Cancelled()

        c = s.cfg.data
        if not getattr(s, "rbx_ready", True):
            raise Fatal("Multi-instance ไม่พร้อม")

        ck = s.vault.data.get(str(a.id))
        place = a.place_id or c["place_id"]
        if not ck:
            raise Fatal("บัญชีนี้ไม่มี cookie ใน vault")
        if not place:
            raise Fatal("ยังไม่ได้ตั้ง Place ID")
        if a.health in ("banned", "cookie"):
            await s._check_one(a)
            if a.health == "banned":
                raise Fatal("บัญชีนี้ถูกแบน — กด “ตรวจสถานะ” ใหม่ถ้าแก้ไขแล้ว")
            if a.health == "cookie":
                raise Fatal("cookie หมดอายุ/ใช้ไม่ได้ — เพิ่มบัญชีนี้ใหม่เพื่ออัปเดต cookie")

        follow_id = 0
        if a.join_friend:
            try:
                u = await s.rbx.resolve_user(a.join_friend)
                follow_id = u["id"]
            except Exception as e:
                s.log("WARN", a.name, f"join friend '{a.join_friend}' ไม่ได้: {e}")

        a.stop_req = False
        a.gen += 1
        gen = a.gen
        a.desc = ""
        a.last_beat = 0.0
        await s.h_kill(a)
        s.tr(a, "AUTHENTICATING", "ขอ auth ticket (rate-limited)")
        tk = await s.rbx.ticket(ck)
        if a.stop_req or not a.active:
            raise Cancelled()

        fps_val = s.fps(a)
        quality = int(c.get("quality", 1) or 1)
        prof = c.get("profile") or "Ultra Low"
        s.tr(a, "LAUNCHING", f"FPS={fps_val} · Q{quality} · {prof}")

        await s.loop.run_in_executor(
            None, write_settings, int(fps_val), int(quality))

        before = pids()
        a.joined = False
        os.startfile(s.rbx.launch_uri(tk, place, a.link, follow_id))

        s.log("INFO", a.name, "รอ Roblox เปิด process…")
        _t0 = time.time()
        a.pid = await wait_new_pid(before, timeout=30)
        s._track_pid(a.pid)
        s.log("INFO", a.name, f"Roblox เปิดแล้ว · PID {a.pid} · ใช้เวลา {dur(time.time() - _t0)}")
        if a.stop_req or not a.active:
            raise Cancelled()
        S.optimize(a.pid, prof)

        s._watch_exit(a, a.pid, gen)
        if a.joined:
            s._entered(a)
        else:
            s.tr(a, "LOADING", "รอ api.lua แจ้งเข้าเกม")
            lt = int(c.get("load_timeout", 120) or 0)
            if lt > 0:
                s.loop.call_later(lt, s._load_timeout, a.id, gen)

    def _account_rank(s):
        """ลำดับบัญชีที่ใช้จัดหน้าต่าง = ลำดับที่ผู้ใช้เห็นในหน้าบัญชี (account_order ก่อน แล้วตามด้วยที่เหลือเรียงตาม id)"""
        order = [str(x) for x in (s.cfg.data.get("account_order") or [])]
        pos = {k: n for n, k in enumerate(order)}
        return lambda a: (not a.pinned, pos.get(str(a.id), len(order)), a.id)

    def arrange_now(s, auto=False):
        """จัดหน้าต่างบัญชีที่ IN_GAME เป็นตาราง · บัญชีแรกอยู่ซ้ายบนเสมอ
        - กดเอง (auto=False): จัดทุกบัญชีที่อยู่ในเกม
        - อัตโนมัติหลังเข้าเกม (auto=True): จัดทุกบัญชีที่อยู่ในเกม"""
        live = sorted((x for x in s.accts.values()
                       if x.state == "IN_GAME" and x.pid and psutil.pid_exists(x.pid)
                       ), key=s._account_rank())
        ps = [x.pid for x in live]
        c = s.cfg.data
        if not ps:
            if not auto:
                s.log("WARN", "layout", "ยังไม่มีบัญชีที่อยู่ในเกมให้จัดหน้าต่าง")
            return {"ok": False, "error": "ยังไม่มีบัญชีที่อยู่ในเกม"}
        cols, rows = int(c.get("grid_cols", 8) or 8), int(c.get("grid_rows", 6) or 6)
        cw, ch = int(c.get("cell_w", 200) or 200), int(c.get("cell_h", 150) or 150)
        n = S.arrange(ps, cols, rows, cw, ch, int(c.get("monitor", 0)))
        s.log("INFO", "layout", f"จัดตาราง {cols}x{rows} · ช่อง {cw}x{ch}: สำเร็จ {n}/{len(ps)}")
        if n < len(ps):
            s.log("WARN", "layout", f"หาหน้าต่างไม่เจอ {len(ps) - n} ตัว")
        return {"ok": n > 0, "placed": n, "total": len(ps),
                "error": "" if n else "ไม่พบหน้าต่าง Roblox"}

    def set_password(s, i, pw):
        if not s.vault.key:
            raise RuntimeError("vault ยังไม่ปลดล็อก")
        if pw:
            s.vault.data[f"pw:{i}"] = pw
        else:
            s.vault.data.pop(f"pw:{i}", None)
        s.vault.flush()

    def credentials(s, i):
        a = s.accts.get(i)
        pw = s.vault.data.get(f"pw:{i}") if (a and s.vault.key) else None
        return (a.name, pw) if a else (None, None)

    def purge_creds(s):
        ks = [k for k in s.vault.data if str(k).startswith("cred:")]
        for k in ks:
            s.vault.data.pop(k, None)
        if ks and s.vault.key:
            s.vault.flush()

    def add_account(s, me, ck, pw=None):
        if not s.vault.key:
            raise RuntimeError("vault ยังไม่ปลดล็อก")
        for a in s.accts.values():
            if a.user_id == me["id"]:
                s.vault.data[str(a.id)] = ck
                if pw:
                    s.vault.data[f"pw:{a.id}"] = pw
                s.vault.flush()
                a.health = ""
                return f"{a.name} (อัปเดต cookie)"
        i = max(s.accts, default=0) + 1
        s.accts[i] = Acct(id=i, name=me["name"], user_id=me["id"])
        s.vault.data[str(i)] = ck
        if pw:
            s.vault.data[f"pw:{i}"] = pw
        s.vault.flush()
        s.save_accounts()
        s.log("INFO", "vault", f"เพิ่มบัญชี {me['name']}")

        def _fetch(acc_id=i, uid=me["id"]):
            try:
                url = s.call(s.rbx.avatar_url(uid), 20)
                if url:
                    s.accts[acc_id].avatar_url = url
                    s.save_accounts()
            except Exception:
                pass
        threading.Thread(target=_fetch, daemon=True).start()
        return me["name"]

    async def _check_one(s, a):
        prev = a.health if a.health != "checking" else ""
        if not s.vault.key:
            a.health = prev
            return
        ck = s.vault.data.get(str(a.id))
        try:
            res = await s.rbx.check_account(ck, a.user_id)
        except Exception as e:
            s.log("WARN", a.name, f"ตรวจสถานะไม่สำเร็จ: {e}")
            a.health = prev
            return
        if not ck:
            new = "nocookie"
        elif res["banned"]:
            new = "banned"
        elif res["cookie"] is False:
            new = "cookie"
        elif res["cookie"] is True:
            new = "ok"
        else:
            new = prev
        if new != prev and new in ("banned", "cookie", "nocookie"):
            why = {"banned": "บัญชีถูกแบน",
                   "cookie": "cookie หมดอายุ/ใช้ไม่ได้",
                   "nocookie": "ไม่มี cookie ใน vault"}[new]
            s.log("WARN", a.name, why)
        a.health = new

    def check_health(s, ids=None):
        targets = [a for a in list(s.accts.values()) if ids is None or a.id in ids]
        if not targets:
            return 0
        with s._health_lock:
            if s._health_busy:
                return -1
            s._health_busy = True
        for a in targets:
            a.health = "checking"

        def _run():
            try:
                for a in targets:
                    if a.id not in s.accts:
                        continue
                    try:
                        s.call(s._check_one(a), 45)
                    except Exception as e:
                        s.log("WARN", a.name, f"ตรวจสถานะ: {e}")
                        if a.health == "checking":
                            a.health = ""
            finally:
                with s._health_lock:
                    s._health_busy = False
        threading.Thread(target=_run, daemon=True, name="p4ng-health").start()
        return len(targets)

    def delete_account(s, i):
        a = s.accts.get(i)
        if not a:
            return {"ok": False, "error": "ไม่พบบัญชี"}
        name = a.name
        a.stop_req = True
        a.active = False
        s.q.cancel(i)
        if a.pid and psutil.pid_exists(a.pid):
            try:
                p = psutil.Process(a.pid)
                if (p.name() or "").lower() == ROBLOX_MAIN:
                    p.kill()
            except Exception:
                pass
        s._untrack_pid(a.pid)
        with s.lock:
            s.accts.pop(i, None)
            for k in (str(i), f"cred:{i}", f"pw:{i}"):
                s.vault.data.pop(k, None)
            order = s.cfg.data.get("account_order") or []
            s.cfg.data["account_order"] = [x for x in order
                                           if x != i and str(x) != str(i)]
        if s.vault.key:
            s.vault.flush()
        s.save_accounts()
        s.cfg.save()
        s.log("INFO", "core", f"ลบบัญชี {name}")
        return {"ok": True}

    def audit_vault(s):
        miss = [a.name for a in s.accts.values() if str(a.id) not in s.vault.data]
        if miss:
            s.log("WARN", "vault", f"{len(miss)} บัญชีไม่มี cookie: " + ", ".join(miss))

    def lock_vault(s):
        with s.lock:
            if s.vault.key:
                s.vault.key = None
                s.vault.data = {}
                s.log("INFO", "vault", "ล็อก vault แล้ว")
                return True
        return False

    def kill_roblox_and_reinit(s):
        for a in s.accts.values():
            if a.pid and psutil.pid_exists(a.pid):
                try:
                    p = psutil.Process(a.pid)
                    if (p.name() or "").lower() == ROBLOX_MAIN:
                        p.kill()
                except Exception:
                    pass
            a.pid = 0
            a.active = False
            if a.state in ("IN_GAME", "LOADING", "LAUNCHING",
                           "AUTHENTICATING", "RECONNECTING"):
                s.tr(a, "IDLE", "ปิด Roblox ทั้งหมด")
        n = kill_all_roblox()
        with s.lock:
            s._spawned.clear()
            s._home_seen.clear()
        s.log("WARN", "core", f"ปิด Roblox {n} ตัว")
        time.sleep(0.5)
        ok = s.rbx.hold_mutex()
        s.rbx_ready = ok
        if ok:
            s.log("INFO", "core", f"multi-instance: {s.rbx.mutex_reason}")
        else:
            s.log("WARN", "core", f"ยังไม่พร้อม: {s.rbx.mutex_reason}")
        return {"killed": n, "ok": ok, "reason": s.rbx.mutex_reason}

    def boot_cleanup(s):
        if not s.cfg.data.get("force_kill_on_boot", False):
            return {"skipped": True, "killed": 0, "ok": s.rbx_ready,
                    "reason": s.rbx.mutex_reason}
        n = _count_roblox()
        if n > 0:
            return s.kill_roblox_and_reinit()
        if not s.rbx_ready:
            s.rbx_ready = s.rbx.hold_mutex()
        return {"killed": 0, "ok": s.rbx_ready, "reason": s.rbx.mutex_reason}

    def _stats(s):
        n = psutil.cpu_count() or 1
        with s.lock:
            live = set()
            for a in s.accts.values():
                if not (a.pid and a.state == "IN_GAME"):
                    a.cpu = a.ram = 0
                    continue
                live.add(a.pid)
                try:
                    p = s._procs.get(a.pid)
                    if p is None:
                        p = s._procs[a.pid] = psutil.Process(a.pid)
                        p.cpu_percent(None)
                    a.cpu = round(max(0.0, min(100.0, p.cpu_percent(None) / n)), 1)
                    a.ram = p.memory_info().rss / 1048576
                except psutil.Error:
                    s._procs.pop(a.pid, None)
                    a.cpu = a.ram = 0
            for k in [k for k in s._procs if k not in live]:
                s._procs.pop(k, None)

    def _cfg_crc(s):
        """crc ของ settings — คำนวณใหม่เมื่อมีการ save หรือเก่ากว่า 3 วิ (เดิมคำนวณทุกครั้งที่ poll = ทุกวินาที)"""
        c, t = getattr(s, "_crc_cache", None), time.time()
        if c is None or c[0] != s.cfg.rev or t - c[2] > 3:
            c = (s.cfg.rev, zlib.crc32(json.dumps(s.cfg.data, sort_keys=True).encode("utf-8")), t)
            s._crc_cache = c
        return c[1]

    def state(s, since=0, cfg_crc=0, acc_sig=0):
        s._stats()
        q = s.q
        crc = s._cfg_crc()
        with s.lock:
            spawned_n = len(s._spawned)
            now = time.time()
            home_n = sum(1 for t in s._home_seen.values() if now - t > s.HOME_GRACE)
        accounts = [

                {"id": a.id, "name": a.name,
                 "state": a.state, "active": a.active,
                 "reason": a.reason, "since": a.since * 1000,
                 "fps": a.fps, "auto": a.auto, "cpu": round(a.cpu), "ram": round(a.ram),
                 "place_id": a.place_id, "link": a.link,
                 "avatar_url": a.avatar_url, "desc": a.desc,
                 "user_id": a.user_id, "join_friend": a.join_friend,
                 "health": a.health,
                 # ★ NEW — auto-exec
                 "auto_exec": a.auto_exec,
                 "pinned": a.pinned,
                 "has_script_override": bool(a.script_override),
                 # vault
                 "no_cookie": bool(s.vault.key) and str(a.id) not in s.vault.data,
                 "has_pw": bool(s.vault.key) and f"pw:{a.id}" in s.vault.data}
                for a in s.accts.values()
        ]
        jobs = [{
                "id": j.id, "type": j.type, "acc": j.acc,
                "pri": j.pri, "state": j.state,
                "attempts": j.attempts,
                "max_attempts": j.max_attempts,
                "nb": j.nb * 1000,
                "created_at": j.created_at * 1000,
            } for j in list(q.jobs)]
        sig = zlib.crc32(json.dumps([accounts, jobs, q.done], sort_keys=True).encode("utf-8"))
        same = sig == acc_sig                     # บัญชี/คิว/ประวัติเหมือนรอบก่อน → ไม่ส่งซ้ำ
        return {
            "accounts": None if same else accounts,
            "jobs": None if same else jobs,
            "done": None if same else q.done,
            "acc_sig": sig,
            "logs": s.log.since(since) if since else s.log.tail(200),
            "api_port": s.api_port,
            "paused": q.paused,
            "busy": q.busy,
            "next_at": q.next_at * 1000,
            "rc": s.rc,
            "cfg_crc": crc,
            "settings": s.cfg.data if crc != cfg_crc else None,
            "rbx_ready": getattr(s, "rbx_ready", True),
            "rbx_reason": s.rbx.mutex_reason,
            "spawned_count": spawned_n,
            "home_stuck_count": home_n,
        }