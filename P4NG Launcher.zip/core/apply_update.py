"""ตัวช่วยเขียนไฟล์อัปเดตทับ — รันแยกกระบวนการ (ถูกคัดลอกไป DATA/update/ ก่อนรัน เพื่อไม่ให้ตัวเองถูกเขียนทับ)
args: pid  staging  appdir  python_exe  main_py  update_dir
ใช้ไลบรารีมาตรฐานเท่านั้น (psutil ถ้ามี)
"""
import os, shutil, subprocess, sys, time
from pathlib import Path

SKIP = {"data", "portable.txt", "__pycache__", ".git", ".gitignore"}
NOWIN = 0x08000000 if os.name == "nt" else 0
DETACH = (0x00000008 | 0x00000200) if os.name == "nt" else 0


def log(msg):
    try:
        with open(UPD / "apply.log", "a", encoding="utf-8") as f:
            f.write(time.strftime("%H:%M:%S ") + msg + "\n")
    except Exception:
        pass


def wait_exit(pid, timeout=60):
    try:
        import psutil
    except Exception:
        time.sleep(6); return
    t = time.time()
    while time.time() - t < timeout and psutil.pid_exists(pid):
        time.sleep(0.4)
    time.sleep(1.0)                      # ให้ Windows ปล่อย handle ไฟล์


def files(root):
    for p in root.rglob("*"):
        rel = p.relative_to(root)
        if p.is_file() and not (set(rel.parts) & SKIP) and p.suffix != ".pyc":
            yield rel


def copy_retry(src, dst):
    for i in range(6):
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst); return
        except PermissionError:
            if i == 5: raise
            time.sleep(0.8)


def main():
    global UPD
    pid, staging, appdir, exe, main_py, upd = sys.argv[1:7]
    UPD = Path(upd); staging = Path(staging); appdir = Path(appdir)
    log(f"เริ่ม · pid={pid} staging={staging}")
    wait_exit(int(pid))
    backup = UPD / "backup"
    shutil.rmtree(backup, ignore_errors=True)
    old_req = (appdir / "requirements.txt").read_bytes() if (appdir / "requirements.txt").exists() else b""
    done = []
    try:
        for rel in files(staging):
            dst = appdir / rel
            if dst.exists():
                copy_retry(dst, backup / rel)
            done.append(rel)
            copy_retry(staging / rel, dst)
        log(f"เขียนทับ {len(done)} ไฟล์")
    except Exception as e:
        log(f"ผิดพลาด: {e!r} → ย้อนกลับ")
        for rel in done:
            b = backup / rel
            try:
                if b.exists(): copy_retry(b, appdir / rel)
            except Exception as e2:
                log(f"ย้อนกลับ {rel} ไม่ได้: {e2!r}")
    else:
        new_req = (staging / "requirements.txt").read_bytes() if (staging / "requirements.txt").exists() else b""
        if new_req and new_req != old_req:
            py = exe
            if os.name == "nt" and exe.lower().endswith("pythonw.exe") and Path(exe[:-5] + ".exe").exists():
                py = exe[:-5] + ".exe"
            try:
                subprocess.run([py, "-m", "pip", "install", "--disable-pip-version-check", "-r",
                                str(appdir / "requirements.txt")], creationflags=NOWIN, timeout=600,
                               stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                log("ติดตั้งไลบรารีใหม่แล้ว")
            except Exception as e:
                log(f"pip ไม่สำเร็จ: {e!r}")
    finally:
        shutil.rmtree(UPD / "staging", ignore_errors=True)
        try:
            (UPD / "pkg.zip").unlink()
        except OSError:
            pass
        subprocess.Popen([exe, main_py], cwd=str(appdir), creationflags=NOWIN | DETACH, close_fds=True,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        log("เปิดแอปใหม่แล้ว")


if __name__ == "__main__":
    main()
