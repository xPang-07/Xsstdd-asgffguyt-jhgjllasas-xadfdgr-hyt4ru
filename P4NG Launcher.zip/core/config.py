import json, os, shutil, sys, threading
from pathlib import Path

BASE = Path(sys.argv[0]).resolve().parent
if hasattr(sys, "_MEIPASS"):
    RES = Path(sys._MEIPASS)
else:
    RES = Path(__file__).resolve().parent.parent
    if not (RES / "ui").exists():
        RES = BASE
APP_NAME = "P4NG Launcher"


def _data_dir():
    legacy = BASE / "data"
    if os.environ.get("P4NG_PORTABLE") == "1" or (BASE / "portable.txt").exists():
        return legacy
    root = os.environ.get("APPDATA") or str(Path.home() / ".config")
    new = Path(root) / APP_NAME
    if not new.exists() and legacy.is_dir():
        try:
            shutil.copytree(legacy, new)
        except OSError:
            new.mkdir(parents=True, exist_ok=True)
    new.mkdir(parents=True, exist_ok=True)
    return new


DATA = _data_dir()
LOGS = DATA / "logs"
LOGS.mkdir(parents=True, exist_ok=True)

DEFAULTS = {
    "schema": 6,
    "fps": 30,
    "quality": 1,
    "profile": "Ultra Low",
    "dmin": 5, "dmax": 10,
    "auto": True, "maxrc": 3,
    "place_id": 0,
    "maps": [],
    "grid_cols": 8,
    "grid_rows": 6,
    "cell_w": 200,
    "cell_h": 150,
    "monitor": 0,
    "auto_arrange": True,
    "auto_minimize": False,
    "show_banner": True,
    "sound": True,
    "notify_overlay": True,
    "force_kill_on_boot": False,
    "load_timeout": 120,
    "auto_clean": True,
    "auto_exec_enabled": True,
    "auto_update_check": True,
    "auto_exec_script": "",
    "auto_exec_delay": 2,
    "accent":   "#e8456b",
    "accent_2": "#c93558",
    "account_order": [],
}


class Store:
    def __init__(s, name, default):
        s.path = DATA / name
        s.lock = threading.RLock()
        s.data = dict(default)
        s.rev = 0                       # เพิ่มทุกครั้งที่ save() — ใช้แคช crc ของ settings
        if s.path.exists():
            try:
                s.data.update(json.loads(s.path.read_text("utf-8")))
            except Exception:
                s.path.replace(s.path.with_suffix(".bak"))

    def save(s):
        with s.lock:
            s.rev += 1
            tmp = s.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(s.data, ensure_ascii=False, indent=2), "utf-8")
            os.replace(tmp, s.path)