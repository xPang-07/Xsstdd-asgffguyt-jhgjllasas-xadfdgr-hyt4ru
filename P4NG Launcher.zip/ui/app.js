/* P4NG Launcher — UI logic · ลำดับส่วนด้านล่างคือลำดับการโหลด
   kit (02c) + แถวบัญชีร่วม (06a) + ACT (12) คือแกนที่ทุกหน้าใช้ร่วมกัน */

/* ══════════════════════════════════════════════════════════════════════
   01-core
   ══════════════════════════════════════════════════════════════════════ */
/* =========================================================================
   P4NG Launcher — UI (แยกไฟล์ตามส่วน โหลดตามเลขลำดับใน index.html)
   ========================================================================= */

const DEFAULT_ACCENT = '#e8456b';
const APP_VERSION = '1.0.0';
{ const _v = document.getElementById('app-ver'); if (_v) _v.textContent = 'v' + APP_VERSION; }
const hasCore = () => typeof window.pywebview !== 'undefined' && window.pywebview.api;
const api = (m, ...a) => window.pywebview.api[m](...a);

const C = {
    IDLE: ['ว่าง', '#6d758d', false],
    QUEUED: ['รอคิว', '#f5b84b', true],
    AUTHENTICATING: ['ตรวจสิทธิ์', '#b69cff', true],
    LAUNCHING: ['กำลังเปิด', '#9d7bff', true],
    LOADING: ['โหลดเกม', '#6cc4ff', true],
    IN_GAME: ['ในเกม', '#3ddc97', false],
    RECONNECTING: ['กำลังเชื่อมใหม่', '#f5b84b', true],
    COOLDOWN: ['พักก่อน', '#7aa2c9', false],
    ERROR: ['ผิดพลาด', '#ff6b7a', false],
};

// เมนู dock — 'dash' (หน้าหลัก) อยู่กึ่งกลางเสมอ: ซ้าย 2 · ขวา 2 + ปุ่มเริ่ม/หยุดทั้งหมด
// [key, ป้ายชื่อ, ชื่อไอคอนใน ICON, ปุ่มลัด]
const NAV = [
    ['acc',     'บัญชี',       'user',     '1'],
    ['queue',   'คิว',         'queue',    '2'],
    ['dash',    'หน้าหลัก',    'home',     '3'],
    ['console', 'คอนโซล',      'console',  '4'],
    ['set',     'ตั้งค่า',     'settings', '5'],
];

const S = {
    view: 'dash', accounts: [], jobs: [], done: [], logs: [], net: true,
    paused: false, busy: false, nextAt: 0, rc: 0,
    sel: new Set(), filter: 'IMPORTANT', lp: false,
    accSig: 0,
    selMode: false, selAnchor: 0,
    set: {}, ready: false,
    accSearch: '', clearSeq: 0, logSeq: 0, cfgCrc: 0,
    rbxReady: true, rbxReason: '',
    loginMode: 'browser',
    gameCache: {},
    accFilter: 'ALL',
};

const $ = s => document.querySelector(s);
const $$ = s => document.querySelectorAll(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[c]));
const num = v => { const n = Number(v); return Number.isFinite(n) ? n : 0; };


/* ══════════════════════════════════════════════════════════════════════
   02-ui-kit
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 02-ui-kit.js — cache ข้อมูลเกม, tooltip, ธีม, toast, modal พื้นฐาน */

/* ======================================================================
   GAME INFO CACHE (persistent)
   ====================================================================== */
const GICACHE_KEY = 'p4ng.gameinfo';
const GICACHE_TTL = 7 * 24 * 60 * 60 * 1000;   // 7 วัน

function loadGameInfoCache() {
    try {
        const raw = localStorage.getItem(GICACHE_KEY);
        if (!raw) return {};
        const d = JSON.parse(raw);
        const now = Date.now();
        const out = {};
        for (const [pid, entry] of Object.entries(d)) {
            if (entry && entry.ts && (now - entry.ts) < GICACHE_TTL) {
                out[pid] = entry.data;
            }
        }
        return out;
    } catch (_) { return {}; }
}
function saveGameInfoCache(cache) {
    try {
        const d = {};
        const now = Date.now();
        for (const [pid, data] of Object.entries(cache)) {
            d[pid] = { ts: now, data };
        }
        localStorage.setItem(GICACHE_KEY, JSON.stringify(d));
    } catch (_) { }
}
function cacheGameInfo(pid, info) {
    if (!pid || !info || !info.ok) return;
    S.gameCache[pid] = info;
    saveGameInfoCache(S.gameCache);
}

/* ======================================================================
   TOOLTIP — เขียนเองไม่พึ่งไลบรารี (delegate: ทุก element ที่มี data-tip ใช้ได้เลย ทั้งที่สร้างทีหลัง)
   ====================================================================== */
(() => {
    const tip = document.createElement('div');
    tip.className = 'p4-tip';
    tip.setAttribute('role', 'tooltip');
    document.body.appendChild(tip);
    let cur = null, timer = 0;
    const hide = () => {
        clearTimeout(timer); timer = 0; cur = null;
        tip.classList.remove('on');
        tip.style.left = '-9999px';
        tip.removeAttribute('data-side');
    };
    const place = el => {
        const r = el.getBoundingClientRect(), vw = innerWidth, vh = innerHeight, M = 8;
        const tw = tip.offsetWidth, th = tip.offsetHeight;
        let x = r.left + r.width / 2 - tw / 2;
        x = Math.max(M, Math.min(x, vw - tw - M));
        let y = r.top - th - 8, below = false;
        if (y < M) { y = r.bottom + 8; below = true; }
        if (y + th > vh - M) y = Math.max(M, vh - th - M);
        tip.style.left = Math.round(x) + 'px';
        tip.style.top = Math.round(y) + 'px';
        tip.dataset.side = below ? 'bottom' : 'top';
    };
    const show = el => {
        const t = el?.dataset?.tip;
        if (!t || !el.isConnected || !el.matches(':hover')) { hide(); return; }
        tip.textContent = t;
        tip.style.left = '-9999px'; tip.style.top = '0px';
        tip.classList.add('on');
        place(el);
        if (window.gsap) gsap.fromTo(tip, { opacity: 0, y: 4, scale: .98 }, { opacity: 1, y: 0, scale: 1, duration: .16, ease: 'power2.out', overwrite: true });
    };
    document.addEventListener('mouseover', e => {
        const el = e.target.closest && e.target.closest('[data-tip]');
        if (el === cur) return;
        hide();
        if (!el || !el.dataset.tip) return;
        cur = el;
        timer = setTimeout(() => cur === el && show(el), 380);
    }, true);
    document.addEventListener('mouseout', e => {
        const el = e.target.closest && e.target.closest('[data-tip]');
        if (el && (el === cur || el.contains(cur)) && !el.contains(e.relatedTarget)) hide();
    }, true);
    // Prevent stale tips when a page rerenders/removes the hovered element.
    const tipObserver = new MutationObserver(() => { if (cur && !cur.isConnected) hide(); });
    tipObserver.observe(document.body, { childList: true, subtree: true });
    ['mousedown', 'wheel', 'keydown', 'blur'].forEach(ev => addEventListener(ev, hide, true));
    document.addEventListener('scroll', hide, true);
})();

/* ======================================================================
   THEME
   ====================================================================== */
function hexToRgb(h) {
    h = String(h).replace('#', '').trim();
    if (h.length === 3) h = h.split('').map(c => c + c).join('');
    if (h.length !== 6 || !/^[0-9a-f]{6}$/i.test(h)) return [157, 123, 255];
    return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}
function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(x =>
        Math.max(0, Math.min(255, Math.round(x))).toString(16).padStart(2, '0')
    ).join('');
}
function shade(hex, pct) {
    const [r, g, b] = hexToRgb(hex);
    const t = pct < 0 ? 0 : 255;
    const p = Math.abs(pct) / 100;
    return rgbToHex(r + (t - r) * p, g + (t - g) * p, b + (t - b) * p);
}
function hexA(hex, a) {
    const [r, g, b] = hexToRgb(hex);
    return `rgba(${r},${g},${b},${a})`;
}
const ACCENT_PRESETS = [        // [ชื่อ, สี]
    ['โรส', '#e8456b'], ['ม่วง', '#9d7bff'], ['น้ำเงิน', '#5b8cff'], ['ฟ้า', '#3cc8e6'], ['เขียว', '#3ddc97'], ['ไลม์', '#a3e635'],
    ['เหลือง', '#f5c542'], ['ส้ม', '#ff9a4d'], ['ชมพู', '#ff6fae'], ['แดง', '#ff6b7a'], ['ขาว', '#e5e7eb'],
];
function lum(hex) {
    const [r, g, b] = hexToRgb(hex).map(v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); });
    return .2126 * r + .7152 * g + .0722 * b;
}
/** นำสีที่เลือกไปใช้ทั้งแอป + อัปเดตสถานะ "เลือกอยู่" ของ swatch/ช่องกรอกทันที (ไม่ต้องออก-เข้าหน้าตั้งค่าใหม่) */
function applyAccent() {
    const a = (S.set.accent || DEFAULT_ACCENT).toLowerCase(), L = lum(a);
    const root = document.documentElement;
    root.style.setProperty('--ac', a);
    root.style.setProperty('--ac-2', shade(a, 22));
    root.style.setProperty('--on-ac', 1.05 / (L + .05) >= (L + .05) / .058 ? '#ffffff' : '#14161d');
    paintAccent(a);
}
function paintAccent(a) {
    let hit = false;
    $$('[data-accent-pick]').forEach(b => {
        const on = b.dataset.accentPick.toLowerCase() === a;
        hit = hit || on;
        b.classList.toggle('on', on);
    });
    const c = $('[data-accent-custom]');                 // ปุ่ม "กำหนดเอง" = เลือกอยู่เมื่อสีปัจจุบันไม่ตรงชุดสำเร็จรูป
    if (c) {
        c.classList.toggle('on', !hit);
        c.style.setProperty('--c', a);
        const t = c.querySelector('[data-accent-val]');
        if (t) t.textContent = a.toUpperCase();
    }
}
/** ตั้งสีหลัก (สีรองที่ overlay/หน้าเลือกเกมใช้ คำนวณให้เอง) */
function setAccent(hex) {
    S.set.accent = hex;
    S.set.accent_2 = shade(hex, -12);
    applyAccent();
    save();
}

/* ======================================================================
   TOAST
   ====================================================================== */
const TOAST_ICONS = {
    ok:   '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>',
    err:  '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    warn: '<svg viewBox="0 0 24 24"><path d="M12 7v6M12 17v.01"/></svg>',
    info: '<svg viewBox="0 0 24 24"><path d="M12 11v6M12 7v.01"/></svg>',
};
const TOAST_TITLES = { ok: 'สำเร็จ', err: 'ผิดพลาด', warn: 'แจ้งเตือน', info: 'ข้อมูล' };
const TOAST_MAX = 3;          // แสดงพร้อมกันได้สูงสุด 3 อัน (เรียงแนวตั้ง)
const _toastQueue = [];       // อันที่เกินจะเข้าคิวรอ แล้วโผล่ทีละอันเมื่อมีที่ว่าง

const _toastLive = () => [...$('#toasts').children].filter(t => !t.classList.contains('out'));

/* มีที่ว่าง → ดึงอันที่รออยู่ออกมาแสดง */
function pumpToasts() {
    while (_toastQueue.length && _toastLive().length < TOAST_MAX) {
        const q = _toastQueue.shift();
        mountToast(q.msg, q.kind, q.dur, q.opts);
    }
}

/* toast(msg, kind, dur, { title, sub, tag, time, img })
   msg      = หัวข้อหลัก (ตัวหนาใหญ่)
   opts.title = บรรทัดเล็กบนสุด ส่วนที่เป็นสี (ค่าเริ่มต้น: สำเร็จ/ผิดพลาด/แจ้งเตือน/ข้อมูล)
   opts.sub   = ข้อความเทาต่อท้าย title เช่น 'เข้าเกมแล้ว'
   opts.tag   = ข้อความสีเด่นบรรทัดล่าง เช่น 'IN GAME'
   opts.time  = ข้อความเวลาสีเทาบรรทัดล่าง (ค่าเริ่มต้น 'เมื่อสักครู่')
   opts.img   = URL รูปเล็ก (เช่นไอคอนเกม/อวาตาร์) แทนไอคอนสถานะ */
function toast(msg, kind = 'info', dur = 3000, opts = {}) {
    if (!TOAST_ICONS[kind]) kind = 'info';
    const wrap = $('#toasts');
    const text = String(msg);

    // ข้อความเดิม + ชนิดเดิมที่ยังแสดงอยู่ → นับจำนวน, รีเซ็ตเวลา (อยู่ตำแหน่งเดิม)
    const dup = [...wrap.children].find(t => !t.classList.contains('out')
        && t.dataset.kind === kind && t.dataset.msg === text);
    if (dup) { dup._bump(dur); return; }

    // ซ้ำกับอันที่รอคิวอยู่ → ไม่ต้องเพิ่มอีก
    if (_toastQueue.some(q => q.kind === kind && String(q.msg) === text)) return;

    // เต็ม 3 อันแล้ว → เข้าคิวรอ
    if (_toastLive().length >= TOAST_MAX) {
        _toastQueue.push({ msg: text, kind, dur, opts });
        return;
    }
    mountToast(text, kind, dur, opts);
}

function mountToast(text, kind, dur, opts) {
    const wrap = $('#toasts');
    const el = document.createElement('div');
    el.className = `toast ${kind}`;
    el.dataset.kind = kind;
    el.dataset.msg = text;
    el.setAttribute('role', kind === 'err' ? 'alert' : 'status');
    const icon = opts.img
        ? `<img src="${esc(opts.img)}" alt="" draggable="false">`
        : TOAST_ICONS[kind];
    el.innerHTML = `
        <div class="t-ico">${icon}</div>
        <div class="t-body">
            <div class="t-title"><b>${esc(opts.title || TOAST_TITLES[kind])}</b>${opts.sub ? esc(opts.sub) : ''}</div>
            <div class="t-msg" title="${esc(text)}">${esc(text)}</div>
            <div class="t-meta">${opts.tag ? `<b>${esc(opts.tag)}</b>` : ''}${esc(opts.time || 'เมื่อสักครู่')}</div>
        </div>
        <div class="t-count">1</div>
        <button class="t-x" type="button" aria-label="ปิด">${ICON.close(12)}</button>
        <div class="t-bar"></div>`;

    let timer = null, left = dur, started = 0, count = 1, closed = false;
    const bar = el.querySelector('.t-bar');
    const close = () => {
        if (closed) return;
        closed = true;
        clearTimeout(timer);
        el.classList.add('out');
        setTimeout(() => { el.remove(); pumpToasts(); }, 330);
    };
    const run = ms => {
        clearTimeout(timer);
        started = Date.now();
        left = ms;
        timer = setTimeout(close, ms);
    };
    el._bump = d => {
        count++;
        const c = el.querySelector('.t-count');
        c.textContent = count > 99 ? '99+' : count;
        el.classList.add('has-count');
        c.style.animation = 'none'; void c.offsetWidth; c.style.animation = '';
        bar.style.setProperty('--d', d + 'ms');
        bar.style.animation = 'none'; void bar.offsetWidth; bar.style.animation = '';
        run(d);
    };
    el.style.setProperty('--d', dur + 'ms');

    // เอาเมาส์วางค้าง = หยุดเวลา, เอาออก = นับต่อ
    el.addEventListener('mouseenter', () => {
        if (closed) return;
        clearTimeout(timer);
        left = Math.max(400, left - (Date.now() - started));
    });
    el.addEventListener('mouseleave', () => { if (!closed) run(left); });
    el.addEventListener('click', close);

    wrap.appendChild(el);
    run(dur);
}

/* ======================================================================
   MODAL HELPERS
   ====================================================================== */
function enableClickOutsideClose(o, closeFn, canClose) {
    o.addEventListener('mousedown', e => {
        if (e.target.closest('.dialog')) return;
        if (typeof canClose === 'function' && !canClose()) {
            const d = o.querySelector('.dialog');
            if (d && window.gsap) gsap.fromTo(d, { x: -6 }, { x: 0, duration: .5, ease: 'elastic.out(1,.25)', clearProps: 'transform' });
            return;
        }
        closeFn();
    });
}
function ask(title, { multi = false, secret = false, info = false, confirm = false, ok = 'ตกลง' } = {}) {
    return new Promise(res => {
        const o = document.createElement('div');
        o.className = 'overlay';
        const field = (info || confirm) ? '' : (multi
            ? `<textarea id="ask-input" rows="5" class="mono"></textarea>`
            : `<input id="ask-input" type="${secret ? 'password' : 'text'}" autocomplete="off">`);
        o.innerHTML = `
          <div class="dialog ask">
            <div class="ask-h"><div class="ask-ic">${info ? 'i' : '?'}</div><div class="ask-t">${esc(title)}</div></div>
            ${field}
            <div class="dlg-f" style="padding:0;border:0">
              ${info ? '' : `<button class="btn ghost" id="m-no" type="button">ยกเลิก</button>`}
              <button class="btn pri" id="m-ok" type="button">${esc(ok)}</button>
            </div>
          </div>`;
        document.getElementById('modal-root').appendChild(o);
        requestAnimationFrame(() => o.classList.add('in'));
        const input = o.querySelector('#ask-input');
        if (input) setTimeout(() => input.focus(), 220);
        const close = v => { o.classList.remove('in'); setTimeout(() => o.remove(), 250); res(v); };
        o.querySelector('#m-ok').onclick = () => close(input ? input.value : true);
        const no = o.querySelector('#m-no');
        if (no) no.onclick = () => close(null);
        o.addEventListener('keydown', e => {
            if (e.key === 'Enter' && !multi && !info) { e.preventDefault(); close(input ? input.value : true); }
            if (e.key === 'Escape') close(null);
        });
        enableClickOutsideClose(o, () => close(null), () => true);
    });
}


/* ======================================================================
   ยืนยันลบบัญชี (askDelete) — โทนแดง · แสดงบัญชีที่จะถูกลบ · บอกผลกระทบชัด
   • โฟกัสเริ่มต้นที่ "ยกเลิก" และ Enter จะไม่ลบ (กันเผลอ)
   • ลบตั้งแต่ 2 บัญชีขึ้นไป ต้องติ๊กรับทราบก่อนปุ่มลบจะกดได้
   ====================================================================== */
function askDelete(accts) {
    accts = (accts || []).filter(Boolean);
    const n = accts.length;
    if (!n) return Promise.resolve(false);
    const one = n === 1, live = accts.filter(a => a.active).length;
    return new Promise(res => {
        const o = document.createElement('div');
        o.className = 'overlay';
        const target = a => `
            <div class="dg-t">
              ${avatarHtml(a)}
              <div class="dg-tn"><b>${esc(a.name)}</b><small>ID ${a.id}${a.user_id ? ' · uid ' + a.user_id : ''}</small></div>
              ${a.active ? '<span class="dg-run"><i></i>กำลังทำงาน</span>' : ''}
            </div>`;
        o.innerHTML = `
          <div class="dialog danger-dlg" role="alertdialog" aria-modal="true" aria-labelledby="dg-title">
            <div class="dg-top">
              <div class="dg-ic">${ICON.trash(22)}</div>
              <div class="dg-ht">
                <h3 id="dg-title">${one ? 'ลบบัญชีนี้ถาวร?' : `ลบ ${n} บัญชีถาวร?`}</h3>
                <p>${ICON.alert(13)} การลบนี้ย้อนกลับไม่ได้</p>
              </div>
            </div>
            <div class="dg-body">
              <div class="dg-targets${one ? '' : ' multi'}">${accts.map(target).join('')}</div>
              <div class="dg-fx-t">สิ่งที่จะเกิดขึ้น</div>
              <ul class="dg-fx">
                ${live ? `<li class="x"><i>${ICON.stop(11)}</i><span>ปิดเกมที่เปิดอยู่${one ? '' : ` <b>${live} บัญชี</b>`}ทันที</span></li>` : ''}
                <li class="x"><i>${ICON.key(12)}</i><span>ลบ cookie และรหัสผ่านออกจาก vault</span></li>
                <li class="x"><i>${ICON.trash(12)}</i><span>ลบ${one ? 'บัญชี' : 'ทุกบัญชี'}ออกจากรายการและคิวงานในแอป</span></li>
                <li class="ok"><i>${ICON.shield(12)}</i><span>บัญชีบน Roblox <b>ไม่ถูกลบ</b> — ลบเฉพาะข้อมูลในแอปนี้</span></li>
              </ul>
              ${one ? '' : `<label class="dg-ack"><input type="checkbox" id="dg-ack"><span>ฉันเข้าใจว่าลบ ${n} บัญชีนี้แล้วกู้คืนไม่ได้</span></label>`}
            </div>
            <div class="dg-f">
              <button class="btn ghost" id="m-no" type="button">ยกเลิก</button>
              <button class="btn danger-solid" id="m-ok" type="button" ${one ? '' : 'disabled'}>${ICON.trash(14)} ${one ? 'ลบถาวร' : `ลบ ${n} บัญชี`}</button>
            </div>
          </div>`;
        document.getElementById('modal-root').appendChild(o);
        requestAnimationFrame(() => o.classList.add('in'));
        const close = v => { o.classList.remove('in'); setTimeout(() => o.remove(), 250); res(v); };
        const ok = o.querySelector('#m-ok'), no = o.querySelector('#m-no'), ack = o.querySelector('#dg-ack');
        setTimeout(() => no.focus(), 220);
        if (ack) ack.onchange = () => { ok.disabled = !ack.checked; };
        ok.onclick = () => { if (!ok.disabled) close(true); };
        no.onclick = () => close(null);
        o.addEventListener('keydown', e => { if (e.key === 'Escape') close(null); });
        enableClickOutsideClose(o, () => close(null), () => true);
    });
}

/* ======================================================================
   RANGE + ช่องตัวเลข (กรอกได้ · เกิน min/max → ตันที่ขอบ)
   ====================================================================== */
(function () {
    const pair = (el) => {
        const w = el.closest('.range-wrap');
        return w ? { r: w.querySelector('input[type=range]'), v: w.querySelector('input.range-val') } : null;
    };
    /* ลากหลอด → อัปเดตเลข */
    document.addEventListener('input', e => {
        const t = e.target;
        if (t.matches && t.matches('.range-wrap input[type=range]')) {
            const p = pair(t);
            if (p.v && document.activeElement !== p.v) {
                const isG = t.dataset.global && +t.value <= +t.min;     /* ซ้ายสุด = Global */
                p.v.value = isG ? t.dataset.global : t.value;
                p.v.classList.toggle('is-global', !!isG);
            }
        } else if (t.matches && t.matches('.range-wrap input.range-val')) {
            t.value = t.value.replace(/\D/g, '');          /* รับเฉพาะตัวเลข */
        }
    });
    const commit = (v) => {
        const p = pair(v); if (!p || !p.r) return;
        let n = parseInt(v.value, 10);
        if (isNaN(n)) { v.value = v.dataset.prev ?? p.r.value; return; }   /* ว่าง → คืนค่าเดิม */
        n = Math.min(+p.r.max, Math.max(+(p.r.dataset.floor || p.r.min), n));                     /* ตันที่ limit */
        p.r.value = n;
        p.r.dispatchEvent(new Event('input', { bubbles: true }));
        v.value = n; v.classList.remove('is-global');
    };
    document.addEventListener('focusin', e => {
        const v = e.target;
        if (v.matches && v.matches('.range-wrap input.range-val')) { v.dataset.prev = v.value; v.select(); }
    });
    document.addEventListener('focusout', e => {
        if (e.target.matches && e.target.matches('.range-wrap input.range-val')) commit(e.target);
    });
    document.addEventListener('keydown', e => {
        if (e.key === 'Enter' && e.target.matches && e.target.matches('.range-wrap input.range-val')) { e.preventDefault(); e.target.blur(); }
    });
})();


/* ======================================================================
   CODE EDITOR — กล่องใส่ script (Lua) ใช้ร่วมกัน: หน้าตั้งค่า (global) + แก้ไขบัญชี (เฉพาะบัญชี)
   ====================================================================== */
function codeEditor({ attr, value = '', placeholder = '', rows = 8, badge = '' }) {
    const v = String(value || '');
    return `<div class="code" data-code>
      <div class="code-bar">
        <span class="code-lang">${ICON.code(13)}<b>Lua</b></span>
        ${badge ? `<span class="code-badge${badge === 'Custom' ? ' is-custom' : ''}">${badge}</span>` : ''}
        <span class="code-len" data-code-len>${codeStats(v)}</span>
        <button class="code-btn" type="button" data-code-clear ${v ? '' : 'hidden'} data-tip="ล้างทั้งหมด">${ICON.trash(12)}<span>ล้าง</span></button>
      </div>
      <textarea class="code-ta" ${attr} rows="${rows}" spellcheck="false" autocomplete="off" autocapitalize="off"
                wrap="off" placeholder="${esc(placeholder)}">${esc(v)}</textarea>
    </div>`;
}
function codeStats(v) {
    if (!v) return 'ว่าง';
    const lines = v.split('\n').length;
    return `${lines} บรรทัด · ${v.length.toLocaleString()} ตัวอักษร`;
}
/** ผูก event ของ codeEditor ที่อยู่ใน root — onChange(value) ถูกเรียกทุกครั้งที่แก้ */
function bindCodeEditors(root, onChange) {
    root.querySelectorAll('[data-code]').forEach(box => {
        if (box.dataset.bound) return;
        box.dataset.bound = '1';
        const ta = box.querySelector('textarea');
        const len = box.querySelector('[data-code-len]');
        const clr = box.querySelector('[data-code-clear]');
        const sync = () => {
            len.textContent = codeStats(ta.value);
            clr.hidden = !ta.value;
            onChange && onChange(ta.value, ta);
        };
        ta.addEventListener('input', sync);
        ta.addEventListener('keydown', e => {          // Tab = เว้น 2 ช่อง (ไม่ย้ายโฟกัส)
            if (e.key !== 'Tab' || e.shiftKey || e.ctrlKey || e.altKey) return;
            e.preventDefault();
            const { selectionStart: a, selectionEnd: b, value } = ta;
            ta.value = value.slice(0, a) + '  ' + value.slice(b);
            ta.selectionStart = ta.selectionEnd = a + 2;
            sync();
        });
        clr.onclick = () => { ta.value = ''; sync(); ta.focus(); };
    });
}


/* ══════════════════════════════════════════════════════════════════════
   02b-icons
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · ไอคอน — Lucide (https://lucide.dev)
   ICON.ชื่อ(ขนาดpx) คืน <i data-lucide> แล้ว lucide.createIcons() แปลงเป็น <svg> ให้อัตโนมัติทุกครั้งที่ DOM เปลี่ยน
   อยากได้ไอคอนใหม่: เพิ่มบรรทัดใน MAP (ชื่อฝั่ง Lucide ดูที่ lucide.dev/icons) */
const ICON = (() => {
  const MAP = {
    play: 'play', stop: 'square', pause: 'pause', edit: 'pencil', view: 'eye', eyeOff: 'eye-off', trash: 'trash-2',
    refresh: 'refresh-cw', undo: 'undo-2', plus: 'plus', close: 'x', check: 'check', farm: 'moon', game: 'gamepad-2',
    shield: 'shield', alert: 'alert-triangle', ban: 'ban', key: 'key', search: 'search', map: 'map-pin',
    grid: 'layout-grid', chevDown: 'chevron-down', listChecks: 'list-checks', pipette: 'pipette', palette: 'palette',
    monitor: 'monitor', minus: 'minus', rows: 'rows-3', tag: 'tag',
    list: 'list', queue: 'align-left', copy: 'copy', console: 'terminal', home: 'home', user: 'user', users: 'user-plus',
    link: 'link', bolt: 'zap', globe: 'globe', chart: 'activity', clock: 'clock', info: 'info', file: 'file-text',
    arrowR: 'arrow-right', arrowL: 'arrow-left', chevR: 'chevron-right', target: 'target', minimize: 'arrow-down-to-line',
    download: 'download', code: 'code', hourglass: 'hourglass', cpu: 'cpu', cookie: 'cookie', dot: 'circle',
    skull: 'skull', moon: 'moon', star: 'star', settings: 'settings', more: 'ellipsis', sel: 'square-check',
  };
  const FILL = new Set(['play', 'stop', 'pause', 'dot']);
  const SW = { plus: 2.6, close: 2.4, check: 2.6, search: 2.4 };
  return new Proxy({}, {
    get: (_, k) => (s = 14) =>
      `<i data-lucide="${MAP[k] || 'circle-help'}" class="ic${FILL.has(k) ? ' ic-fill' : ''}" style="--s:${s}px${SW[k] ? `;stroke-width:${SW[k]}` : ''}"></i>`,
  });
})();

/* แปลง <i data-lucide> → <svg> แบบ synchronous ก่อน paint (ไม่มีกะพริบ)
   ไม่ใช้ lucide.createIcons(): svg ที่มันสร้างยังมี data-lucide ติดมาด้วย → MutationObserver เรียกซ้ำไม่รู้จบ (หน้าค้าง)
   เลยสร้าง svg เองจาก lucide.icons แล้วไม่ใส่ data-lucide ให้ svg */
if (window.lucide && lucide.icons && lucide.createElement) {
  const pascal = n => n.replace(/(^|-)([a-z0-9])/g, (_, __, c) => c.toUpperCase());
  const swap = () => {
    document.querySelectorAll('i[data-lucide]').forEach(el => {
      const node = lucide.icons[pascal(el.getAttribute('data-lucide'))] || lucide.icons.CircleHelp;
      if (!node) return;
      const svg = lucide.createElement(node);
      svg.setAttribute('class', 'lucide ' + el.className);
      const st = el.getAttribute('style');
      if (st) svg.setAttribute('style', st);
      svg.removeAttribute('width'); svg.removeAttribute('height');
      el.replaceWith(svg);
    });
  };
  new MutationObserver(swap).observe(document.documentElement, { childList: true, subtree: true });
  swap();
}


/* ══════════════════════════════════════════════════════════════════════
   02c-kit
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 02c-kit.js — ส่วนประกอบที่ทุกหน้าใช้ร่วมกัน
   ทุกหน้า (หน้าหลัก/บัญชี/คิว/จัดหน้าต่าง/คอนโซล/ตั้งค่า) ประกอบจากฟังก์ชันชุดนี้ + class ใน app.css
   อยากเปลี่ยนหน้าตา "ทุกหน้า" พร้อมกัน → แก้ที่นี่หรือ app.css ที่เดียว */

const UI = {
    /* หัวหน้า: l = สถานะซ้าย · r = ปุ่มขวา */
    head: (title, { l = '', r = '', sub = '' } = {}) =>
        `<header class="ph"><div class="ph-main"><h1 class="ph-t">${title}</h1>${sub ? `<p class="ph-sub">${sub}</p>` : ''}</div><div class="ph-l">${l}</div><div class="ph-r">${r}</div></header>`,

    /* การ์ดตัวเลข — items: [key, ป้าย, ค่า(html), { c: สี, act, v: กดแล้วเรียก ACT[act] พร้อม data-v }] */
    stats: items => `<div class="stats">${items.map(([key, label, v, o = {}]) => `
        <div class="stat${o.act ? ' go' : ''}"${o.act ? ` data-act="${o.act}" data-v="${o.v}"` : ''} style="--c:${o.c || 'var(--tx)'}">
          ${o.ic ? `<span class="stat-ic">${ICON[o.ic](18)}</span>` : ''}
          <div class="stat-b"><span class="k">${label}</span><b class="v" data-stat="${key}">${v}</b></div>
        </div>`).join('')}</div>`,

    /* อัปเดตตัวเลขในที่เดิม (ไม่สร้างหน้าใหม่) — vals: { key: html | [html, สี] } */
    setStats(vals) {
        for (const [key, val] of Object.entries(vals)) {
            const el = document.querySelector(`[data-stat="${key}"]`);
            if (!el) continue;
            const [html, c] = Array.isArray(val) ? val : [val];
            if (el.innerHTML !== html) el.innerHTML = html;
            if (c && el.closest('.stat').style.getPropertyValue('--c') !== c) el.closest('.stat').style.setProperty('--c', c);
        }
    },

    /* การ์ด — flush = ไม่ครอบเนื้อหาด้วย padding (ใช้กับแถว .fr / รายการ) */
    card: (title, body, { right = '', cls = '', flush = false, icon = '' } = {}) => `
        <section class="card ${cls}">
          ${title ? `<div class="card-h">${icon}<span class="k">${title}</span>${right}</div>` : ''}
          ${flush ? body : `<div class="card-b">${body}</div>`}
        </section>`,

    /* หัวข้อกลุ่ม + จำนวน */
    sec: (title, n, right = '') =>
        `<div class="sec"><span class="k">${title}</span>${n != null ? `<b>${n}</b>` : ''}${right ? `<div class="sec-r">${right}</div>` : ''}</div>`,

    /* แถบตัวเลือก — items: [ค่า, ป้าย, จำนวน?, สี?, tooltip?] · กดแล้วเรียก ACT[act] */
    seg: (act, items, cur) => `<div class="seg">${items.map(([v, label, n, c, tip]) =>
        `<button type="button" class="seg-b${cur === v ? ' on' : ''}${n === 0 ? ' zero' : ''}" data-act="${act}" data-v="${v}"${c ? ` style="--c:${c}"` : ''}${tip ? ` data-tip="${tip}"` : ''}>${label}${n != null ? `<em>${n}</em>` : ''}</button>`).join('')}</div>`,

    /* สถานะว่าง */
    empty: (icon, title, desc, btn = '') =>
        `<div class="empty"><div class="ic-box">${icon}</div><b>${title}</b><p>${desc}</p>${btn}</div>`,

    /* แถวตั้งค่า: ชื่อ+คำอธิบายซ้าย · ตัวควบคุมขวา */
    fr: (title, desc, ctl) => `<div class="fr"><div class="fr-t"><b>${esc(title)}</b>${desc ? `<span>${esc(desc)}</span>` : ''}</div><div class="fr-c">${ctl}</div></div>`,
    tg: (key, on) => `<button type="button" class="tg${on ? ' on' : ''}" data-set-tg="${key}" aria-pressed="${!!on}"></button>`,

    /* ช่องค้นหา */
    search: (attr, value, placeholder, clearAct) => `<div class="search">${ICON.search(14)}
        <input type="text" placeholder="${placeholder}" value="${esc(value)}" ${attr} autocomplete="off" spellcheck="false">
        ${value ? `<button class="search-x" type="button" data-act="${clearAct}" aria-label="ล้าง">${ICON.close(12)}</button>` : ''}</div>`,
};

/* hash สั้น ๆ ไว้เทียบว่า html ของ cell เปลี่ยนไหม (patch เฉพาะที่เปลี่ยน ไม่สร้างทั้งแถวใหม่) */
function hsh(s) {
    let h = 5381;
    for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
    return (h >>> 0).toString(36);
}
/** ใส่ html ให้ element เฉพาะเมื่อเปลี่ยนจริง */
function setCell(el, html) {
    if (!el) return;
    const sig = hsh(html);
    if (el.dataset.sig === sig) return;
    el.dataset.sig = sig;
    el.innerHTML = html;
}
/** สร้าง attribute data-sig ให้ cell ตอน render ครั้งแรก */
const cellAttr = (k, html) => `data-cell="${k}" data-sig="${hsh(html)}"`;

/* ══════════════════════════════════════════════════════════════════════
   DROPDOWN กลาง — แทน <select> ของระบบ (รายการตัวเลือกของ <select> แต่งสีไม่ได้ใน WebView)
   DD.html(id, items, value, opts) → ปุ่ม · กดแล้วเปิดเมนูตามธีม · เลือกแล้วเรียก opts.onPick(value)
   items: [[ค่า, ป้าย(html), คำอธิบายสั้น?]] · รายการเกิน 10 ตัวมีช่องค้นหาในเมนู
   ══════════════════════════════════════════════════════════════════════ */
const DD = {
    reg: {}, menu: null, btn: null,
    html(id, items, value, { placeholder = 'เลือก…', icon = '', cls = '', onPick, sticky = true } = {}) {
        DD.reg[id] = { items, value, onPick, sticky };
        const cur = items.find(i => String(i[0]) === String(value));
        return `<button type="button" class="dd ${cls}" data-dd="${id}" aria-haspopup="listbox" aria-expanded="false">
            ${icon}<span class="dd-v${cur ? '' : ' ph'}">${cur ? cur[1] : placeholder}</span>${ICON.chevDown(14)}</button>`;
    },
    close() {
        if (!DD.menu) return;
        const m = DD.menu, b = DD.btn;
        DD.menu = DD.btn = null;
        if (b) { b.setAttribute('aria-expanded', 'false'); b.classList.remove('open'); }
        m.classList.remove('in');
        setTimeout(() => m.remove(), 140);
    },
    open(btn) {
        const id = btn.dataset.dd, r = DD.reg[id];
        if (!r) return;
        if (DD.btn === btn) return DD.close();
        DD.close();
        const menu = document.createElement('div');
        menu.className = 'dd-menu';
        menu.setAttribute('role', 'listbox');
        const many = r.items.length > 10;
        const itemHtml = r.items.map(([v, label, hint], i) => `
            <div class="dd-i${String(v) === String(r.value) ? ' on' : ''}" role="option" data-i="${i}" data-q="${esc(String(label).replace(/<[^>]+>/g, '').toLowerCase())}">
              <span class="dd-t">${label}</span>${hint ? `<em>${hint}</em>` : ''}${String(v) === String(r.value) ? ICON.check(14) : ''}
            </div>`).join('');
        menu.innerHTML = `${many ? `<div class="dd-s">${ICON.search(13)}<input type="text" placeholder="ค้นหา…" autocomplete="off" spellcheck="false"></div>` : ''}
            <div class="dd-list">${itemHtml}</div><div class="dd-none" hidden>ไม่พบรายการ</div>`;
        const rc = btn.getBoundingClientRect();
        menu.style.minWidth = rc.width + 'px';
        menu.style.visibility = 'hidden';
        document.body.appendChild(menu);
        const mw = menu.offsetWidth, mh = menu.offsetHeight, M = 8;
        const down = innerHeight - rc.bottom - M >= Math.min(mh, 240) || rc.top < mh;
        menu.style.left = Math.max(M, Math.min(rc.left, innerWidth - mw - M)) + 'px';
        if (down) { menu.style.top = (rc.bottom + 4) + 'px'; menu.style.maxHeight = Math.max(160, innerHeight - rc.bottom - M - 4) + 'px'; }
        else { menu.style.bottom = (innerHeight - rc.top + 4) + 'px'; menu.style.maxHeight = Math.max(160, rc.top - M - 4) + 'px'; }
        menu.style.visibility = '';
        requestAnimationFrame(() => menu.classList.add('in'));
        btn.setAttribute('aria-expanded', 'true'); btn.classList.add('open');
        DD.menu = menu; DD.btn = btn; menu._r = rc;

        const rows = () => [...menu.querySelectorAll('.dd-i:not([hidden])')];
        let act = menu.querySelector('.dd-i.on') || rows()[0];
        const mark = el => { if (!el) return; menu.querySelectorAll('.dd-i.act').forEach(x => x.classList.remove('act')); el.classList.add('act'); act = el; el.scrollIntoView({ block: 'nearest' }); };
        mark(act);
        const pick = el => {
            if (!el) return;
            const [v, label] = r.items[+el.dataset.i];
            DD.close();
            if (r.sticky) {
                r.value = v;
                const t = btn.querySelector('.dd-v');
                if (t) { t.innerHTML = label; t.classList.remove('ph'); }
            }
            r.onPick && r.onPick(v);
            btn.focus({ preventScroll: true });
        };
        menu.addEventListener('mousemove', e => { const el = e.target.closest('.dd-i'); if (el && el !== act) mark(el); });
        menu.addEventListener('click', e => pick(e.target.closest('.dd-i')));
        const inp = menu.querySelector('.dd-s input');
        if (inp) {
            inp.focus();
            inp.oninput = () => {
                const q = inp.value.trim().toLowerCase();
                menu.querySelectorAll('.dd-i').forEach(el => { el.hidden = !!q && !el.dataset.q.includes(q); });
                menu.querySelector('.dd-none').hidden = rows().length > 0;
                mark(rows()[0]);
            };
        }
        menu._key = e => {
            if (DD.menu !== menu) return;
            if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); DD.close(); btn.focus({ preventScroll: true }); }
            else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                const rs = rows(), k = Math.max(0, rs.indexOf(act)) + (e.key === 'ArrowDown' ? 1 : -1);
                mark(rs[(k + rs.length) % rs.length]);
            } else if (e.key === 'Enter') { e.preventDefault(); pick(act); }
        };
        document.addEventListener('keydown', menu._key, true);
        const off = () => document.removeEventListener('keydown', menu._key, true);
        new MutationObserver((_, ob) => { if (!menu.isConnected) { off(); ob.disconnect(); } }).observe(document.body, { childList: true });
        if (!inp) btn.focus({ preventScroll: true });
    },
};
document.addEventListener('click', e => {
    const b = e.target.closest('[data-dd]');
    if (b && !b.disabled) { e.preventDefault(); DD.open(b); return; }
    if (DD.menu && !DD.menu.contains(e.target)) DD.close();
});
document.addEventListener('keydown', e => {
    const b = e.target.closest && e.target.closest('[data-dd]');
    if (b && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) { e.preventDefault(); DD.open(b); }
});
addEventListener('resize', () => DD.close());
addEventListener('blur', () => DD.close());
document.addEventListener('scroll', e => {          // ปิดเมื่อปุ่มที่ผูกอยู่เลื่อนหนีจริง ๆ (กันปิดเองจาก scroll-into-view ตอนเปิด)
    if (!DD.menu || DD.menu.contains(e.target) || !DD.btn) return;
    const r = DD.btn.getBoundingClientRect(), o = DD.menu._r;
    if (!o || Math.abs(r.top - o.top) > 2 || Math.abs(r.left - o.left) > 2) DD.close();
}, true);

/* ══════════════════════════════════════════════════════════════════════
   COLOR PICKER — แทน <input type="color"> ของระบบ (หน้าต่างสีของ Windows ไม่เข้ากับธีม)
   พื้นที่ความเข้ม/สว่าง (S/V) + แถบ Hue + ช่อง HEX + ปิเปต (ถ้า WebView รองรับ EyeDropper)
   ══════════════════════════════════════════════════════════════════════ */
function rgbToHsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0;
    if (d) {
        if (mx === r) h = ((g - b) / d) % 6; else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
        h *= 60; if (h < 0) h += 360;
    }
    return [h, mx ? d / mx : 0, mx];
}
function hsvToRgb(h, s, v) {
    const c = v * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = v - c;
    const [r, g, b] = h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x] : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x];
    return [(r + m) * 255, (g + m) * 255, (b + m) * 255];
}
const ColorPicker = {
    el: null, anchor: null,
    close() {
        const el = ColorPicker.el;
        if (!el) return;
        ColorPicker.el = null;
        if (ColorPicker.anchor) ColorPicker.anchor.classList.remove('open');
        ColorPicker.anchor = null;
        el.classList.remove('in');
        setTimeout(() => el.remove(), 140);
    },
    open(anchor, value, onChange) {
        if (ColorPicker.el) { const same = ColorPicker.anchor === anchor; ColorPicker.close(); if (same) return; }
        let [h, s, v] = rgbToHsv(...hexToRgb(value));
        const el = document.createElement('div');
        el.className = 'cp';
        el.innerHTML = `
          <div class="cp-sv" data-cp-sv><i class="cp-knob" data-cp-sk></i></div>
          <div class="cp-hue" data-cp-hue><i class="cp-knob" data-cp-hk></i></div>
          <div class="cp-row">
            <span class="cp-prev" data-cp-prev></span>
            <input class="cp-hex mono" data-cp-hex type="text" maxlength="7" spellcheck="false" autocomplete="off" aria-label="รหัสสี HEX">
            ${window.EyeDropper ? `<button type="button" class="ibtn" data-cp-eye data-tip="ดูดสีจากหน้าจอ">${ICON.pipette(14)}</button>` : ''}
          </div>`;
        document.body.appendChild(el);
        const sv = el.querySelector('[data-cp-sv]'), hue = el.querySelector('[data-cp-hue]');
        const sk = el.querySelector('[data-cp-sk]'), hk = el.querySelector('[data-cp-hk]');
        const prev = el.querySelector('[data-cp-prev]'), hex = el.querySelector('[data-cp-hex]');
        const cur = () => rgbToHex(...hsvToRgb(h, s, v));
        const paint = (fromHex) => {
            const c = cur();
            sv.style.setProperty('--h', h);
            sk.style.left = (s * 100) + '%'; sk.style.top = ((1 - v) * 100) + '%'; sk.style.background = c;
            hk.style.left = (h / 360 * 100) + '%'; hk.style.background = `hsl(${h} 100% 50%)`;
            prev.style.background = c;
            if (!fromHex && document.activeElement !== hex) hex.value = c;
        };
        const emit = () => { paint(); onChange(cur()); };
        const drag = (node, fn) => {
            node.addEventListener('pointerdown', e => {
                if (e.button !== 0) return;
                node.setPointerCapture(e.pointerId);
                const mv = ev => { const r = node.getBoundingClientRect(); fn(Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width)), Math.min(1, Math.max(0, (ev.clientY - r.top) / r.height))); emit(); };
                mv(e);
                node.onpointermove = mv;
                node.onpointerup = node.onpointercancel = () => { node.onpointermove = null; };
            });
        };
        drag(sv, (x, y) => { s = x; v = 1 - y; });
        drag(hue, x => { h = x * 359.999; });
        hex.oninput = () => {
            let t = hex.value.trim(); if (t && t[0] !== '#') t = '#' + t;
            if (/^#[0-9a-f]{6}$/i.test(t)) { [h, s, v] = rgbToHsv(...hexToRgb(t)); paint(true); onChange(t.toLowerCase()); }
        };
        hex.onblur = () => { hex.value = cur(); };
        hex.onkeydown = e => { if (e.key === 'Enter') hex.blur(); };
        const eye = el.querySelector('[data-cp-eye]');
        if (eye) eye.onclick = async () => {
            try { const r = await new EyeDropper().open(); [h, s, v] = rgbToHsv(...hexToRgb(r.sRGBHex)); emit(); } catch (_) { }
        };
        paint();
        const rc = anchor.getBoundingClientRect(), M = 8;
        const w = el.offsetWidth, hgt = el.offsetHeight;
        el.style.left = Math.max(M, Math.min(rc.left, innerWidth - w - M)) + 'px';
        const down = innerHeight - rc.bottom - M >= hgt || rc.top < hgt + M;
        el.style.top = Math.max(M, down ? rc.bottom + 6 : rc.top - hgt - 6) + 'px';
        requestAnimationFrame(() => el.classList.add('in'));
        anchor.classList.add('open');
        ColorPicker.el = el; ColorPicker.anchor = anchor;
    },
};
document.addEventListener('mousedown', e => {
    const cp = ColorPicker.el;
    if (cp && !cp.contains(e.target) && !(ColorPicker.anchor && ColorPicker.anchor.contains(e.target))) ColorPicker.close();
});
document.addEventListener('keydown', e => { if (e.key === 'Escape' && ColorPicker.el) { e.stopPropagation(); ColorPicker.close(); } }, true);
addEventListener('blur', () => ColorPicker.close());
document.addEventListener('scroll', e => { if (ColorPicker.el && !ColorPicker.el.contains(e.target)) ColorPicker.close(); }, true);

/* ══════════════════════════════════════════════════════════════════════
   03-modals
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 03-modals.js — modal เพิ่มบัญชีหลายตัว + แก้ไขบัญชี */

/* ======================================================================
   BULK LOGIN MODAL
   ====================================================================== */
function askBulkLogin() {
    return new Promise(resolve => {
        const o = document.createElement('div');
        o.className = 'overlay';
        let items = [], uid = 0, pumping = false, stopped = false, autoClosed = false;
        let phase = 'input', text = '', mode = S.loginMode || 'browser';

        const parse = t => t.split(/\r?\n/).map(raw => {
            const line = raw.trim();
            if (!line || line.startsWith('#')) return null;
            const parts = line.split(line.includes('|') ? /\s*\|\s*/ : /\s*:\s*/);
            if (parts.length < 2) return { raw: line, user: line, ok: false, err: 'รูปแบบผิด — ใช้ user:pass' };
            const user = parts[0].trim(), pass = parts[1];
            if (!user || !pass) return { raw: line, user: line, ok: false, err: 'user หรือ pass ว่าง' };
            return { raw: line, user, pass, ok: true };
        }).filter(Boolean);

        const find = id => items.find(x => x.id === id);
        const isBusy = () => pumping || items.some(x => x.status === 'running' || x.status === 'brow');
        const result = () => items.length ? { ok: true, summary: items } : null;
        const MODES = {
            browser: [ICON.globe(18), 'Browser', 'เปิดหน้าต่างให้ login ทีละบัญชี · ชัวร์ ไม่ติด CAPTCHA', 'แนะนำ'],
            api:     [ICON.bolt(18), 'API', 'login เบื้องหลัง · เร็ว แต่อาจติด CAPTCHA', ''],
        };
        const ST = {
            idle: ['·', 'var(--tx-3)'], running: ['', 'var(--ac)'], brow: ['', 'var(--ac)'],
            need2fa: [ICON.shield(16), 'var(--ac-2)'], ok: [ICON.check(16), 'var(--ok)'], error: [ICON.close(16), 'var(--err)'],
        };

        function stepsHtml() {
            const st = (n, t, on, done) => `<div class="im-step ${on ? 'on' : ''} ${done ? 'done' : ''}"><i>${done ? ICON.check(11) : n}</i><span>${t}</span></div>`;
            return `<div class="im-steps">${st(1, 'วางรายการ', phase === 'input', phase === 'run')}<div class="im-step-line"></div>${st(2, 'ยืนยัน & ผลลัพธ์', phase === 'run', false)}</div>`;
        }
        function modeCards() {
            return `<div class="im-modes">${Object.entries(MODES).map(([k, [ic, t, d, tag]]) => `
              <button type="button" class="im-mode ${mode === k ? 'on' : ''}" data-mode="${k}">
                <span class="im-mode-ic">${ic}</span>
                <span class="im-mode-tx"><b>${t}${tag ? `<em>${tag}</em>` : ''}</b><small>${d}</small></span>
                <span class="im-radio"></span>
              </button>`).join('')}</div>`;
        }
        function previewHtml() {
            const d = parse(text);
            if (!d.length) return `<div class="im-empty"><b>ยังไม่มีรายการ</b><span>วางหรือพิมพ์ user:pass ด้านบน — ระบบจะยังไม่เริ่มจนกว่าคุณจะกดยืนยัน</span></div>`;
            return d.map((x, i) => `<div class="im-prow ${x.ok ? '' : 'bad'}">
                <span class="im-n">${i + 1}</span>
                <span class="im-pu">${esc(x.user)}</span>
                <span class="im-pp">${x.ok ? '•'.repeat(Math.min(x.pass.length, 10)) : esc(x.err)}</span>
                <span class="im-ptag">${x.ok ? ICON.check(13) : ICON.close(13)}</span>
              </div>`).join('');
        }
        function rowHtml(it) {
            const [ic, col] = ST[it.status] || ST.idle;
            const spin = it.status === 'running' || it.status === 'brow';
            const cap = it.status === 'error' && /CAPTCHA|challenge/i.test(it.msg || '');
            return `<div class="row" style="--c:${col}">
              <div class="ic-box">${spin ? '<i class="im-spin"></i>' : ic}</div>
              <div class="row-main">
                <div class="im-user">${esc(it.user)}</div>
                <div class="im-msg">${esc(it.msg || '')}</div>
                ${it.status === 'need2fa' ? `<div class="im-2fa">
                    <input type="text" inputmode="numeric" maxlength="8" autocomplete="off" data-2fa="${it.id}"
                           placeholder="${it.mediaType === 'Email' ? 'รหัสจากอีเมล' : 'รหัส 6 หลัก'}">
                    <button class="btn pri" data-2fa-ok="${it.id}" type="button">ยืนยัน</button></div>` : ''}
              </div>
              <div class="im-act">
                ${cap ? `<button class="btn pri" data-browser="${it.id}" type="button">${ICON.globe(13)} เปิด Browser</button>` : ''}
                ${it.status === 'error' && it.pass ? `<button class="btn ghost" data-retry="${it.id}" type="button">ลองใหม่</button>` : ''}
              </div>
            </div>`;
        }

        function render() {
            const input = phase === 'input';
            o.innerHTML = `
            <div class="dialog wide">
              <div class="dlg-h">
                <div class="av lg">${ICON.key(22)}</div>
                <div class="dlg-h-t"><h3>Import ด้วย Username</h3>
                  <div class="sub">${input ? 'วางรายการ แล้วกดยืนยันเพื่อเริ่ม' : 'กำลังดำเนินการตามที่ยืนยัน'}</div></div>
              </div>
              <div class="dlg-b">
              ${stepsHtml()}
              ${input ? `
                <div class="im-sec"><label>วิธี Login</label>${modeCards()}</div>
                <div class="im-sec"><label>รายการบัญชี <small>บรรทัดละ 1 บัญชี · <code>user:pass</code> หรือ <code>user|pass</code> · <code>#</code> = ข้าม</small></label>
                  <textarea id="im-input" rows="4" spellcheck="false" placeholder="Mango_farm01:MyPass123&#10;Kiwi_alt:P@ssw0rd">${esc(text)}</textarea></div>
                <div class="im-sec"><label>ตรวจสอบรายการ <span class="im-count" id="im-count"></span></label>
                  <div class="im-prev" id="im-prev"></div></div>
              ` : `
                <div class="im-prog" id="im-prog"></div>
                <div class="im-list" id="im-list"></div>
              `}
              </div>
              <div class="dlg-f" id="im-foot"></div>
            </div>`;
            if (input) {
                o.querySelectorAll('[data-mode]').forEach(b => b.onclick = () => { mode = b.dataset.mode; S.loginMode = mode; render(); });
                const ta = o.querySelector('#im-input');
                ta.addEventListener('input', () => { text = ta.value; refreshInput(); });
                ta.addEventListener('keydown', e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); confirmStart(); } });
                setTimeout(() => ta.focus(), 100);
                refreshInput();
            } else {
                const l = o.querySelector('#im-list');
                l.addEventListener('click', onListClick);
                l.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.dataset['2fa']) { e.preventDefault(); submit2FA(+e.target.dataset['2fa']); } });
                renderRun();
            }
            renderFoot();
        }
        function refreshInput() {
            const prev = o.querySelector('#im-prev'); if (!prev) return;
            prev.innerHTML = previewHtml();
            const d = parse(text), ok = d.filter(x => x.ok).length, bad = d.length - ok;
            o.querySelector('#im-count').innerHTML = d.length ? `<b>${ok}</b> พร้อม${bad ? ` · <b class="bad">${bad}</b> ผิดรูปแบบ` : ''}` : '';
            renderFoot();
        }
        function renderRun() {
            const l = o.querySelector('#im-list'), p = o.querySelector('#im-prog'); if (!l) return;
            const keep = document.activeElement && document.activeElement.dataset ? document.activeElement.dataset['2fa'] : null;
            const val = keep ? document.activeElement.value : '';
            l.innerHTML = items.map(rowHtml).join('');
            if (keep) { const i = l.querySelector(`[data-2fa="${keep}"]`); if (i) { i.value = val; i.focus(); } }
            else { const i = l.querySelector('[data-2fa]'); if (i) i.focus(); }
            const ok = items.filter(x => x.status === 'ok').length, bad = items.filter(x => x.status === 'error').length;
            const need = items.filter(x => x.status === 'need2fa').length, done = ok + bad;
            p.innerHTML = `<div class="bar im-bar"><i style="width:${items.length ? Math.round(done / items.length * 100) : 0}%"></i></div>
              <div class="im-stats"><span class="badge" style="--c:var(--ok)">${ok} สำเร็จ</span>
                ${bad ? `<span class="badge" style="--c:var(--err)">${bad} ล้มเหลว</span>` : ''}
                ${need ? `<span class="badge live" style="--c:var(--ac-2)">${need} รอ 2FA</span>` : ''}
                <span class="im-tot">${done}/${items.length}</span></div>`;
            renderFoot();
        }
        function renderFoot() {
            const f = o.querySelector('#im-foot'); if (!f) return;
            if (phase === 'input') {
                const n = parse(text).filter(x => x.ok).length;
                f.innerHTML = `<button class="btn ghost" id="im-cancel" type="button">${items.length ? 'กลับไปดูผล' : 'ยกเลิก'}</button>
                  <button class="btn pri im-go" id="im-go" type="button" ${n ? '' : 'disabled'}>${ICON.check(13)} ยืนยัน · เริ่ม Import${n ? ` (${n} บัญชี)` : ''}</button>`;
                f.querySelector('#im-cancel').onclick = () => items.length ? (phase = 'run', render()) : close(null);
                f.querySelector('#im-go').onclick = confirmStart;
            } else {
                const busy = items.some(x => ['idle', 'running', 'brow'].includes(x.status));
                f.innerHTML = `${busy ? '<button class="btn ghost" id="im-stop" type="button">หยุดคิว</button>'
                                      : '<button class="btn ghost" id="im-more" type="button">+ เพิ่มอีก</button>'}
                  <button class="btn pri" id="im-close" type="button">${items.some(x => x.status === 'ok') ? 'เสร็จสิ้น' : 'ปิด'}</button>`;
                const st = f.querySelector('#im-stop');
                if (st) st.onclick = () => { stopped = true; items.forEach(x => { if (x.status === 'idle') { x.status = 'error'; x.msg = 'ถูกยกเลิก'; } }); renderRun(); };
                const mo = f.querySelector('#im-more');
                if (mo) mo.onclick = () => { text = ''; phase = 'input'; autoClosed = true; render(); };
                f.querySelector('#im-close').onclick = () => close(result());
            }
        }

        function confirmStart() {
            const ok = parse(text).filter(x => x.ok);
            if (!ok.length) { toast('ยังไม่มีรายการที่ถูกต้อง', 'warn'); return; }
            ok.forEach(x => items.push({ id: ++uid, user: x.user, pass: x.pass, mode, status: 'idle', msg: 'รอคิว' }));
            text = ''; phase = 'run'; stopped = false; autoClosed = false;
            render(); pump();
        }
        function onListClick(e) {
            const t = e.target.closest('button'); if (!t) return; const d = t.dataset;
            const redo = id => { const it = find(+id); if (it) { it.status = 'idle'; it.msg = 'รอคิว'; stopped = false; renderRun(); pump(); return it; } };
            if (d['2faOk']) submit2FA(+d['2faOk']);
            else if (d.retry) redo(d.retry);
            else if (d.browser) { const it = redo(d.browser); if (it) it.mode = 'browser'; }
        }
        const upd = (it, status, msg) => { it.status = status; it.msg = msg; if (phase === 'run') renderRun(); };

        async function submit2FA(id) {
            const it = find(id); if (!it || it.status !== 'need2fa') return;
            const inp = o.querySelector(`[data-2fa="${id}"]`);
            const code = inp ? inp.value.trim() : '';
            if (!/^\d{4,8}$/.test(code)) { upd(it, 'need2fa', 'กรอกตัวเลข 4-8 หลัก'); return; }
            upd(it, 'running', 'กำลังยืนยัน…');
            try {
                const r = await api('login_2fa', it.ticket, code);
                if (r.ok) { upd(it, 'ok', 'เพิ่ม: ' + r.added); poll(); }
                else if (r.need_2fa) upd(it, 'need2fa', 'รหัสไม่ถูกต้อง');
                else upd(it, 'error', r.error || 'ยืนยันไม่สำเร็จ');
            } catch (e) { upd(it, 'error', String(e)); }
            maybeFinish();
        }
        async function processOne(it) {
            if (it.mode === 'browser') {
                upd(it, 'brow', 'เปิดหน้าต่าง Browser…');
                try {
                    const r = await api('browser_login_prefill', it.user, it.pass);
                    if (r.ok) { upd(it, 'ok', 'เพิ่ม: ' + r.added); poll(); } else upd(it, 'error', r.error || 'ไม่สำเร็จ');
                } catch (e) { upd(it, 'error', String(e)); }
                return;
            }
            upd(it, 'running', 'กำลัง login…');
            try {
                const r = await api('login_password', it.user, it.pass);
                if (r.ok) { upd(it, 'ok', 'เพิ่ม: ' + r.added); poll(); return; }
                if (r.need_2fa) {
                    it.ticket = r.ticket; it.mediaType = r.mediaType;
                    upd(it, 'need2fa', it.mediaType === 'Email' ? 'ต้องยืนยัน — กรอกรหัสจากอีเมล' : 'ต้องยืนยัน — เปิด Authenticator');
                    return;
                }
                const cap = /CAPTCHA|challenge/i.test(r.error || '');
                upd(it, 'error', cap ? 'Roblox บังคับ CAPTCHA — เปิดด้วย Browser แทน' : (r.error || 'login ล้มเหลว'));
            } catch (e) { upd(it, 'error', String(e)); }
        }
        async function pump() {
            if (pumping) return;
            pumping = true;
            while (!stopped) {
                const it = items.find(x => x.status === 'idle');
                if (!it) break;
                await processOne(it);
            }
            pumping = false;
            maybeFinish();
        }
        function maybeFinish() {
            if (phase === 'run') renderFoot();
            if (pumping || autoClosed || phase !== 'run' || !items.length) return;
            if (items.every(x => x.status === 'ok')) {
                autoClosed = true;
                toast(`เพิ่มสำเร็จ ${items.length} บัญชี`, 'ok', 2500);
                setTimeout(() => close(result()), 900);
            }
        }

        const close = v => { stopped = true; o.classList.remove('in'); setTimeout(() => o.remove(), 250); resolve(v); };
        o.addEventListener('keydown', e => { if (e.key === 'Escape' && !isBusy()) close(result()); });
        document.getElementById('modal-root').appendChild(o);
        enableClickOutsideClose(o, () => close(result()), () => !isBusy() && !(phase === 'input' && text.trim()));
        render();
        requestAnimationFrame(() => o.classList.add('in'));
    });
}

/* ======================================================================
   EDIT ACCOUNT MODAL — ★ เพิ่ม Auto-Exec Script block
   ====================================================================== */
async function askAccount(a) {
    const ownPid = num(a.place_id), globalPid = num(S.set.place_id);
    // state() ส่งมาแค่ has_script_override — ดึงโค้ดเฉพาะบัญชีที่เคยบันทึกไว้มาใส่ให้ (เดิมช่องนี้ว่างเสมอ)
    let savedScript = '';
    const scriptReq = api('get_script_for_account', a.id)
        .then(r => { if (r && r.ok) savedScript = r.script_override || ''; })
        .catch(() => { });
    await scriptReq;

    return new Promise(res => {
        const o = document.createElement('div');
        o.className = 'overlay';

        const live = S.accounts.find(x => x.id === a.id) || a;
        const [stTxt, stColor, stLive] = C[live.state] || C.IDLE;
        const globalFps = S.set.fps ?? 30;
        const gPid = globalPid;
        let placeId = ownPid || globalPid;          // ค่าเริ่มต้น = เลือกแมพเริ่มต้นให้เลย
        let fpsVal = (a.fps == null || a.fps === '') ? '' : Number(a.fps);
        let tabKey = 'game';

        /* ── วิธีเข้าเกม: ตามเพื่อน (ชนะทุกอย่าง) > Private server > เซิร์ฟเวอร์ปกติ — ตรงกับลำดับที่ core ใช้จริง ── */
        let connMode = a.join_friend ? 'friend' : (a.link ? 'private' : 'public');
        const connVal = { link: a.link || '', friend: a.join_friend || '' };
        const CONN = [
            ['public',  'globe', 'เซิร์ฟเวอร์ปกติ', 'สุ่มเข้าเซิร์ฟเวอร์สาธารณะ'],
            ['private', 'key',   'Private server',   'เข้าเซิร์ฟเวอร์ส่วนตัว'],
            ['friend',  'users', 'ตามเพื่อน',         'เข้าเซิร์ฟเวอร์เดียวกับเพื่อน'],
        ];
        /* ดึง linkCode จากลิงก์ที่วาง (หรือรับรหัสตรง ๆ) — คืน { code, state } */
        const parseLink = (raw) => {
            const v = (raw || '').trim();
            if (!v) return { code: '', state: 'empty' };
            const m = v.match(/privateServerLinkCode=([\w-]+)/i);
            if (m) return { code: m[1], state: 'ok' };
            if (/[?&]code=[\w-]+/i.test(v) && /share/i.test(v)) return { code: '', state: 'share' };
            if (/^https?:\/\//i.test(v) || /\s/.test(v)) return { code: '', state: 'bad' };
            if (/^[\w-]{8,}$/.test(v)) return { code: v, state: 'ok' };
            return { code: '', state: 'bad' };
        };
        const connPanel = () => {
            if (connMode === 'public') return `
              <div class="cx-note">${ICON.globe(15)}<div><b>ไม่ต้องตั้งค่าเพิ่ม</b><span>เข้าแมพที่เลือกด้านบน ผ่านเซิร์ฟเวอร์สาธารณะที่ Roblox จัดให้</span></div></div>`;
            if (connMode === 'private') return `
              <div class="fld"><label class="field-l" for="e-link">ลิงก์ Private server</label>
                <input id="e-link" value="${esc(connVal.link)}" placeholder="วางลิงก์ที่มี privateServerLinkCode=… หรือรหัสโดยตรง" autocomplete="off" spellcheck="false"></div>
              <div class="cx-st" id="e-link-st"></div>
              <p class="cx-help">ต้องเป็นแมพเดียวกับที่เลือกด้านบน · ระบบจะแยกรหัสออกจากลิงก์ให้เอง</p>`;
            return `
              <div class="fld"><label class="field-l" for="e-friend">ชื่อผู้ใช้ของเพื่อน</label>
                <div class="cx-in"><span class="pre">@</span><input id="e-friend" value="${esc(connVal.friend)}" placeholder="username เพื่อน" autocomplete="off" spellcheck="false"></div></div>
              <ul class="cx-rules">
                <li>จะ<b>ตามเพื่อนไปแมพที่เพื่อนอยู่</b> — ไม่ใช้แมพที่เลือกด้านบน</li>
                <li>ต้องเป็นเพื่อนกัน และเพื่อนต้องเปิดให้เข้าร่วมได้</li>
                <li>หาเพื่อนไม่เจอ → เข้าเซิร์ฟเวอร์ปกติแทน</li>
              </ul>`;
        };
        const connHtml = () => `
          <div class="cx">
            <div class="cx-opts" role="radiogroup" aria-label="วิธีเข้าเกม">${CONN.map(([k, ic, t, d]) => `
              <button type="button" class="cx-o${connMode === k ? ' on' : ''}" role="radio" aria-checked="${connMode === k}" data-conn="${k}">
                <span class="cx-ic">${ICON[ic](16)}</span><b>${t}</b><small>${d}</small><i class="cx-ck">${ICON.check(11)}</i>
              </button>`).join('')}</div>
            <div class="cx-panel" id="ae-conn-panel">${connPanel()}</div>
          </div>`;
        function updLinkState() {
            const st = o.querySelector('#e-link-st'); if (!st) return;
            const r = parseLink(connVal.link);
            const msg = {
                empty: ['', 'วางลิงก์หรือรหัส private server'],
                ok:    ['ok', `${ICON.check(13)} ตรวจพบรหัส <code>${esc(r.code.length > 14 ? r.code.slice(0, 6) + '…' + r.code.slice(-4) : r.code)}</code>`],
                share: ['warn', `${ICON.alert(13)} ลิงก์แบบ share?code=… ใช้ตรง ๆ ไม่ได้ — เปิดลิงก์ในเบราว์เซอร์ก่อน แล้วคัดลอกลิงก์ที่ได้ (ขึ้นต้น roblox.com/games/…)`],
                bad:   ['warn', `${ICON.alert(13)} อ่านรหัสจากลิงก์นี้ไม่ได้ — ต้องมี privateServerLinkCode=… หรือวางรหัสโดยตรง`],
            }[r.state];
            st.className = 'cx-st ' + msg[0]; st.innerHTML = msg[1];
        }
        function bindConn() {
            const box = o.querySelector('#ae-conn'); if (!box) return;
            box.innerHTML = connHtml();
            const pl = o.querySelector('#ae-place'); if (pl) pl.classList.toggle('dim', connMode === 'friend');
            box.querySelectorAll('[data-conn]').forEach(b => b.onclick = () => { connMode = b.dataset.conn; bindConn(); });
            const li = box.querySelector('#e-link'), fi = box.querySelector('#e-friend');
            if (li) { li.oninput = () => { connVal.link = li.value; updLinkState(); }; updLinkState(); }
            if (fi) fi.oninput = () => { connVal.friend = fi.value; };
        }

        const avatar = live.avatar_url
            ? `<img src="${esc(live.avatar_url)}" alt="">`
            : ``;

        function placeHtml() {
            const lib = mapLib().slice();
            if (placeId && !libGet(placeId)) lib.push({ id: placeId, ...(S.gameCache[placeId] || {}) });   // แมพเก่าที่ยังไม่เข้าคลัง
            const opt = m => `<button type="button" class="mp-opt${placeId === m.id ? ' on' : ''}" data-pick="${m.id}">
                <span class="mp-ic">${m.icon ? `<img src="${esc(m.icon)}" alt="" draggable="false">` : ICON.map(16)}</span>
                <span class="mp-tx"><b>${esc(m.name || 'Place ' + m.id)}${m.id === gPid ? ' <em class="mc-tag own">ค่าเริ่มต้น</em>' : ''}</b><small>${'#' + m.id + (m.creator ? ' · โดย ' + esc(m.creator) : '')}</small></span>
                <span class="mp-ck">${ICON.check(13)}</span></button>`;
            return `<div class="mp-list">${lib.map(opt).join('')}</div>
              <div class="mp-foot">
                <span>${lib.length ? 'เลือกจากคลังแมพที่บันทึกไว้' : 'ยังไม่มีแมพในคลัง'}</span>
                <button class="btn ghost" id="ae-lib" type="button">${ICON.settings(13)} จัดการคลังแมพ</button>
              </div>`;
        }
        function bindPlace() {
            const box = o.querySelector('#ae-place');
            box.querySelectorAll('[data-pick]').forEach(b => b.onclick = () => {
                placeId = num(b.dataset.pick);
                box.innerHTML = placeHtml(); bindPlace();
            });
            const lb = box.querySelector('#ae-lib');
            if (lb) lb.onclick = () => { close(null); go('set'); };
        }

        function render() {
            const TABS = [['game', ICON.map(13), 'เกม'], ['run', ICON.bolt(13), 'การทำงาน'], ['script', ICON.code(13), 'Script']];
            o.innerHTML = `
              <div class="dialog wide ae">
                <div class="dlg-h">
                  ${avatarHtml(live, 'lg')}
                  <div class="dlg-h-t">
                    <h3>${esc(live.name)}</h3>
                    <div class="ae-chips">
                      <span class="badge${stLive ? ' live' : ''}" style="--c:${stColor}">${esc(stTxt)}</span>
                      <span class="chip">ID ${live.id}${live.user_id ? ' · uid ' + live.user_id : ''}</span>
                    </div>
                  </div>
                  <button class="ibtn" id="ae-x" type="button" data-tip="ปิด (Esc)">${ICON.close(14)}</button>
                </div>

                <div class="ae-tabs"><div class="seg" role="tablist">${TABS.map(([k, ic, t]) =>
                    `<button type="button" class="seg-b${k === tabKey ? ' on' : ''}" role="tab" data-tab="${k}">${ic}${t}</button>`).join('')}</div></div>

                <div class="dlg-b ae-b">
                  <div class="ae-p" data-p="game" ${tabKey === 'game' ? '' : 'hidden'}>
                    <div class="ae-h"><b>เกมปลายทาง</b><span>เพิ่มแมพใหม่ได้ที่ ตั้งค่า → คลังแมพ</span></div>
                    <div id="ae-place">${placeHtml()}</div>
                    <div class="ae-h"><b>การเชื่อมต่อ</b><span>เลือกวิธีเข้าเกมของบัญชีนี้</span></div>
                    <div id="ae-conn"></div>
                  </div>

                  <div class="ae-p" data-p="run" ${tabKey === 'run' ? '' : 'hidden'}>
                    ${UI.card(null, `
                        ${UI.fr('FPS', `0 = ใช้ค่า Global (${globalFps})`, `<div class="range-wrap">
                            <input type="range" min="0" max="240" step="1" id="e-fps" value="${fpsVal === '' ? 0 : fpsVal}">
                            <input class="range-val mono ${fpsVal === '' ? 'is-global' : ''}" id="e-fps-val" type="text" inputmode="numeric" maxlength="3" value="${fpsVal === '' ? globalFps : fpsVal}"></div>`)}
                        ${UI.fr('Auto-reconnect', 'เข้าเกมใหม่เมื่อหลุด', `<button class="tg ${a.auto ? 'on' : ''}" id="e-auto" type="button"></button>`)}`, { flush: true })}
                  </div>

                  <div class="ae-p" data-p="script" ${tabKey === 'script' ? '' : 'hidden'}>
                    ${UI.card(null, UI.fr('Auto-Exec', 'รัน script อัตโนมัติเมื่อบัญชีนี้เข้าเกม', `<button class="tg ${a.auto_exec !== false ? 'on' : ''}" id="e-autoexec" type="button"></button>`), { flush: true })}
                    <div class="fld">
                      <label class="field-l">Script เฉพาะบัญชี <em>· เว้นว่าง = ใช้ Script หลักจากตั้งค่า</em></label>
                      ${codeEditor({ attr: 'id="e-script-override"', value: savedScript, rows: 9,
                          placeholder: '-- เว้นว่าง = ใช้ script Global',
                          badge: savedScript ? 'Custom' : 'ใช้ Global' })}
                    </div>
                  </div>
                </div>

                <div class="dlg-f">
                  <button class="btn ghost del" id="e-del" type="button" data-tip="ลบถาวร รวม cookie และรหัสผ่านใน vault">${ICON.trash(13)} ลบบัญชี</button>
                  <i class="sp"></i>
                  <button class="btn ghost" id="m-no" type="button">ยกเลิก</button>
                  <button class="btn pri" id="m-ok" type="button">${ICON.check(13)} บันทึก</button>
                </div>
              </div>`;
            o.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => {
                tabKey = b.dataset.tab;
                o.querySelectorAll('[data-tab]').forEach(x => x.classList.toggle('on', x === b));
                o.querySelectorAll('[data-p]').forEach(p => { p.hidden = p.dataset.p !== tabKey; });
            });
            requestAnimationFrame(() => o.classList.add('in'));
            bindPlace();
            bindConn();
            bindCodeEditors(o, (val) => {
                const bd = o.querySelector('.code-badge');
                if (bd) { bd.textContent = val.trim() ? 'Custom' : 'ใช้ Global'; bd.classList.toggle('is-custom', !!val.trim()); }
            });

            /* ── FPS slider ── */
            const fps = o.querySelector('#e-fps'), fpsTx = o.querySelector('#e-fps-val');
            if (fps) {
                const applySlider = () => {
                    const v = +fps.value;
                    if (v < 5) {
                        fpsVal = '';
                        fpsTx.value = globalFps;
                        fpsTx.classList.add('is-global');
                    } else {
                        fpsVal = v;
                        fpsTx.value = v;
                        fpsTx.classList.remove('is-global');
                    }
                };
                fps.oninput = applySlider;

                fpsTx.onchange = () => {
                    const raw = parseInt(fpsTx.value, 10);
                    if (isNaN(raw) || raw <= 0) {
                        fpsVal = '';
                        fpsTx.value = globalFps;
                        fpsTx.classList.add('is-global');
                        fps.value = 0;
                    } else {
                        const v = Math.max(5, Math.min(240, raw));
                        fpsVal = v;
                        fpsTx.value = v;
                        fpsTx.classList.remove('is-global');
                        fps.value = v;
                    }
                };

                if (fpsVal === '') {
                    fps.value = 0;
                    fpsTx.value = globalFps;
                    fpsTx.classList.add('is-global');
                } else {
                    fps.value = fpsVal;
                    fpsTx.value = fpsVal;
                    fpsTx.classList.remove('is-global');
                }
            }

            /* ── Auto-reconnect ── */
            const tg = o.querySelector('#e-auto');
            if (tg) tg.onclick = () => tg.classList.toggle('on');

            /* ── Auto-exec ── */
            const tga = o.querySelector('#e-autoexec');
            if (tga) tga.onclick = () => tga.classList.toggle('on');

            /* ── Delete ── */
            o.querySelector('#e-del').onclick = async () => {
                const yes = await askDelete([live]);
                if (!yes) return;
                const r = await api('delete_account', a.id);
                if (r && r.ok) { toast(`ลบ ${a.name} แล้ว`, 'ok', 2200); close(null); poll(); }
                else toast((r && r.error) || 'ลบไม่สำเร็จ', 'err', 3500);
            };

            /* ── Save ── */
            o.querySelector('#m-ok').onclick = () => {
                /* ตรวจการเชื่อมต่อก่อนบันทึก — กันบันทึกค่าที่เข้าเกมไม่ได้ */
                let linkOut = '', friendOut = '';
                if (connMode === 'private') {
                    const r = parseLink(connVal.link);
                    if (r.state !== 'ok') {
                        o.querySelector('[data-tab="game"]')?.click();
                        toast(r.state === 'empty' ? 'กรอกลิงก์ Private server หรือเลือก "เซิร์ฟเวอร์ปกติ"' : 'ลิงก์ Private server ไม่ถูกต้อง', 'warn', 3200);
                        o.querySelector('#e-link')?.focus(); return;
                    }
                    linkOut = r.code;
                } else if (connMode === 'friend') {
                    friendOut = connVal.friend.trim().replace(/^@/, '');
                    if (!friendOut) {
                        o.querySelector('[data-tab="game"]')?.click();
                        toast('กรอกชื่อผู้ใช้ของเพื่อน หรือเลือก "เซิร์ฟเวอร์ปกติ"', 'warn', 3200);
                        o.querySelector('#e-friend')?.focus(); return;
                    }
                }
                const patch = {
                    name: a.name,
                    fps: fpsVal === '' ? null : fpsVal,
                    place_id: placeId === gPid ? 0 : placeId,      // เท่าแมพเริ่มต้น = ตามค่าเริ่มต้น (เปลี่ยน Global แล้วตามไปด้วย)
                    link: linkOut,
                    auto: tg ? tg.classList.contains('on') : a.auto,
                    join_friend: friendOut,
                    // ★ NEW
                    auto_exec: tga ? tga.classList.contains('on') : true,
                    script_override: o.querySelector('#e-script-override')?.value || "",
                };
                close(patch);
            };
            o.querySelector('#m-no').onclick = () => close(null);
            o.querySelector('#ae-x').onclick = () => close(null);
            enableClickOutsideClose(o, () => close(null), () => true);
        }

        const close = v => { o.classList.remove('in'); setTimeout(() => o.remove(), 250); res(v); };
        o.addEventListener('keydown', e => { if (e.key === 'Escape') close(null); });
        document.getElementById('modal-root').appendChild(o);
        render();
    });
}


/* ══════════════════════════════════════════════════════════════════════
   04-helpers
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 04-helpers.js — copy / beep / badge / chip / game-info lazy load */

/* ======================================================================
   COPY HELPERS
   ====================================================================== */
async function copyText(txt) {
    try { await navigator.clipboard.writeText(txt); return true; }
    catch (e) {
        try {
            const ta = document.createElement('textarea');
            ta.value = txt;
            ta.style.cssText = 'position:fixed;left:-9999px;top:0';
            document.body.appendChild(ta); ta.select();
            const ok = document.execCommand('copy');
            ta.remove(); return ok;
        } catch (e2) { return false; }
    }
}
function fmtLogs(list, withHeader = true) {
    const lines = list.map(x => `${x.t} ${String(x.l).padEnd(5)} [${x.tag}] ${x.m}`);
    if (!withHeader) return lines.join('\n');
    const on = S.accounts.filter(a => a.state === 'IN_GAME');
    return [
        '=== P4NG Launcher Log Export ===',
        `Time:     ${new Date().toLocaleString('th-TH')}`,
        `Accounts: ${S.accounts.length} (${on.length} in-game)`,
        `Queue:    ${S.jobs.length} jobs${S.paused ? ' (paused)' : ''}`,
        `Auto:     ${S.set.auto ? 'ON' : 'OFF'} · maxrc=${S.set.maxrc}`,
        `Grid:     ${S.set.grid_cols ?? 8}x${S.set.grid_rows ?? 6} · cell ${S.set.cell_w ?? 200}x${S.set.cell_h ?? 150}`,
        `Place ID: ${S.set.place_id}`,
        `Logs shown: ${list.length}`,
        '---', '',
    ].join('\n') + lines.join('\n');
}
async function copyLogs(scope) {
    let list;
    if (scope === 'all') list = S.logs.slice(-200);
    else if (scope === '100') list = S.logs.slice(-100);
    else list = S.logs.filter(lvMatch).slice(-60);
    if (!list.length) { toast('ไม่มี log ให้ copy', 'warn'); return; }
    const ok = await copyText(fmtLogs(list));
    toast(ok ? `Copy ${list.length} บรรทัดแล้ว` : 'Copy ไม่สำเร็จ', ok ? 'ok' : 'err', 2200);
}

/* sound */
let _audioCtx = null;
function beep(freq = 660, dur = 100) {
    if (!S.set.sound) return;
    try {
        _audioCtx = _audioCtx || new (window.AudioContext || window.webkitAudioContext)();
        const o = _audioCtx.createOscillator(), g = _audioCtx.createGain();
        o.frequency.value = freq;
        o.connect(g); g.connect(_audioCtx.destination);
        g.gain.setValueAtTime(.06, _audioCtx.currentTime);
        g.gain.exponentialRampToValueAtTime(.0001, _audioCtx.currentTime + dur / 1000);
        o.start(); o.stop(_audioCtx.currentTime + dur / 1000);
    } catch (e) { }
}

/* ======================================================================
   HELPERS
   ====================================================================== */
function badge(state) {
    const [txt, c, live] = C[state] || C.IDLE;
    return `<span class="badge${live ? ' live' : ''}" style="--c:${c}">${esc(txt)}</span>`;
}
/* helper: timeout wrapper */
function withTimeout(promise, ms) {
    return Promise.race([
        promise,
        new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))
    ]);
}

/* account order */
function applyAccountOrder() {
    const order = S.set.account_order || [];
    if (Array.isArray(order) && order.length) {
        const idx = {};
        order.forEach((id, i) => idx[id] = i);
        S.accounts.sort((a, b) => {
            const ai = idx[a.id] ?? 999999;
            const bi = idx[b.id] ?? 999999;
            return ai - bi;
        });
    }
    /* บัญชีที่ปักหมุดอยู่บนสุดเสมอ (sort เสถียร → ลำดับเดิมในกลุ่มไม่เปลี่ยน) */
    S.accounts.sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0));
}

/* ======================================================================
   MAP CARD — การ์ดแมพมีรูป (ใช้ในหน้าตั้งค่า + หน้าแก้ไขบัญชี)
   o.tag = ป้ายมุมชื่อ · o.own = ไฮไลต์ป้าย · o.actions = html ปุ่มด้านขวา
   ====================================================================== */
function fmtCount(n) {
    n = num(n);
    if (n >= 1e9) return (n / 1e9).toFixed(1).replace(/\.0$/, '') + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
    if (n >= 1e3) return (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
    return String(n);
}
/* ======================================================================
   คลังแมพ (ตั้งค่า → คลังแมพ) — บันทึกชื่อ/รูปของแมพไว้ใน settings.json ครั้งเดียวตอนเพิ่ม
   ทุกที่ที่แสดงแมพอ่านจากคลังนี้ ไม่ต้องดึงจากเว็บ Roblox ซ้ำอีก
   S.set.maps = [{ id, name, icon, banner, creator }]  ·  S.set.place_id = แมพเริ่มต้น (Global)
   ====================================================================== */
const mapLib = () => Array.isArray(S.set.maps) ? S.set.maps : (S.set.maps = []);
const libGet = pid => { pid = num(pid); return pid ? mapLib().find(m => m.id === pid) : null; };
const mapInfo = pid => libGet(pid) || S.gameCache[num(pid)] || null;
const librarySig = () => mapLib().map(m => m.id).join('.') + '|' + num(S.set.place_id);
function libUpsert(pid, info) {
    pid = num(pid); if (!pid || !info) return false;
    const e = { id: pid, name: info.name || '', icon: info.icon || '', banner: info.banner || '', creator: info.creator || '' };
    const lib = mapLib(), i = lib.findIndex(m => m.id === pid);
    if (i >= 0) lib[i] = { ...lib[i], ...e, name: e.name || lib[i].name, icon: e.icon || lib[i].icon, banner: e.banner || lib[i].banner };
    else lib.push(e);
    return true;
}
/* ดึงข้อมูลแมพจากเว็บหนึ่งครั้ง (ใช้ตอนเพิ่มแมพ / รีเฟรช / ย้ายแมพเก่าเข้าคลัง) */
async function fetchMapInfo(pid) {
    try { const r = await api('game_info', num(pid)); return r && r.ok ? r : null; } catch (_) { return null; }
}

function mapCardHtml(pid, o = {}) {
    pid = num(pid);
    const act = o.actions ? `<div class="mc-actions">${o.actions}</div>` : '';
    if (!pid) {
        return `<div class="mapcard is-empty"><div class="mc-body">
            <div class="mc-icon">${ICON.map(26)}</div>
            <div class="mc-info"><div class="mc-name">ยังไม่ได้ตั้งแมพ</div>
              <div class="mc-sub">วางลิงก์เกมหรือ Place ID ด้านล่าง</div></div>${act}</div></div>`;
    }
    const info = mapInfo(pid);
    if (!info) {
        return `<div class="mapcard is-empty"><div class="mc-body">
            <div class="mc-icon">${ICON.map(26)}</div>
            <div class="mc-info"><div class="mc-name">Place ${pid}</div>
              <div class="mc-sub">ยังไม่มีข้อมูลในคลังแมพ</div></div>${act}</div></div>`;
    }
    const bg = (info.banner || info.icon || '').replace(/'/g, '%27').replace(/"/g, '%22');
    return `<div class="mapcard${info.banner ? ' has-banner' : ''}" data-place="${pid}">
        ${bg ? `<div class="mc-bg" style="background-image:url('${esc(bg)}')"></div>` : ''}
        <div class="mc-shade"></div>
        <div class="mc-body">
          <div class="mc-icon">${info.icon ? `<img src="${esc(info.icon)}" alt="" draggable="false">` : '?'}</div>
          <div class="mc-info">
            <div class="mc-name-row">
              <div class="mc-name" title="${esc(info.name || '')}">${esc(info.name || 'Place ' + pid)}</div>
              ${o.tag ? `<span class="mc-tag${o.own ? ' own' : ''}">${esc(o.tag)}</span>` : ''}
            </div>
            ${info.creator ? `<div class="mc-sub">โดย ${esc(info.creator)}</div>` : ''}
            <div class="mc-stats">
              ${info.playing != null ? `<span class="mc-stat live"><i></i>${num(info.playing).toLocaleString('th-TH')} กำลังเล่น</span>` : ''}
              ${info.visits ? `<span class="mc-stat">${ICON.play(9)} ${fmtCount(info.visits)} visits</span>` : ''}
              <span class="mc-stat mono">#${pid}</span>
            </div>
          </div>${act}
        </div></div>`;
}

/* Copy username:password ของบัญชี — อ่านจาก vault ตอนกดเท่านั้น */
async function copyCred(id) {
    const a = S.accounts.find(x => x.id === id);
    try {
        const r = await api('get_credentials', id);
        if (r && r.ok) {
            const ok = await copyText(r.text);
            toast(ok ? `Copy ${a ? a.name : ''}:••••• แล้ว` : 'Copy ไม่สำเร็จ', ok ? 'ok' : 'err', 2000);
            return ok;
        }
        toast((r && r.error) || 'ไม่สำเร็จ', 'warn', 3200, r && r.no_pw ? { sub: 'ใส่ได้ที่ แก้ไขบัญชี' } : {});
    } catch (e) { toast('Copy ไม่สำเร็จ: ' + e, 'err', 3000); }
    return false;
}


/* ======================================================================
   VIEW IN GAME — ดึงหน้าต่าง Roblox ของบัญชีขึ้นมา
   (เดิม viewInGame() ไม่ได้ถูกประกาศไว้ที่ไหนเลย → กดปุ่ม 👁 แล้วไม่มีอะไรเกิดขึ้น)
   ====================================================================== */
async function viewInGame(id) {
    const a = S.accounts.find(x => x.id === id);
    if (!a) return;
    if (!['IN_GAME', 'LOADING', 'LAUNCHING', 'RECONNECTING'].includes(a.state)) {
        toast('บัญชีนี้ยังไม่ได้เปิดเกม', 'warn', 2200);
        return;
    }
    try {
        const r = await api('view_account', id);
        if (!r || !r.ok) toast((r && r.error) || 'เปิดหน้าต่างไม่สำเร็จ', 'warn', 3000);
    } catch (e) { toast('เปิดหน้าต่างไม่สำเร็จ: ' + e, 'err', 3000); }
}



/* ══════════════════════════════════════════════════════════════════════
   05-state
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 05-state.js — รับ state จาก backend + poll */

/* ======================================================================
   STATE
   ====================================================================== */
let _prevStates = {};

function detectTransitions() {
    S.accounts.forEach(a => {
        const prev = _prevStates[a.id];
        if (prev && prev !== a.state) {
            if (a.state === 'ERROR') beep(220, 180);
            else if (a.state === 'IN_GAME') beep(720, 80);
            else if (a.state === 'RECONNECTING') beep(440, 120);
        }
        _prevStates[a.id] = a.state;
    });
}

const LOG_KEEP = 300;

function loadState(st) {
    const dirty = settingsDirty();

    // settings: server ส่งมาเฉพาะตอนเปลี่ยน (เทียบ crc)
    // ถ้ายังไม่ได้ใช้ (หน้าตั้งค่า/กำลังบันทึก) จะถูกส่งซ้ำรอบหน้า
    if (st.settings && S.view !== 'set' && !dirty) {
        Object.assign(S.set, st.settings);
        S.cfgCrc = st.cfg_crc;
    }

    // accounts/jobs/done เป็น null = ไม่เปลี่ยนจากรอบก่อน (ดูที่ acc_sig) → ไม่ต้อง sort/แทนที่ข้อมูลซ้ำ
    if (st.accounts) {
        S.accounts = st.accounts; S.jobs = st.jobs; S.done = st.done; S.accSig = st.acc_sig;
        S.dataChanged = true;
        applyAccountOrder();
    }

    // log: รับเฉพาะบรรทัดใหม่ (delta) แล้วต่อท้าย
    if (st.logs && st.logs.length) {
        const fresh = st.logs.filter(x => (x.i || 0) > S.logSeq && (x.i || 0) > S.clearSeq);
        S.logSeq = st.logs[st.logs.length - 1].i || S.logSeq;
        const _now = Date.now(); fresh.forEach(x => { x.ts = _now; });
        if (fresh.length) {
            S.logs = S.logs.concat(fresh);
            if (S.logs.length > LOG_KEEP) S.logs = S.logs.slice(-LOG_KEEP);
        }
    }

    S.apiPort = st.api_port;
    S.paused = st.paused;
    S.busy = st.busy;
    S.nextAt = st.next_at;
    S.rc = st.rc;
    S.rbxReady = st.rbx_ready !== false;
    S.rbxReason = st.rbx_reason || '';

    // ★ Sweep stats (สำหรับ sidebar) — backend ส่งค่ามาใน state()
    S.spawnedCount = st.spawned_count || 0;
    S.homeStuckCount = st.home_stuck_count || 0;

    if (!dirty) {
    }

    detectTransitions();
}

let _polling = false, _pollT = 0;
const _stateFlags = () => [S.paused, S.busy, S.rc, S.rbxReady, S.rbxReason, S.spawnedCount, S.homeStuckCount, S.apiPort, Math.floor(S.nextAt / 1000)].join('|');

async function poll() {
    if (!S.ready || _polling) return;          // กัน request ซ้อนกันเมื่อ backend ตอบช้า
    _polling = true;
    try {
        const st = await api('state', S.logSeq, S.cfgCrc, S.accSig || 0);
        const logs0 = S.logSeq, cfg0 = S.cfgCrc, flags0 = _stateFlags();
        S.dataChanged = false;
        loadState(st);
        // ไม่มีอะไรเปลี่ยน (บัญชี/คิว/log ใหม่/settings/ธง) → ข้าม render ทั้งรอบ
        if (S.dataChanged || S.logSeq !== logs0 || S.cfgCrc !== cfg0 || _stateFlags() !== flags0 || S.forceRender
            || S.view === 'queue') {      // หน้าคิวมีตัวนับถอยหลัง (ETA) ต้องอัปเดตทุกรอบ
            S.forceRender = false;
            render();
        }
    } catch (e) { }
    _polling = false;
}

function pollLoop() {                          // self-scheduling: เร็วเมื่อเห็นหน้าจอ, ช้าเมื่อซ่อน
    clearTimeout(_pollT);
    _pollT = setTimeout(async () => {
        await poll();
        pollLoop();
    }, pollDelay());
}

// เร็ว (1s) เมื่อมีบัญชีกำลังทำงาน/เปิดหน้า dash-console, ช้าลงเมื่อไม่มีอะไรเปลี่ยน, ช้าสุดเมื่อซ่อนหน้าต่าง
function pollDelay() {
    if (document.hidden) return 4000;
    const busy = S.busy || S.jobs.length || S.accounts.some(a =>
        a.state !== 'IDLE' && a.state !== 'ERROR' && a.state !== 'COOLDOWN');
    if (busy || S.view === 'console') return (S.view === 'set' || S.view === 'queue') ? 2000 : 1000;
    return 2500;
}

document.addEventListener('visibilitychange', () => {
    document.documentElement.classList.toggle('is-hidden', document.hidden);
    if (!document.hidden) {
        poll();
        pollLoop();
    }
});


/* ══════════════════════════════════════════════════════════════════════
   06a-account-card
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 06a-account-row.js — การ์ดบัญชี (ใช้ร่วม: หน้าหลัก = compact · หน้าบัญชี = full)
   สร้างครั้งเดียวด้วย accCard() แล้วอัปเดตเฉพาะ cell ที่เปลี่ยนด้วย patchAccRow() — ไม่ rebuild ทั้งการ์ด */

const BUSY = ['IN_GAME', 'LOADING', 'LAUNCHING', 'AUTHENTICATING', 'QUEUED', 'RECONNECTING'];
const running = a => !!a.active || BUSY.includes(a.state);

function avatarHtml(a, cls = '') {
    return `<div class="av ${cls}">${a.avatar_url
        ? `<img src="${esc(a.avatar_url)}" alt="" loading="lazy" draggable="false">`
        : esc((a.name[0] || '?').toUpperCase())}</div>`;
}

const HEALTH_MAP = {
    ok:       { ic: 'check', cls: 'is-ok',   tip: 'cookie ใช้ได้ · ไม่โดนแบน' },
    banned:   { ic: 'ban',   cls: 'is-bad',  tip: 'บัญชีถูกแบน' },
    cookie:   { ic: 'key',   cls: 'is-warn', tip: 'cookie หมดอายุ · เพิ่มบัญชีใหม่' },
    nocookie: { ic: 'key',   cls: 'is-warn', tip: 'ไม่มี cookie ใน vault' },
    checking: { ic: 'alert', cls: '',        tip: 'กำลังตรวจ…' },
};
function healthChipHtml(a) {
    const h = HEALTH_MAP[a.health];
    return h && a.health !== 'ok' ?       /* ปกติไม่แสดง — โชว์เฉพาะเมื่อมีปัญหา/กำลังตรวจ (การ์ดจะได้ไม่รก) */ `<span class="chip ${h.cls}" data-tip="${h.tip}">${ICON[h.ic](11)}</span>` : '';
}

function mapChipHtml(a) {
    const pid = num(a.place_id) || num(S.set.place_id);
    if (!pid) return `<span class="chip none" data-tip="ยังไม่ได้ตั้ง Place ID">${ICON.map(11)}<span>ยังไม่ตั้งแมพ</span></span>`;
    const info = mapInfo(pid);
    if (!info) {
        return `<span class="chip" data-tip="ยังไม่มีข้อมูลในคลังแมพ">${ICON.map(11)}<span>Place ${pid}</span></span>`;
    }
    const name = info.name || `Place ${pid}`;
    const tip = `${name}\nPlace ID: ${pid}`;
    return `<span class="chip" data-tip="${esc(tip)}">${info.icon ? `<img src="${esc(info.icon)}" alt="">` : ICON.map(11)}<span>${esc(name)}</span></span>`;
}

/* CPU / RAM — ทุกการ์ดมีสองช่องนี้เสมอ (ไม่อยู่ในเกม = ช่องจางว่าง) เพื่อให้การ์ดสูงเท่ากันและไม่ขยับตอนเริ่ม/หยุด */
function resChipsHtml(a) {
    const live = a.state === 'IN_GAME' || a.state === 'LOADING';
    const ghost = (k) => `<span class="chip ghost">${k} —</span>`;
    let cpu = ghost('CPU'), ram = ghost('RAM');
    if (live && a.cpu > 0) {
        const lvl = a.cpu < 30 ? 'lo' : a.cpu < 70 ? 'mid' : 'hi';
        cpu = `<span class="chip ${lvl}" data-tip="CPU: ${a.cpu.toFixed(1)}%">CPU ${a.cpu < 10 ? a.cpu.toFixed(1) : a.cpu.toFixed(0)}%</span>`;
    }
    if (live && a.ram > 0) {
        const txt = a.ram >= 1024 ? (a.ram / 1024).toFixed(2) + ' GB' : a.ram.toFixed(0) + ' MB';
        ram = `<span class="chip" data-tip="RAM: ${a.ram.toFixed(0)} MB">RAM ${txt}</span>`;
    }
    return cpu + ram;
}

function accCardActions(a, full) {
    const run = running(a);
    const go = run
        ? `<button class="ac-go stop" type="button" data-act="stop" data-id="${a.id}" data-tip="หยุด · ปิดเกมทันที">${ICON.stop(12)}<span>หยุด</span></button>`
        : `<button class="ac-go play" type="button" data-act="start" data-id="${a.id}" data-tip="เริ่ม">${ICON.play(12)}<span>เริ่ม</span></button>`;
    /* แก้ไข / ดูหน้าต่าง / คัดลอก / ลบ ฯลฯ อยู่ในเมนูคลิกขวา (หรือปุ่ม ⋯ นี้) */
    return go + `<button class="ibtn" type="button" data-act="acc-menu" data-id="${a.id}" data-tip="เมนูเพิ่มเติม · คลิกขวาที่การ์ดก็ได้">${ICON.more(16)}</button>`;
}

/* เนื้อหาของแต่ละ cell ในการ์ดบัญชี (patch เฉพาะ cell ที่เปลี่ยน) */
function accCells(a, full) {
    const c = C[a.state] || C.IDLE;
    return {
        t: `<span class="nm">${esc(a.name)}</span>${pinBtnHtml(a)}`,
        sub: `<span${a.user_id ? ` data-tip="Roblox uid ${a.user_id}"` : ''}>ID ${a.id}</span>`,
        st: `<span class="st-tx${c[2] ? ' live' : ''}" style="--c:${c[1]}">${esc(c[0])}</span>${healthChipHtml(a)}`,
        m: mapChipHtml(a) + (!full && a.auto_exec ? `<span class="chip">${ICON.bolt(11)}<span>Auto-Exec</span></span>` : ''),
        res: resChipsHtml(a),
        act: accCardActions(a, full),
    };
}

/* ปุ่มปักหมุด (ดาว) — อยู่ต่อท้ายชื่อ · ปักแล้วขึ้นบนสุดของรายการ */
function pinBtnHtml(a) {
    return `<button class="pin-b${a.pinned ? ' on' : ''}" type="button" data-act="pin" data-id="${a.id}" aria-pressed="${!!a.pinned}" data-tip="${a.pinned ? 'เลิกปักหมุด' : 'ปักหมุดไว้บนสุด'}">${ICON.star(13)}</button>`;
}

/* การ์ดบัญชี — ใช้ร่วม: หน้าหลัก (compact) · หน้าบัญชี (full) */
function accCard(a, full) {
    const c = accCells(a, full), sel = S.sel.has(a.id);
    return `<div class="acard${full ? ' full' : ''}${sel ? ' sel' : ''}${a.pinned ? ' pinned' : ''}" data-row="${a.id}" style="--c:${(C[a.state] || C.IDLE)[1]}">
      ${full ? `<button class="chk" type="button" data-act="sel" data-id="${a.id}" aria-pressed="${sel}" aria-label="เลือกบัญชี ${esc(a.name)}">${ICON.check(12)}</button>` : ''}
      <div class="ac-top">
        <div class="av-w">${avatarHtml(a, 'lg')}<i class="av-dot"></i></div>
        <div class="ac-id">
          <div class="ac-name" ${cellAttr('t', c.t)}>${c.t}</div>
          <div class="ac-meta">
            <span class="ac-st" ${cellAttr('st', c.st)}>${c.st}</span>
            ${full ? `<span class="ac-sub" ${cellAttr('sub', c.sub)}>${c.sub}</span>` : ''}
          </div>
        </div>
      </div>
      <div class="ac-info" ${cellAttr('m', c.m)}>${c.m}</div>
      <div class="ac-res" ${cellAttr('res', c.res)}>${c.res}</div>
      <div class="ac-act" ${cellAttr('act', c.act)}>${c.act}</div>
    </div>`;
}

function patchAccRow(row, a, full) {
    row.style.setProperty('--c', (C[a.state] || C.IDLE)[1]);
    const sel = S.sel.has(a.id);
    row.classList.toggle('sel', sel);
    row.classList.toggle('pinned', !!a.pinned);
    const cb = row.querySelector('.chk');
    if (cb && cb.getAttribute('aria-pressed') !== String(sel)) cb.setAttribute('aria-pressed', sel);
    const c = accCells(a, full);
    for (const k of ['t', 'sub', 'st', 'm', 'res', 'act']) setCell(row.querySelector(`[data-cell="${k}"]`), c[k]);
}

function patchAccRows(root, full) {
    if (!root) return;
    root.querySelectorAll('.acard[data-row]').forEach(row => {
        const a = S.accounts.find(x => x.id === +row.dataset.row);
        if (a) patchAccRow(row, a, full);
    });
}

/* ══════════════════════════════════════════════════════════════════════
   06-view-dash
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 06-view-dash.js — หน้าหลัก (ประกอบจาก UI kit + แถวบัญชีร่วม) */

const Views = {};

/* ตัวเลขรวมของหน้าหลัก */
function fleetStats() {
    const A = S.accounts;
    return {
        on: A.filter(a => a.state === 'IN_GAME').length,
        cpu: A.reduce((s, a) => s + (a.cpu || 0), 0),
        ram: A.reduce((s, a) => s + (a.ram || 0), 0) / 1024,
        attn: A.filter(a => a.state === 'ERROR' || a.health === 'banned').length + (S.homeStuckCount || 0),
    };
}

/* แถบสถานะรวมของทุกบัญชี — อ่านภาพรวมได้ในแวบเดียว */
function fleetBar(A) {
    const groups = [
        ['ในเกม',      '#3ddc97', ['IN_GAME'], true],
        ['กำลังเริ่ม', '#9d7bff', ['QUEUED', 'AUTHENTICATING', 'LAUNCHING', 'LOADING', 'RECONNECTING']],
        ['ว่าง',       '#6d758d', ['IDLE', 'COOLDOWN']],
        ['ผิดพลาด',    '#ff6b7a', ['ERROR']],
    ].map(([label, color, sts, live]) => ({ label, color, live, n: A.filter(a => sts.includes(a.state)).length }));
    const segs = groups.filter(g => g.n).map(g =>
        `<i class="${g.live ? 'live' : ''}" style="flex-grow:${g.n};--c:${g.color}"></i>`).join('') || '<i style="--c:var(--s3)"></i>';
    const key = groups.map(g => `<span><i style="--c:${g.color}"></i>${g.label} <b>${g.n}</b></span>`).join('');
    return `<div class="fleet" role="img" aria-label="${groups.map(g => g.label + ' ' + g.n).join(', ')}">
        <div class="fleet-bar">${segs}</div><div class="fleet-key">${key}</div></div>`;
}

const laneIcon = () => S.busy ? ICON.play(12) : ICON.pause(12);

function heroSub() {
    const stuck = S.homeStuckCount || 0;
    return `${S.jobs.length} งานในคิว · ${S.busy ? 'lane ทำงาน' : 'lane ว่าง'}`
        + (stuck ? ` · <b style="color:var(--warn)">${stuck} ค้าง</b>` : '');
}

/* แถวสถานะระบบ (การ์ดขวาของหน้าหลัก) */
function sysRows() {
    const row = (label, val, st = '') => `<div class="sys-r"><span>${label}</span><b class="${st}">${val}</b></div>`;
    return row('api.lua', S.apiPort ? `พร้อม · :${S.apiPort}` : 'ออฟไลน์', S.apiPort ? 'ok' : 'bad')
        + row('Multi-instance', S.rbxReady ? 'พร้อมใช้งาน' : 'ไม่พร้อม', S.rbxReady ? 'ok' : 'bad')
        + row('Launch lane', S.paused ? 'พักอยู่' : (S.busy ? 'กำลังทำงาน' : 'ว่าง'), S.paused ? 'warn' : '');
}

Views.dash = {
    key: () => 'dash:' + S.accounts.map(a => a.id).join(','),

    html() {
        const A = S.accounts, f = fleetStats();
        return `
          ${UI.head('หน้าหลัก', {
              sub: 'ภาพรวมบัญชีและระบบแบบเรียลไทม์',
              r: `<button class="btn" type="button" data-act="add-account">${ICON.plus(14)} เพิ่มบัญชี</button>`,
          })}

          <div class="brand-strip">
            <img src="img/banner-wide.png" width="1200" height="200" alt="P4NG Roblox Account Manager" decoding="async">
          </div>

          <section class="card ov">
            <div class="ov-l">
              <div class="k"><i class="live-dot"></i>ในเกมตอนนี้</div>
              <div class="ov-n"><b data-stat="on">${f.on}</b><span>จาก ${A.length} บัญชี</span></div>
              <div id="dash-fleet" ${cellAttr('f', fleetBar(A))}>${fleetBar(A)}</div>
              <div class="hero-sub" data-stat="sub">${heroSub()}</div>
            </div>
            <div class="ov-r">
              ${UI.stats([
                ['cpu',  'CPU รวม',    `${f.cpu.toFixed(0)}<small>%</small>`,  { ic: 'cpu',   c: 'var(--info)' }],
                ['ram',  'RAM รวม',    `${f.ram.toFixed(1)}<small>GB</small>`, { ic: 'chart', c: 'var(--ac-2)' }],
                ['jobs', 'คิว / LANE', `${S.jobs.length}<small>${laneIcon()}</small>`, { ic: 'queue', c: 'var(--warn)', act: 'go', v: 'queue' }],
                ['attn', 'ต้องดูแล',   `${f.attn}`, { ic: 'alert', c: f.attn ? 'var(--err)' : 'var(--tx-3)' }],
              ])}
            </div>
          </section>

          <div class="dash-grid">
            <div class="dash-main">
              ${A.length ? `
                ${UI.sec('บัญชี', A.length, `<button class="btn ghost" data-act="go" data-v="acc">จัดการทั้งหมด ${ICON.chevR(12)}</button>`)}
                <div class="agrid" id="dash-list">${A.map(a => accCard(a, false)).join('')}</div>
              ` : UI.empty(ICON.plus(24), 'ยังไม่มีบัญชี', 'เริ่มด้วยการเพิ่มบัญชี Roblox',
                    `<button class="btn pri" data-act="add-account">${ICON.plus(14)} เพิ่มบัญชี</button>`)}
            </div>
            <aside class="dash-side">
              ${UI.card('สถานะระบบ', `<div id="dash-sys" ${cellAttr('s', sysRows())}>${sysRows()}</div>`, { icon: ICON.shield(13) })}
              ${UI.card('เหตุการณ์ล่าสุด', `<div class="csl-body mini" id="dash-log-list">${logHtml(S.logs.filter(x => x.l !== 'DEBUG').slice(-6))}</div>`,
                  { icon: ICON.console(13), flush: true, right: `<button class="btn ghost sm" data-act="go" data-v="console">ดูทั้งหมด ${ICON.chevR(12)}</button>` })}
            </aside>
          </div>`;
    },

    patch() {
        const f = fleetStats();
        UI.setStats({
            on: `${f.on}`,
            sub: heroSub(),
            cpu: `${f.cpu.toFixed(0)}<small>%</small>`,
            ram: `${f.ram.toFixed(1)}<small>GB</small>`,
            jobs: `${S.jobs.length}<small>${laneIcon()}</small>`,
            attn: [`${f.attn}`, f.attn ? 'var(--err)' : 'var(--tx-3)'],
        });
        setCell($('#dash-fleet'), fleetBar(S.accounts));
        setCell($('#dash-sys'), sysRows());
        patchAccRows($('#dash-list'), false);
        setCell($('#dash-log-list'), logHtml(S.logs.filter(x => x.l !== 'DEBUG').slice(-6)));
    },
};

/* ══════════════════════════════════════════════════════════════════════
   07-view-accounts
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 07-view-accounts.js — หน้า บัญชี (UI kit + แถวบัญชีร่วม · ปุ่มทั้งหมดผ่าน ACT ใน 12-render-actions) */

const ACC_ATTN = a => a.state === 'ERROR' || ['banned', 'cookie', 'nocookie'].includes(a.health);
const ACC_TABS = [
    ['ALL',    'ทั้งหมด',   () => true],
    ['ONLINE', 'ออนไลน์',   a => a.state === 'IN_GAME'],
    ['IDLE',   'ว่าง',      a => a.state === 'IDLE'],
    ['ATTN',   'ต้องดูแล',  ACC_ATTN],
];

function accVisible() {
    const q = S.accSearch.trim().toLowerCase();
    const tab = ACC_TABS.find(t => t[0] === S.accFilter) || ACC_TABS[0];
    return S.accounts.filter(a => tab[2](a) && (!q
        || a.name.toLowerCase().includes(q)
        || String(a.id).includes(q)
        || (a.desc || '').toLowerCase().includes(q)));
}

function accSummary() {
    const A = S.accounts, attn = A.filter(ACC_ATTN).length;
    return {
        all: [`${A.length}`], on: [`${A.filter(a => a.state === 'IN_GAME').length}`],
        idle: [`${A.filter(a => a.state === 'IDLE').length}`],
        attn: [`${attn}`, attn ? 'var(--err)' : 'var(--tx-3)'],
    };
}

/* ── เลือกหลายบัญชี ─────────────────────────────────────────────────
   ปุ่ม "เลือก" เปิดโหมดเลือก → แต่ละแถวมีวงกลมเลือกทางซ้าย · คลิกที่แถวเพื่อเลือก · Shift+คลิกเลือกเป็นช่วง
   Ctrl+A เลือกทั้งหมดที่เห็น · Esc ออก · แถบเครื่องมือลอยอยู่ล่างจอ (#selbar) */
const SEL_BY = [
    ['idle',   'ที่ว่าง',          a => a.state === 'IDLE'],
    ['online', 'ที่อยู่ในเกม',     a => a.state === 'IN_GAME'],
    ['attn',   'ที่ต้องดูแล',      ACC_ATTN],
    ['invert', 'กลับด้านการเลือก', null],
];

function selectBy(key) {
    const vis = accVisible();
    if (key === 'invert') { vis.forEach(a => S.sel.has(a.id) ? S.sel.delete(a.id) : S.sel.add(a.id)); }
    else { const f = SEL_BY.find(x => x[0] === key)[2]; S.sel = new Set(vis.filter(f).map(a => a.id)); }
    if (!S.sel.size) { toast('ไม่มีบัญชีที่ตรงเงื่อนไข', 'warn', 1800); return autoExitSel(); }
    S.selMode = true;
    paintSel();
}
/* ไม่มีบัญชีไหนถูกเลือก → ออกจากโหมดเลือกทันที */
function autoExitSel() {
    if (S.selMode && !S.sel.size) { setSelMode(false); return true; }
    return false;
}
function setSelMode(on) {
    S.selMode = on;
    if (!on) { S.sel.clear(); S.selAnchor = 0; }
    rerender();                                         // โครงสร้างแถบเครื่องมือเปลี่ยน
}
function toggleSel(id, range) {
    const vis = accVisible().map(a => a.id);
    if (range && S.selAnchor && vis.includes(S.selAnchor) && vis.includes(id)) {
        const i = vis.indexOf(S.selAnchor), j = vis.indexOf(id);
        vis.slice(Math.min(i, j), Math.max(i, j) + 1).forEach(x => S.sel.add(x));
    } else {
        S.sel.has(id) ? S.sel.delete(id) : S.sel.add(id);
        S.selAnchor = id;
    }
    if (!S.selMode) { S.selMode = true; rerender(); return; }
    if (autoExitSel()) return;
    paintSel();
}
/* อัปเดตสถานะการเลือกทั้งหน้าในที่เดิม (ไม่สร้างแถวใหม่ จึงไม่กระตุก/เลื่อนหาย) */
function paintSel() {
    const list = $('#acc-list');
    if (list) {
        list.classList.toggle('selmode', S.selMode);
        list.querySelectorAll('.acard[data-row]').forEach(row => {
            const on = S.sel.has(+row.dataset.row);
            row.classList.toggle('sel', on);
            const cb = row.querySelector('.chk');
            if (cb && cb.getAttribute('aria-pressed') !== String(on)) cb.setAttribute('aria-pressed', on);
        });
    }
    const vis = accVisible(), n = vis.filter(a => S.sel.has(a.id)).length;
    const all = $('[data-sel-all]');
    if (all) {
        all.dataset.state = n === 0 ? 'none' : n === vis.length ? 'all' : 'some';
        const em = all.querySelector('em'); if (em) em.textContent = `${n}/${vis.length}`;
    }
    paintSelBar();
}
function selBarHtml() {
    const sel = S.accounts.filter(a => S.sel.has(a.id));
    const act = sel.filter(running).length, idle = sel.length - act;
    const b = (cls, a, tip, inner) => `<button class="btn ${cls}" type="button" data-act="${a}" data-tip="${tip}">${inner}</button>`;
    return `
      <button class="ibtn" type="button" data-act="sel-clear" data-tip="ออกจากโหมดเลือก (Esc)">${ICON.close(14)}</button>
      <div class="sb-n">${sel.length
          ? `<b class="mono">${sel.length}</b><span>เลือกแล้ว</span>`
          : `<span class="mu">แตะที่แถวเพื่อเลือกบัญชี</span>`}</div>
      ${sel.length ? `
        <i class="sb-sp"></i>
        ${idle ? b('pri', 'bulk-open', 'เปิดเกมบัญชีที่ว่าง', `${ICON.play(12)} เปิดเกม <b>${idle}</b>`) : ''}
        ${act ? b('warn', 'bulk-stop', 'หยุดบัญชีที่กำลังทำงาน', `${ICON.stop(12)} หยุด <b>${act}</b>`) : ''}
        ${b('', 'bulk-check', 'ตรวจ cookie / แบน เฉพาะที่เลือก', `${ICON.shield(12)} ตรวจ`)}
        <i class="sb-sp"></i>
        <button class="ibtn danger-i" type="button" data-act="bulk-delete" data-tip="ลบบัญชีที่เลือก">${ICON.trash(14)}</button>` : ''}`;
}
function paintSelBar() {
    const bar = $('#selbar'); if (!bar) return;
    const on = S.view === 'acc' && S.selMode;
    document.body.classList.toggle('has-selbar', on);
    bar.classList.toggle('show', on);
    bar.setAttribute('aria-hidden', String(!on));
    if (on) setCell($('#selbar .sb-in'), selBarHtml());
}
$('#selbar').addEventListener('click', e => {
    const el = e.target.closest('[data-act]');
    if (el && !el.disabled && ACT[el.dataset.act]) ACT[el.dataset.act](el, e);
});
/* คลิกที่แถวเพื่อเลือก (เฉพาะโหมดเลือก · ไม่ทับปุ่ม/ป้ายที่กดได้ในแถว) */
$('#main').addEventListener('click', e => {
    if (!S.selMode || S.view !== 'acc') return;
    const row = e.target.closest('.acard[data-row]');
    if (!row || e.target.closest('button, a, input, .chip.btn-like')) return;
    toggleSel(+row.dataset.row, e.shiftKey);
    if (e.shiftKey) getSelection()?.removeAllRanges();
});
document.addEventListener('keydown', e => {
    if (S.view !== 'acc' || document.querySelector('#modal-root .overlay') || DD.menu) return;
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.target.isContentEditable) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a') {
        e.preventDefault();
        accVisible().forEach(a => S.sel.add(a.id));
        S.selMode = true; rerender();
    } else if (e.key === 'Escape' && S.selMode) { setSelMode(false); }
});

/* ช่องตัวเลขด้านบน = ตัวกรองด้วย: ช่องที่กำลังกรองอยู่ไฮไลต์ · กดซ้ำเพื่อกลับเป็นทั้งหมด */
function paintTiles() {
    $$('.stat[data-act="tab"]').forEach(el => el.classList.toggle('on', S.accFilter !== 'ALL' && el.dataset.v === S.accFilter));
}

Views.acc = {
    key: () => 'acc:' + S.selMode + ':' + S.accFilter + ':' + S.accSearch + ':' + accVisible().map(a => a.id).join(','),

    html() {
        const list = accVisible(), filtered = !!S.accSearch.trim() || S.accFilter !== 'ALL';
        const allSel = list.length > 0 && list.every(a => S.sel.has(a.id));
        const sm = accSummary();

        return `
          ${UI.head('บัญชี', {
              sub: 'จัดการบัญชี Roblox ทั้งหมด — เปิด/หยุด ตรวจสถานะ และเลือกหลายบัญชีพร้อมกัน',
              r: `${UI.search('data-search', S.accSearch, 'ค้นหาชื่อ / ID / โน้ต…', 'search-clear')}
                  <button class="btn pri" type="button" data-act="add-account">${ICON.plus(14)} เพิ่มบัญชี</button>`,
          })}

          ${UI.stats([
              ['all',  'ทั้งหมด',    sm.all[0],  { ic: 'users',  c: 'var(--ac-2)', act: 'tab', v: 'ALL' }],
              ['on',   'ออนไลน์',    sm.on[0],   { ic: 'bolt',   c: 'var(--ok)',   act: 'tab', v: 'ONLINE' }],
              ['idle', 'ว่าง',       sm.idle[0], { ic: 'moon',   c: 'var(--tx-2)', act: 'tab', v: 'IDLE' }],
              ['attn', 'ต้องดูแล',   sm.attn[0], { ic: 'alert',  c: sm.attn[1], act: 'tab', v: 'ATTN' }],
          ])}

          ${list.length ? `<div class="toolbar">
              <button class="btn${S.selMode ? ' on' : ''}" type="button" data-act="sel-mode" aria-pressed="${S.selMode}" data-tip="${S.selMode ? 'ออกจากโหมดเลือก (Esc)' : 'เลือกหลายบัญชีเพื่อจัดการพร้อมกัน (Ctrl+A = ทั้งหมด)'}">${ICON.listChecks(13)} เลือก</button>
              ${S.selMode ? `
                <button class="btn sel-all" type="button" data-act="sel-all" data-sel-all data-state="${allSel ? 'all' : S.sel.size ? 'some' : 'none'}">
                  <span class="tri">${ICON.check(11)}${ICON.minus(11)}</span>เลือกทั้งหมด <em class="mono">${list.filter(a => S.sel.has(a.id)).length}/${list.length}</em></button>
                ${DD.html('sel-by', SEL_BY.map(([k, l]) => [k, l]), '', { placeholder: 'เลือกตาม…', sticky: false, onPick: selectBy })}` : ''}
              <div class="sp"></div>
              <button class="btn" type="button" data-act="check-health" data-tip="ตรวจ cookie และสถานะแบน">${ICON.shield(12)} ตรวจสถานะ</button>
            </div>` : ''}

          ${list.length
              ? `<div class="agrid${S.selMode ? ' selmode' : ''}" id="acc-list">${list.map(a => accCard(a, true)).join('')}</div>`
              : (S.accounts.length && filtered
                  ? UI.empty(ICON.search(24), 'ไม่พบบัญชีที่ตรงกับตัวกรอง', 'ลองกดช่องตัวเลขด้านบนอีกครั้ง หรือเปลี่ยนคำค้น',
                      `<button class="btn" type="button" data-act="clear-filter">ล้างตัวกรอง</button>`)
                  : UI.empty(ICON.users(24), 'ยังไม่มีบัญชี', 'เริ่มด้วยการเพิ่มบัญชี Roblox ที่ต้องการจัดการ',
                      `<button class="btn pri" type="button" data-act="add-account">${ICON.plus(14)} เพิ่มบัญชี</button>`))}`;
    },

    mount() {
        paintTiles();
        const s = $('[data-search]');
        if (!s) return;
        s.oninput = () => {
            S.accSearch = s.value;
            const pos = s.selectionStart;
            render();
            const s2 = $('[data-search]');
            if (s2) { s2.focus(); s2.setSelectionRange(pos, pos); }
        };
    },

    patch() {
        UI.setStats(accSummary());
        patchAccRows($('#acc-list'), true);
        paintTiles();
        paintSel();
    },
};

/* ── เมนูเพิ่มบัญชี ─────────────────────────────────────────── */
function openAddMenu(anchor) {
    document.querySelectorAll('.menu').forEach(m => m.remove());
    const menu = document.createElement('div');
    menu.className = 'menu';
    const item = (m, ic, t, d, pri) => `<div class="menu-i${pri ? ' pri' : ''}" data-method="${m}">
        <div class="ic-box">${ic}</div><div><b>${t}</b><small>${d}</small></div></div>`;
    menu.innerHTML =
        item('Import', ICON.download(16), 'Import', 'วาง user:pass ทีละบรรทัด · แนะนำ', true)
        + item('Cookie', ICON.cookie(16), 'Cookie', 'วาง .ROBLOSECURITY')
        + item('Browser login', ICON.globe(16), 'Browser Login', 'ล็อกอินผ่านหน้าต่างเบราว์เซอร์')
        + item('Quick Login', ICON.bolt(16), 'Quick Login', 'ยืนยันผ่านอุปกรณ์ที่ล็อกอินอยู่');
    positionMenu(menu, anchor);
    const close = e => {
        if (e && menu.contains(e.target)) return;
        menu.remove();
        document.removeEventListener('mousedown', close);
    };
    setTimeout(() => document.addEventListener('mousedown', close), 0);
    menu.querySelectorAll('.menu-i').forEach(el => el.onclick = () => {
        close();
        el.dataset.method === 'Import' ? bulkImport() : addAccount(el.dataset.method);
    });
}

function positionMenu(menu, anchor) {
    const r = anchor.getBoundingClientRect(), M = 8, G = 8;
    menu.style.visibility = 'hidden';
    document.body.appendChild(menu);
    const mw = menu.offsetWidth, mh = menu.offsetHeight;
    const x = Math.max(M, Math.min(r.right - mw, innerWidth - mw - M));
    const down = innerHeight - r.bottom - G - M >= mh || r.top < mh + G + M;
    menu.style.left = x + 'px';
    menu.style.top = (down ? r.bottom + G : r.top - mh - G) + 'px';
    menu.style.visibility = '';
    requestAnimationFrame(() => menu.classList.add('in'));
}

/* ══════════════════════════════════════════════════════════════════════
   09-view-queue
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 09-view-queue.js — หน้า คิว (UI kit เดียวกับหน้าอื่น) */

/* ═══ QUEUE ═══════════════════════════════════════════════════ */
const JOB_TYPES = {
    LAUNCH:       [() => ICON.play(14),    'var(--ac-2)', 'เปิดเกม'],
    REJOIN:       [() => ICON.refresh(14), 'var(--warn)', 'เชื่อมใหม่'],
    KILL:         [() => ICON.stop(14),    'var(--err)',  'ปิดเกม'],
    APPLY_LAYOUT: [() => ICON.grid(14),    'var(--info)', 'จัดหน้าต่าง'],
};
const jobType = t => JOB_TYPES[t] || [() => ICON.dot(10), 'var(--tx-3)', t];
const etaText = nb => { const s = Math.max(0, Math.round((nb - Date.now()) / 1000)); return s <= 0 ? 'พร้อมเริ่ม' : 'เริ่มใน ' + s + ' วิ'; };
const laneText = () => {
    const wait = S.nextAt > Date.now() ? Math.ceil((S.nextAt - Date.now()) / 1000) : 0;
    return S.busy ? 'กำลังทำงาน' : (wait ? 'รอ ' + wait + ' วิ' : 'ว่าง');
};

function queueStats() {
    const run = S.jobs.filter(j => j.state === 'RUNNING').length, pend = S.jobs.filter(j => j.state === 'PENDING').length;
    return {
        lane: [laneText(), S.busy ? 'var(--ac-2)' : 'var(--tx)'],
        rp: [`${run}<small>/ ${pend}</small>`],
        done: [`${S.done.length}`],
        err: [`${S.rc}`, S.rc ? 'var(--warn)' : 'var(--tx)'],
    };
}

function queueJobRow(j) {
    const a = S.accounts.find(x => x.id === j.acc), run = j.state === 'RUNNING';
    const att = j.attempts || 0, [ic, color, label] = jobType(j.type), nb = j.nb || 0;
    return `<div class="row${run ? ' is-run' : ''}" data-job="${j.id}" style="--c:${color}">
      <div class="ic-box">${ic()}</div>
      <div class="row-main">
        <div class="row-t"><span class="nm">${esc(a ? a.name : 'ทั้งหมด')}</span><span class="chip">${label}</span></div>
        <div class="row-m">
          <span class="mono" data-tip="หมายเลขงาน">#${j.id}</span>
          <span class="mono" data-tip="ความสำคัญ (0 = สูงสุด)">P${j.pri}</span>
          <span class="mono${att ? ' is-warn' : ''}" data-tip="จำนวนครั้งที่ลอง">ลอง ${att}/${j.max_attempts || 3}</span>
        </div>
      </div>
      <div class="row-val">${run ? '<span class="badge live" style="--c:var(--ac)">กำลังรัน</span>' : `<span data-eta="${nb}">${nb ? etaText(nb) : 'พร้อมเริ่ม'}</span>`}</div>
    </div>`;
}

Views.queue = {
    key: () => 'queue:' + S.jobs.map(j => `${j.id}${j.state}${j.attempts || 0}`).join(',')
        + ':' + S.paused,

    html() {
        const pend = S.jobs.filter(j => j.state === 'PENDING'), run = S.jobs.filter(j => j.state === 'RUNNING');
        const q = queueStats();
        const group = (title, list) => list.length
            ? `${UI.sec(title, list.length)}<div class="list">${list.map(queueJobRow).join('')}</div>` : '';

        return `
          ${UI.head('คิวงาน', {
              sub: 'ลำดับการเปิดเกมของแต่ละบัญชี พร้อมตัวนับถอยหลัง · คลิกขวาที่งานเพื่อยกเลิก',
              l: S.paused ? `<span class="badge live" style="--c:var(--warn)">พักอยู่</span>` : '',
              r: S.jobs.length ? `
                <button class="btn" type="button" data-act="pause">${S.paused ? ICON.play(12) + ' เดินคิวต่อ' : ICON.pause(12) + ' พักคิว'}</button>
                ${pend.length ? `<button class="btn danger" type="button" data-act="cancel-all" data-tip="ยกเลิกทุกงานที่ยังไม่เริ่ม">${ICON.close(12)} ยกเลิกที่รอ (${pend.length})</button>` : ''}` : '',
          })}

          ${UI.stats([
              ['lane', 'Launch lane',        q.lane[0], { c: q.lane[1] }],
              ['rp',   'กำลังรัน / รอคิว',   q.rp[0]],
              ['done', 'เสร็จรอบนี้',        q.done[0]],
              ['err',  'ผิดพลาดสะสม',        q.err[0], { c: q.err[1] }],
          ])}

          ${S.jobs.length
              ? group('กำลังรัน', run) + group('รอคิว', pend)
              : UI.empty(ICON.check(24), 'คิวว่าง', 'ไม่มีงานค้างอยู่ · เพิ่มงานได้ที่หน้าบัญชี')}`;
    },

    patch() {
        UI.setStats(queueStats());
        $$('[data-eta]').forEach(el => {
            const nb = +el.dataset.eta;
            if (!nb) return;
            const t = etaText(nb);
            if (el.textContent !== t) el.textContent = t;
        });
    },
};

/* ══════════════════════════════════════════════════════════════════════
   10-view-console
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 10-view-console.js — ตัวแสดง log + หน้า คอนโซล */

/* ======================================================================
   LOG RENDER — detailed view
   ====================================================================== */
/* ตัวกรองระดับ: IMPORTANT = INFO/WARN/ERROR (ซ่อน DEBUG) · ALL = ละเอียดทั้งหมด */
const lvMatch = x => S.filter === 'ALL' || (S.filter === 'IMPORTANT' ? x.l !== 'DEBUG' : x.l === S.filter);

const LOG_COLORS = {
    DEBUG: '#6d758d', INFO: '#9d7bff', WARN: '#f5b84b', ERROR: '#ff6b7a'
};
const LOG_ICONS = { DEBUG: ICON.dot(8), INFO: ICON.info(12), WARN: ICON.alert(12), ERROR: ICON.close(12) };

function hlLog(s) {
    let t = s;

    // 1) quoted strings
    t = t.replace(/&quot;([^&]*?)&quot;/g,
        '&quot;<span class="hl-str">$1</span>&quot;');

    // 2) HTTP codes + status
    t = t.replace(/\b(HTTP\s*\d{3}|401|403|404|409|415|429|500|502|503|504)\b/g,
        '<span class="hl-code">$1</span>');

    // 3) numbers & units
    t = t.replace(/(\b\d+(?:\.\d+)?\s*(?:%|วิ|ms|MB|GB|KB|FPS|KB\/s|MB\/s)?\b|\b\d+\/\d+\b)/g,
        '<span class="hl-num">$1</span>');

    // 4) arrows
    t = t.replace(/→|←|⇢|⇠/g, '<span class="hl-arrow">$&</span>');

    // 5) states / keywords
    t = t.replace(/\b(IDLE|QUEUED|AUTHENTICATING|LAUNCHING|LOADING|IN_GAME|RECONNECTING|COOLDOWN|ERROR|OK|DOWN|ON|OFF)\b/g,
        '<span class="hl-state">$1</span>');

    // 6) file paths
    t = t.replace(/([A-Za-z]:\\[^\s]+|\/[\w\/\-\.]+\.\w+)/g,
        '<span class="hl-path">$1</span>');

    // 7) urls
    t = t.replace(/(https?:\/\/[^\s]+|127\.0\.0\.1:\d+)/g,
        '<span class="hl-url">$1</span>');

    // 8) errors
    t = t.replace(/(ERROR|error|failed|ล้มเหลว|ผิดพลาด|rate limit|timeout|หมดเวลา)/gi,
        '<span class="hl-err">$1</span>');

    // 9) ok / success
    t = t.replace(/(✓|สำเร็จ|พร้อม|success|OK\b)/g,
        '<span class="hl-ok">$1</span>');

    // 10) whitespace
    t = t.replace(/\n/g, '<br>');
    t = t.replace(/\t/g, '    ');

    return t;
}

function logHtml(list) {
    if (!list || !list.length) {
        return '<div class="csl-empty">— ยังไม่มี log —</div>';
    }
    return list.map(x => {
        const c = LOG_COLORS[x.l] || LOG_COLORS.DEBUG;
        const ic = LOG_ICONS[x.l] || '·';
        const multi = /\n/.test(x.m) || x.m.length > 160;
        const idx = String(x.i || 0).padStart(5, '0');
        return `<div class="csl-row lv-${x.l}" data-log-i="${x.i}"
                data-log-tag="${esc(x.tag)}" data-log-lv="${x.l}" title="${x.l} · #${idx}">
            <span class="csl-time">${esc(x.t || '--:--:--')}</span>
            <span class="csl-lv" style="color:${c}">${ic}</span>
            <span class="csl-tag" data-log-tag-filter="${esc(x.tag)}" title="กรองเฉพาะ ${esc(x.tag)}">${esc(x.tag)}</span>
            <span class="csl-msg${multi ? ' csl-multi' : ''}">${hlLog(esc(x.m || ''))}</span>
        </div>`;
    }).join('');
}

/* ---------- Console ---------- */
const CslState = { search: '', showRaw: false, tagFilter: '' };

/* สิ่งที่ผู้ใช้ควรรู้: WARN/ERROR ล่าสุด 3 เรื่อง (ไม่ซ้ำ tag+ข้อความ) ภายใน 15 นาที */
function cslAttn() {
    const now = Date.now(), seen = new Set(), out = [];
    for (let k = S.logs.length - 1; k >= 0 && out.length < 3; k--) {
        const x = S.logs[k];
        if (x.l !== 'WARN' && x.l !== 'ERROR') continue;
        const sig = x.tag + '|' + x.m;
        if (seen.has(sig)) continue;
        seen.add(sig);
        if (x.ts && now - x.ts > 15 * 60e3) continue;
        out.push(x);
    }
    return out;
}
function cslAttnHtml() {
    const list = cslAttn();
    if (!list.length) return '';
    return `<section class="csl-attn"><div class="csl-attn-t">${ICON.alert(13)} ต้องดู · เหตุการณ์ผิดปกติล่าสุด</div>${list.map(x => `
        <button type="button" class="csl-attn-r lv-${x.l}" data-act="csl-jump" data-tag="${esc(x.tag)}" data-tip="กรองเฉพาะ ${esc(x.tag)}">
          <span class="csl-time">${esc(x.t)}</span><b>${esc(x.tag)}</b><span class="csl-attn-m">${esc(x.m)}</span></button>`).join('')}</section>`;
}

function cslView() {
    const q = CslState.search.trim().toLowerCase();
    return S.logs
        .filter(lvMatch)
        .filter(x => !CslState.tagFilter || x.tag === CslState.tagFilter)
        .filter(x => !q || (x.m || '').toLowerCase().includes(q) || (x.tag || '').toLowerCase().includes(q) || (x.l || '').toLowerCase().includes(q));
}
const cslBody = view => CslState.showRaw ? `<pre class="csl-json">${esc(JSON.stringify(view.slice(-200), null, 2))}</pre>` : logHtml(view.slice(-200));

Views.console = {
    key: () => 'console:' + S.filter + ':' + CslState.tagFilter + ':' + CslState.showRaw + ':' + S.lp + ':' + cslAttn().map(x => x.i).join(','),

    html() {
        const all = S.logs, view = cslView();
        const cnt = { DEBUG: 0, INFO: 0, WARN: 0, ERROR: 0 };
        all.forEach(x => cnt[x.l] = (cnt[x.l] || 0) + 1);
        const tags = [...new Set(all.slice(-500).map(x => x.tag))].sort();
        const lv = [
            ['IMPORTANT', 'สำคัญ', all.length - (cnt.DEBUG || 0), 'var(--ac-2)'],
            ['ALL', 'ละเอียดทั้งหมด', all.length, 'var(--tx-2)'],
            ['WARN', 'WARN', cnt.WARN || 0, LOG_COLORS.WARN],
            ['ERROR', 'ERROR', cnt.ERROR || 0, LOG_COLORS.ERROR],
            ['INFO', 'INFO', cnt.INFO || 0, LOG_COLORS.INFO],
            ['DEBUG', 'DEBUG', cnt.DEBUG || 0, LOG_COLORS.DEBUG],
        ];

        return `
          ${UI.head('คอนโซล', {
              sub: 'เหตุการณ์ของระบบแบบสด · เริ่มต้นแสดงเฉพาะที่สำคัญ (เลือก “ละเอียดทั้งหมด” เพื่อดู DEBUG) · คลิกแถวเพื่อขยาย · คลิกขวาเพื่อคัดลอก/กรอง',
              l: `<span class="chip">${all.length} รายการ</span>${cnt.WARN ? `<span class="chip is-warn">${cnt.WARN} WARN</span>` : ''}${cnt.ERROR ? `<span class="chip is-bad">${cnt.ERROR} ERROR</span>` : ''}`,
              r: `<button class="btn" type="button" data-act="csl-raw">${CslState.showRaw ? ICON.file(13) + ' JSON' : ICON.list(13) + ' Text'}</button>
                  <button class="btn" type="button" data-act="copy-view">${ICON.copy(13)} ที่เห็น</button>
                  <button class="btn pri" type="button" data-act="copy-all">${ICON.copy(13)} ทั้งหมด</button>
                  <button class="btn" type="button" data-act="lp">${S.lp ? ICON.play(12) + ' Live' : ICON.pause(12) + ' Stop'}</button>
                  <button class="btn" type="button" data-act="clear-log">${ICON.trash(13)} ล้าง</button>`,
          })}

          <div class="toolbar">
            ${UI.seg('lvl', lv, S.filter)}
            <div class="sp"></div>
            ${UI.search('data-csl-search', CslState.search, 'ค้นหาข้อความ, tag, level…', 'csl-search-clear')}
            ${tags.length ? DD.html('csl-tag', [['', `ทุก tag <em>${tags.length}</em>`], ...tags.map(t => [t, esc(t)])], CslState.tagFilter, {
                icon: ICON.tag(13), cls: 'csl-dd', onPick: v => { CslState.tagFilter = v; render(); },
            }) : ''}
          </div>
          ${CslState.tagFilter ? `<div><span class="chip-x">tag: <b>${esc(CslState.tagFilter)}</b>
              <button class="ibtn" type="button" data-act="csl-tag-clear" style="width:24px;height:24px">${ICON.close(11)}</button></span></div>` : ''}

          ${cslAttnHtml()}
          <section class="card"><div class="csl-body" id="csl-body">${cslBody(view)}</div></section>
          <div class="csl-foot"><span data-csl-count>แสดง ${Math.min(view.length, 200)} / ${view.length}${view.length > 200 ? ' (สูงสุด 200)' : ''}</span><span>${S.lp ? 'Live' : 'หยุดไว้'}</span></div>`;
    },

    mount() {
        const s = $('[data-csl-search]');
        if (s) s.oninput = () => {
            CslState.search = s.value;
            this.patch(true);
        };
        bindRowInteractions();
    },

    patch(force) {
        const body = $('#csl-body'); if (!body) return;
        const view = cslView();
        const sig = view.length + ':' + (view.length ? view[view.length - 1].i : 0) + ':' + CslState.search + CslState.showRaw;
        if (!force && body.dataset.sig === sig) return;
        body.dataset.sig = sig;
        body.innerHTML = cslBody(view);
        bindRowInteractions();
        if (!S.lp) body.scrollTop = body.scrollHeight;
        const c = $('[data-csl-count]');
        if (c) c.textContent = `แสดง ${Math.min(view.length, 200)} / ${view.length}${view.length > 200 ? ' (สูงสุด 200)' : ''}`;
    },
};

function bindRowInteractions() {
    document.querySelectorAll('.csl-row').forEach(row => {
        if (row.dataset.bound) return;
        row.dataset.bound = '1';

        const tagEl = row.querySelector('[data-log-tag-filter]');
        if (tagEl) {
            tagEl.onclick = (e) => {
                e.stopPropagation();
                const t = tagEl.dataset.logTagFilter;
                CslState.tagFilter = (CslState.tagFilter === t) ? '' : t;
                render();
            };
        }

        row.oncontextmenu = (e) => {
            e.preventDefault();
            const x = S.logs.find(l => l.i === +row.dataset.logI);
            if (!x) return;
            const line = `[${x.t}] ${x.l} [${x.tag}] ${x.m}`;
            const cp = (txt, label) => copyText(txt).then(ok => toast(ok ? `คัดลอก${label}แล้ว` : 'คัดลอกไม่สำเร็จ', ok ? 'ok' : 'err', 1500));
            openCtx(e.clientX, e.clientY, [
                { ic: 'copy', t: 'คัดลอกบรรทัดนี้', fn: () => cp(line, 'บรรทัด') },
                { ic: 'copy', t: 'คัดลอกเฉพาะข้อความ', fn: () => cp(x.m, 'ข้อความ') },
                { sep: 1 },
                { ic: 'tag', t: CslState.tagFilter === x.tag ? `เลิกกรอง [${x.tag}]` : `กรองเฉพาะ [${x.tag}]`, fn: () => { CslState.tagFilter = CslState.tagFilter === x.tag ? '' : x.tag; render(); } },
                { ic: 'search', t: 'ค้นหาข้อความนี้', fn: () => { CslState.search = x.m.slice(0, 60); render(); } },
            ]);
        };

        row.onclick = () => {
            row.classList.toggle('csl-expand');
        };
    });
}


/* ══════════════════════════════════════════════════════════════════════
   11-view-settings
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 11-view-settings.js — หน้า ตั้งค่า */

Views.set = {
    key: () => 'set:' + librarySig() + ':' + updSig(),
    html() {
        const s = S.set, fr = UI.fr, tg = UI.tg;
        const num_ = (key, min, max, val, step) => stepper(key, min, max, val, step);
        const rng = (key, min, max, val, valAttr, len) => `<div class="range-wrap">
            <input type="range" min="${min}" max="${max}" step="1" value="${val}" data-set="${key}">
            <input class="range-val mono" type="text" inputmode="numeric" maxlength="${len}" ${valAttr} value="${val}"></div>`;
        return `
          ${UI.head('ตั้งค่า', { sub: 'ปรับการเปิดเกม จัดหน้าต่าง ธีมสี และการแจ้งเตือนของแอป' })}
          <div class="grid-2">
            <div class="stack">
              ${UI.card('คลังแมพ', mapLibHtml(), { flush: true })}

              ${UI.card('การเปิดเกม', `
                  ${fr('FPS', '5–240 · ใช้เมื่อบัญชีไม่ได้ตั้งเอง', rng('fps', 5, 240, s.fps ?? 30, 'data-fps-val', 3))}
                  ${fr('Quality กราฟิก', '1–10 · ยิ่งต่ำยิ่งเบา', rng('quality', 1, 10, s.quality ?? 1, 'data-nq-val', 2))}
                  ${fr('โปรไฟล์ทรัพยากร', 'เพดาน CPU/RAM', profileSeg(s.profile))}
                  ${fr('เว้นช่วงต่ำสุด', 'วินาที · ระยะห่างระหว่างเปิดเกม', num_('dmin', 1, 60, s.dmin, 1))}
                  ${fr('เว้นช่วงสูงสุด', 'วินาที · ระยะห่างระหว่างเปิดเกม', num_('dmax', 1, 120, s.dmax, 1))}`, { flush: true })}

              ${UI.card('หน้าต่าง Roblox', windowsCardHtml(), { flush: true })}

              ${UI.card('การกู้คืน', `
                  ${fr('Auto-reconnect', 'เปิด/ปิดทั้งระบบ', tg('auto', s.auto))}
                  ${fr('Reconnect สูงสุด/นาที', 'เกินแล้วพัก', num_('maxrc', 1, 10, s.maxrc, 1))}
                  ${fr('รอเข้าเกมนานสุด', 'วินาที · ไม่มีสัญญาณจาก api.lua ถือว่าเปิดไม่สำเร็จ แล้วปิด+เปิดใหม่ (0 = ไม่จำกัด)', num_('load_timeout', 0, 600, s.load_timeout, 10))}`, { flush: true })}

              ${UI.card('Roblox ที่ตกค้าง', `
                  ${fr('ปิด Roblox ที่ตกค้างให้อัตโนมัติ', 'ปิด Roblox ที่ค้างหน้า Home · ถูกย่ออยู่ · หรือไม่ได้ผูกกับบัญชีใดเลย (ตรวจทุก 5 วินาที) · บัญชีที่กำลังเล่นไม่ถูกแตะ', tg('auto_clean', s.auto_clean !== false))}`, { flush: true })}
            </div>

            <div class="stack">
              ${UI.card('อัปเดตแอป', updCardHtml(s), { flush: true })}

              ${UI.card('Auto-Exec Script', `
                  ${fr('เปิดใช้งานทั้งระบบ', 'ถ้าปิด ทุกบัญชีจะไม่รัน script อัตโนมัติ', tg('auto_exec_enabled', s.auto_exec_enabled !== false))}
                  ${fr('หน่วงก่อนรัน', 'วินาที · รอให้เกมโหลดเสร็จก่อน', num_('auto_exec_delay', 0, 30, s.auto_exec_delay ?? 2, 1))}
                  <div class="card-b stack" style="gap:8px">
                    <div class="fr-t"><b>Script หลัก</b><span>ส่งให้ทุกบัญชีที่เปิด Auto-Exec</span></div>
                    ${codeEditor({ attr: 'data-autoexec-script', value: s.auto_exec_script || '', placeholder: '-- วาง script หลักที่นี่ (Lua)', rows: 9 })}
                    <div class="hint">${ICON.info(14)}<span>ระบบจะส่ง script นี้ผ่าน <code>GET /api/script</code> ให้ api.lua เมื่อมีคน heartbeat · api.lua จะ <code>loadstring</code> และรันทันที</span></div>
                  </div>`, { flush: true })}

              ${UI.card('ธีมสี', `
                  <div class="swatches">${ACCENT_PRESETS.map(([nm, a]) => `
                    <button type="button" class="swatch${(s.accent || '').toLowerCase() === a ? ' on' : ''}" data-accent-pick="${a}" style="--c:${a}">${nm}</button>`).join('')}</div>
                  <button type="button" class="swatch custom${ACCENT_PRESETS.some(p => p[1] === (s.accent || DEFAULT_ACCENT).toLowerCase()) ? '' : ' on'}" data-accent-custom style="--c:${s.accent || DEFAULT_ACCENT}">
                    <i class="sw-wheel"></i><span>กำหนดเอง</span><em class="mono" data-accent-val>${(s.accent || DEFAULT_ACCENT).toUpperCase()}</em>${ICON.chevDown(14)}
                  </button>
                  <button class="btn ghost block" type="button" data-act="accent-reset" style="margin-top:8px">${ICON.undo(13)} คืนค่าเริ่มต้น</button>`)}

              ${UI.card('แอป', `
                  ${fr('Force close Roblox ตอนเปิดแอป', 'ปิดที่ค้างก่อนเริ่ม', tg('force_kill_on_boot', s.force_kill_on_boot))}
                  ${fr('Multi-instance', S.rbxReady ? 'พร้อมใช้งาน' : 'ไม่พร้อม', `<button class="btn${S.rbxReady ? '' : ' pri'}" type="button" data-act="kill-rbx">ปิด Roblox + ลองใหม่</button>`)}
                  ${fr('เสียงแจ้งเตือน', 'beep เมื่อ state เปลี่ยน', tg('sound', s.sound))}
                  ${fr('แจ้งเตือนมุมขวาล่างจอ', 'popup เมื่อบัญชีหลุดหรือเข้าเกม · แสดงทับทุกหน้าต่าง',
                      `<button class="btn" type="button" data-act="test-notify">ทดสอบ</button>${tg('notify_overlay', s.notify_overlay !== false)}`)}`, { flush: true })}

              ${UI.card('เกี่ยวกับ', `<img class="about-banner" src="img/banner.png" width="800" height="400" alt="P4NG Roblox Account Manager" decoding="async" loading="lazy">` + fr('P4NG Launcher v' + APP_VERSION, '© 2026 · made by @pangkung_pk',
                  `<button class="btn" type="button" data-open-url="https://www.instagram.com/pangkung_pk/">${ICON.link(13)} Instagram</button>
                   <button class="btn" type="button" data-open-url="https://discord.gg/c2RegyBjDF">${ICON.link(13)} Discord</button>`), { flush: true })}
            </div>
          </div>`;
    },

    mount() {
        bindPlace();

        $$('[data-set]').forEach(el => {
            const k = el.dataset.set;
            const h = () => {
                const v = el.type === 'number' ? num(el.value) : (el.type === 'range' ? +el.value : el.value);
                S.set[k] = v;
                if (k === 'fps')            { const t = $('[data-fps-val]'); if (t) t.value = v; }
                if (k === 'quality') { const t = $('[data-nq-val]');  if (t) t.value = v; }
                if (GRID_KEYS.includes(k)) paintGrid();
                save();
            };
            el.oninput = h; el.onchange = h;
        });
        bindSteppers();

        $$('[data-seg="profile"] .seg-b').forEach(b => b.onclick = () => {
            S.set.profile = b.dataset.val; save();
            $$('[data-seg="profile"] .seg-b').forEach(x => x.classList.toggle('on', x === b));
        });
        $$('[data-set-tg]').forEach(b => b.onclick = () => {
            const k = b.dataset.setTg;
            S.set[k] = !S.set[k];
            b.classList.toggle('on', !!S.set[k]);
            save();
        });

        let t = 0;                                              // Auto-exec script (global)
        bindCodeEditors($('#main'), (val, ta) => {
            if (!ta.hasAttribute('data-autoexec-script')) return;
            S.set.auto_exec_script = val;
            clearTimeout(t); t = setTimeout(save, 400);
        });
        $$('[data-open-url]').forEach(b => b.onclick = () => api('open_url', b.dataset.openUrl).catch(() => { }));

        /* ธีมสี — ทุกทางเข้า (swatch / color picker / hex) ผ่าน setAccent() → applyAccent() อัปเดตทั้งสีและสถานะที่เลือกทันที */
        $$('[data-accent-pick]').forEach(b => b.onclick = () => setAccent(b.dataset.accentPick));
        const cb = $('[data-accent-custom]');
        if (cb) cb.onclick = () => ColorPicker.open(cb, S.set.accent || DEFAULT_ACCENT, hex => setAccent(hex));
        bindWindowsCard();
    },
    patch() { paintWinBtn(); },
};

/* ══════════════════════════════════════════════════════════════════════
   ตั้งค่า → หน้าต่าง Roblox (แทนหน้า "จัดหน้าต่าง" เดิม)
   โหมดเดียว = grid · บัญชีแรกอยู่ซ้ายบนเสมอ แล้วเรียงซ้าย→ขวา บน→ล่าง · ขนาดช่องคงที่ตามที่ตั้ง
   ══════════════════════════════════════════════════════════════════════ */
const GRID_MAX = 10;                                   // ตัวเลือกแบบกดบนตาราง (ค่าเกินนี้ตั้งผ่านช่อง "กำหนดเอง")
const GRID_KEYS = ['grid_cols', 'grid_rows', 'cell_w', 'cell_h'];
const CELL_PRESETS = [[160, 120], [200, 150], [240, 180], [320, 240], [400, 300], [480, 360], [640, 480]];
const gridVals = () => ({
    cols: Math.max(1, num(S.set.grid_cols) || 8), rows: Math.max(1, num(S.set.grid_rows) || 6),
    cw: Math.max(120, num(S.set.cell_w) || 200), ch: Math.max(90, num(S.set.cell_h) || 150),
});
const cellIsPreset = g => CELL_PRESETS.some(([w, h]) => w === g.cw && h === g.ch);
const cellKey = g => cellIsPreset(g) ? `${g.cw}x${g.ch}` : 'custom';
const cellLabel = g => cellIsPreset(g) ? `${g.cw} × ${g.ch}` : `กำหนดเอง · ${g.cw} × ${g.ch}`;
let _gridCustom = false;                               // เปิดช่องกรอกตัวเลขเอง (คอลัมน์/แถว)
let _cellCustom = false;                               // เปิดช่องกรอกขนาดช่องเอง

function pickBtnHtml(act) {
    return `<button class="ibtn pri lbl" type="button" data-act="${act}" data-tip="เปิดหน้าต่าง Roblox เพื่อเลือกเกม">${ICON.search(13)}<span>เลือกเกม</span></button>`;
}

function windowsCardHtml() {
    const g = gridVals(), s = S.set;
    _cellCustom = !cellIsPreset(g);
    _gridCustom = g.cols > GRID_MAX || g.rows > GRID_MAX;
    const cells = Array.from({ length: GRID_MAX * GRID_MAX }, (_, i) => {
        const c = i % GRID_MAX + 1, r = Math.floor(i / GRID_MAX) + 1;
        return `<i class="gp-c${c <= g.cols && r <= g.rows ? ' on' : ''}" data-c="${c}" data-r="${r}"></i>`;
    }).join('');
    const cellItems = [...CELL_PRESETS.map(([w, h]) => [`${w}x${h}`, `${w} × ${h}`, w / h === 4 / 3 ? '4:3' : '']), ['custom', 'กำหนดเอง…']];
    const dd = DD.html('cell', cellItems, cellKey(g), {
        cls: 'w-dd',
        onPick: v => {
            if (v === 'custom') { _cellCustom = true; paintGrid(); return; }
            _cellCustom = false;
            const [w, h] = v.split('x').map(Number);
            S.set.cell_w = w; S.set.cell_h = h;
            save(); paintGrid();
        },
    });
    return `
      <div class="fr col">
        <div class="fr-t"><b>ตาราง</b><span>เลือกจำนวนคอลัมน์ × แถว · หน้าต่างแรกอยู่มุมซ้ายบนของจอเสมอ แล้วเรียงซ้าย → ขวา, บน → ล่าง</span></div>
        <div class="gp-box">
          <div class="gp" data-gp style="--n:${GRID_MAX};--ar:${g.cw / g.ch}" role="group" aria-label="เลือกขนาดตาราง">${cells}</div>
          <div class="gp-foot">
            <div class="gp-read"><b class="mono" data-gp-label></b><span data-gp-count></span></div>
            <button class="btn ghost sm" type="button" data-gp-more>${ICON.edit(12)} กำหนดเอง</button>
          </div>
          <div class="gp-custom" data-gp-custom ${_gridCustom ? '' : 'hidden'}>
            <label>คอลัมน์ ${stepper('grid_cols', 1, 40, g.cols, 1)}</label>
            <label>แถว ${stepper('grid_rows', 1, 40, g.rows, 1)}</label>
          </div>
          <div class="gp-hint" data-gp-hint></div>
        </div>
      </div>
      ${UI.fr('ขนาดช่อง', 'ขนาดหน้าต่าง Roblox แต่ละตัว (px) · ถ้าตารางใหญ่เกินจอจะย่อให้พอดี', dd)}
      <div class="fr gp-cell-custom" data-cell-custom ${_cellCustom ? '' : 'hidden'}>
        <div class="fr-t"><b>ขนาดที่กำหนดเอง</b><span>กว้าง × สูง (px)</span></div>
        <div class="fr-c">${stepper('cell_w', 120, 1920, g.cw, 10)}<span class="mu">×</span>${stepper('cell_h', 90, 1080, g.ch, 10)}</div>
      </div>
      ${UI.fr('จัดอัตโนมัติ', 'วางหน้าต่างบัญชีที่เข้าเกมใหม่ลงตารางเอง', UI.tg('auto_arrange', s.auto_arrange !== false))}
      ${UI.fr('ย่อหน้าต่างอัตโนมัติ', 'ย่อหน้าต่าง Roblox ของบัญชีลง taskbar เองหลังเข้าเกม (หลังจัดตาราง) · เกมยังรันต่อ ไม่ถูกปิด · เปิดดูได้ทางคลิกขวาที่การ์ดหรือปุ่มตา', UI.tg('auto_minimize', !!s.auto_minimize))}
      ${UI.fr('ย่อเดี๋ยวนี้', 'ย่อหน้าต่างทุกบัญชีที่อยู่ในเกมตอนนี้', `<button class="btn" type="button" data-act="minimize-all">${ICON.minimize(13)} ย่อทั้งหมด</button>`)}
      ${UI.fr('จัดเดี๋ยวนี้', 'จัดทุกบัญชีที่อยู่ในเกมตอนนี้ตามตารางนี้', `<button class="btn" type="button" data-act="apply-layout" data-win-apply>${ICON.grid(13)} <span data-win-apply-t>จัดเดี๋ยวนี้</span></button>`)}`;
}

/* อัปเดตตัวอย่างตาราง + ข้อความ + ช่องกรอก (ไม่สร้างหน้าใหม่) */
function paintGrid(pv) {
    const box = $('[data-gp]');
    if (!box) return;
    const g = gridVals(), cols = pv ? pv.c : g.cols, rows = pv ? pv.r : g.rows;
    box.style.setProperty('--ar', g.cw / g.ch);
    box.querySelectorAll('.gp-c').forEach(el => {
        const on = +el.dataset.c <= cols && +el.dataset.r <= rows;
        el.classList.toggle('on', on);
        el.classList.toggle('pv', !!pv && on);
    });
    const lb = $('[data-gp-label]'), ct = $('[data-gp-count]');
    if (lb) lb.textContent = `${cols} × ${rows}`;
    if (ct) ct.textContent = `${cols * rows} หน้าต่าง`;
    if (pv) return;
    const more = $('[data-gp-custom]');
    if (more) more.hidden = !_gridCustom;
    const cc = $('[data-cell-custom]');
    if (cc) cc.hidden = !_cellCustom;
    const m = { grid_cols: g.cols, grid_rows: g.rows, cell_w: g.cw, cell_h: g.ch };
    for (const [k, v] of Object.entries(m)) {
        const inp = $(`input[data-set="${k}"]`);
        if (inp && document.activeElement !== inp && String(inp.value) !== String(v)) inp.value = v;
    }
    const btn = $('[data-dd="cell"]'), r = DD.reg.cell;
    if (btn && r) {
        const key = _cellCustom ? 'custom' : cellKey(g);
        r.value = key;
        const t = btn.querySelector('.dd-v');
        const txt = key === 'custom' ? `กำหนดเอง · ${g.cw} × ${g.ch}` : cellLabel(g);
        if (t) { t.textContent = txt; t.classList.remove('ph'); }
    }
    const hint = $('[data-gp-hint]');
    if (hint) {
        const dpr = window.devicePixelRatio || 1;
        const sw = Math.round(screen.availWidth * dpr), sh = Math.round(screen.availHeight * dpr);
        const w = g.cols * g.cw, h = g.rows * g.ch, over = w > sw || h > sh;
        hint.className = 'gp-hint' + (over ? ' warn' : '');
        hint.innerHTML = `${ICON.monitor(13)}<span>ตารางเต็ม <b class="mono">${w} × ${h}</b> px · จอ ~<span class="mono">${sw} × ${sh}</span>${over ? ' — ถ้ามีบัญชีมากจนเกินจอ ระบบจะย่อช่องให้พอดีอัตโนมัติ' : ''}</span>`;
    }
}

function paintWinBtn() {
    const b = $('[data-win-apply]');
    if (!b) return;
    const n = S.accounts.filter(a => a.state === 'IN_GAME').length;
    const t = b.querySelector('[data-win-apply-t]'), txt = n ? `จัดเดี๋ยวนี้ (${n})` : 'จัดเดี๋ยวนี้';
    if (t && t.textContent !== txt) t.textContent = txt;
    if (b.disabled !== !n) b.disabled = !n;
    b.dataset.tip = n ? `จัด ${n} หน้าต่างที่อยู่ในเกมตามตาราง` : 'ยังไม่มีบัญชีที่อยู่ในเกม';
}

function bindWindowsCard() {
    const box = $('[data-gp]');
    if (!box) return;
    paintGrid(); paintWinBtn();
    box.onmouseover = e => {
        const el = e.target.closest('.gp-c');
        if (el) paintGrid({ c: +el.dataset.c, r: +el.dataset.r });
    };
    box.onmouseleave = () => paintGrid();
    box.onclick = e => {
        const el = e.target.closest('.gp-c');
        if (!el) return;
        S.set.grid_cols = +el.dataset.c; S.set.grid_rows = +el.dataset.r;
        _gridCustom = false;
        save(); paintGrid();
    };
    const more = $('[data-gp-more]');
    if (more) more.onclick = () => { _gridCustom = !_gridCustom; paintGrid(); };
}

function stepper(key, min, max, val, step = 1) {
    return `<div class="stepper" data-stepper>
        <button type="button" class="st-b" data-st="-1" tabindex="-1" aria-label="ลด">−</button>
        <input type="number" data-set="${key}" min="${min}" max="${max}" step="${step}" value="${val}">
        <button type="button" class="st-b" data-st="1" tabindex="-1" aria-label="เพิ่ม">+</button>
      </div>`;
}
async function applyPlace(r) {
    if (r && r.ok && r.place_id) {
        const pid = num(r.place_id);
        const had = !!libGet(pid);
        let info = r.info && r.info.ok ? r.info : null;
        if (!info) info = await fetchMapInfo(pid);           // ดึงชื่อ/รูปครั้งเดียวตอนเพิ่ม แล้วเก็บในคลัง
        libUpsert(pid, info || {});
        if (!num(S.set.place_id)) S.set.place_id = pid;      // แมพแรก = แมพเริ่มต้นอัตโนมัติ
        _saveEnd = Date.now() + 2500;
        save();
        rerender();
        toast(`${had ? 'อัปเดต' : 'เพิ่ม'}ในคลัง: ${info?.name || 'Place ' + pid}`, 'ok', 3500);
    } else toast((r && r.error) || 'ไม่สำเร็จ', 'warn', 4000);
}

/* รายการแมพในคลัง (หน้า ตั้งค่า) */
function mapUsage(pid) { return S.accounts.filter(a => num(a.place_id) === pid).length; }
function libRowHtml(m) {
    const def = num(S.set.place_id) === m.id, used = mapUsage(m.id);
    return `<div class="ml-row${def ? ' is-def' : ''}" data-map="${m.id}">
        <div class="ml-ic">${m.icon ? `<img src="${esc(m.icon)}" alt="" draggable="false">` : ICON.map(18)}</div>
        <div class="ml-info">
          <div class="ml-name"><span title="${esc(m.name || '')}">${esc(m.name || 'Place ' + m.id)}</span>${def ? '<em class="mc-tag own">ค่าเริ่มต้น</em>' : ''}</div>
          <div class="ml-sub mono">#${m.id}${m.creator ? ' · โดย ' + esc(m.creator) : ''}${used ? ` · ใช้โดย ${used} บัญชี` : ''}</div>
        </div>
        <div class="ml-act">
          <button class="ibtn${def ? ' on' : ''}" type="button" data-act="map-default" data-id="${m.id}" data-tip="${def ? 'แมพเริ่มต้นอยู่' : 'ตั้งเป็นแมพเริ่มต้น (Global)'}">${ICON.star(14)}</button>
          <button class="ibtn" type="button" data-act="map-refresh" data-id="${m.id}" data-tip="อัปเดตชื่อ/รูปจาก Roblox">${ICON.refresh(14)}</button>
          <button class="ibtn danger-i" type="button" data-act="map-del" data-id="${m.id}" data-tip="ลบออกจากคลัง">${ICON.trash(14)}</button>
        </div>
      </div>`;
}
function mapLibHtml() {
    const lib = mapLib();
    return `<div class="card-b stack" style="gap:10px">
        <div class="inline-set" style="margin-top:0">
          <input data-place-text placeholder="วางลิงก์เกม / Place ID แล้วกด Enter เพื่อเพิ่ม" autocomplete="off" spellcheck="false">
          <button class="btn" type="button" data-act="set-place" data-tip="เพิ่มแมพนี้เข้าคลัง">เพิ่ม</button>
          ${pickBtnHtml('pick-place')}
        </div>
        ${lib.length ? `<div class="ml-list">${lib.map(libRowHtml).join('')}</div>`
            : `<div class="hint">${ICON.info(14)}<span>ยังไม่มีแมพในคลัง — เพิ่มไว้ที่นี่ครั้งเดียว แล้วเลือกให้แต่ละบัญชีได้ทันทีโดยไม่ต้องโหลดจากเว็บ Roblox ทุกครั้ง</span></div>`}
        ${lib.length ? `<div class="hint">${ICON.info(14)}<span>ดาว = แมพเริ่มต้น (Global) ที่บัญชีใช้เมื่อไม่ได้เลือกแมพเอง · เลือกแมพเฉพาะบัญชีได้ที่ปุ่ม ⋯ → แก้ไขบัญชี → เกม</span></div>` : ''}
      </div>`;
}

function bindPlace() {
    const pp = $('[data-act="pick-place"]');
    if (pp) pp.onclick = async () => {
        if (pp.disabled) return;
        pp.disabled = true;
        const old = pp.innerHTML;
        pp.innerHTML = `${ICON.hourglass(13)}<span>กำลังเปิด…</span>`;
        toast('เปิดหน้าต่างเลือกเกม… รอสักครู่', 'info', 5000);
        try {
            const r = await api('open_map_picker', num(S.set.place_id) || 0);
            await applyPlace(r);
        } catch (e) { toast('เปิดไม่สำเร็จ: ' + e, 'err', 4000); }
        finally { pp.disabled = false; pp.innerHTML = old; }
    };
    const sp = $('[data-act="set-place"]'), tx = $('[data-place-text]');
    const go = async () => {
        if (!tx || !tx.value.trim()) { toast('ใส่ลิงก์หรือ Place ID ก่อน', 'warn'); return; }
        try {
            const r = await api('resolve_place', tx.value);
            await applyPlace(r);
            if (r && r.ok) tx.value = '';
        } catch (e) { toast('ตั้งไม่สำเร็จ: ' + e, 'err'); }
    };
    if (sp) sp.onclick = go;
    if (tx) tx.onkeydown = e => { if (e.key === 'Enter') go(); };
}
function bindSteppers() {
    $$('[data-stepper]').forEach(w => {
        if (w.dataset.bound) return; w.dataset.bound = '1';
        const inp = w.querySelector('input');
        const apply = (dir) => {
            const mn = +inp.min, mx = +inp.max, st = +inp.step || 1;
            let v = (parseFloat(inp.value) || mn) + dir * st;
            v = Math.min(mx, Math.max(mn, v));
            if (String(v) === inp.value) return false;
            inp.value = v;
            inp.dispatchEvent(new Event('input', { bubbles: true }));
            return true;
        };
        w.querySelectorAll('.st-b').forEach(b => {
            let t1 = 0, t2 = 0;
            const stop = () => { clearTimeout(t1); clearInterval(t2); };
            b.addEventListener('pointerdown', (e) => {
                if (e.pointerType === 'mouse' && e.button !== 0) return;
                e.preventDefault();
                const dir = +b.dataset.st;
                apply(dir);
                t1 = setTimeout(() => { t2 = setInterval(() => apply(dir), 70); }, 380);
            });
            ['pointerup', 'pointerleave', 'pointercancel'].forEach(ev => b.addEventListener(ev, stop));
        });
        inp.addEventListener('blur', () => {
            const mn = +inp.min, mx = +inp.max;
            let v = parseFloat(inp.value);
            if (isNaN(v)) v = mn;
            v = Math.min(mx, Math.max(mn, v));
            if (String(v) !== inp.value) { inp.value = v; inp.dispatchEvent(new Event('input', { bubbles: true })); }
        });
    });
}
const PROFILE_OPTS = [
    ['Ultra Low', '#4ade80', 'ประหยัดสุด'],
    ['Balanced', '#fbbf24', 'สมดุล'],
    ['Performance', '#f87171', 'แรงสุด'],
];
function profileSeg(cur) {
    return `<div class="seg" data-seg="profile">${PROFILE_OPTS.map(([v, c, tip]) =>
        `<button type="button" class="seg-b ${cur === v ? 'on' : ''}" data-val="${v}" data-tip="${tip}" style="--c:${c}"><i></i>${v}</button>`
    ).join('')}</div>`;
}
// ══════════════════════════════════════════════════════════
// ★ Instances Modal (ใช้ร่วมกับ dashboard)
// ══════════════════════════════════════════════════════════
/* ══════════════════════════════════════════════════════════════════════
   12-render-actions
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 12-render-actions.js — render หลัก + dock + ACT (ปุ่มทุกปุ่ม) + บันทึกตั้งค่า */

/* ======================================================================
   RENDER — สร้างหน้าใหม่เมื่อ key เปลี่ยน · นอกนั้น patch() อัปเดตเฉพาะที่เปลี่ยน
   ====================================================================== */
let _lastKey = '', _lastView = '';
function render() {
    renderDock();
    paintSelBar();
    const v = Views[S.view], key = v.key(), main = $('#main');
    if (key !== _lastKey || !main.firstElementChild) {
        _lastKey = key;
        main.innerHTML = v.html();
        if (_lastView !== S.view && window.gsap)
            gsap.from(main.children, { opacity: 0, y: 8, duration: .35, stagger: .04, ease: 'power3.out', clearProps: 'opacity,transform' });
        _lastView = S.view;
        v.mount?.();
    }
    v.patch?.();
}
/** บังคับสร้างหน้าใหม่ (เมื่อโครงสร้างเปลี่ยนแต่ key ไม่เปลี่ยน) */
function rerender() { _lastKey = ''; render(); }

/* ── Dock (เมนูล่าง) · หน้าหลักอยู่กึ่งกลาง · ขวาสุด = เริ่ม/หยุดทั้งหมด ─── */
function renderDock() {
    const dock = $('#dock'), A = S.accounts;
    const cnt = f => A.filter(f).length;
    const errN = cnt(a => a.state === 'ERROR' || a.health === 'banned');
    const busyN = cnt(a => BUSY.includes(a.state));
    const idleN = cnt(a => ['IDLE', 'ERROR', 'COOLDOWN'].includes(a.state) && a.health !== 'banned');
    const runMode = busyN ? 'stop' : (idleN ? 'start' : 'none');
    const sysBad = !S.apiPort || !S.rbxReady;
    const liveN = cnt(a => a.state === 'IN_GAME');
    const sig = [S.view, A.length, liveN, S.jobs.length, errN, runMode, runMode === 'stop' ? busyN : idleN, sysBad].join(':');
    if (dock.dataset.sig === sig) return;
    dock.dataset.sig = sig;

    const badge = k => {
        if (k === 'acc' && A.length) return `<i class="dk-b${liveN ? ' ok' : ''}" title="ในเกม ${liveN} จาก ${A.length} บัญชี"><b>${liveN}</b><em>/${A.length}</em></i>`;
        if (k === 'queue' && S.jobs.length) return `<i class="dk-b hot" title="งานในคิว ${S.jobs.length}"><b>${S.jobs.length}</b></i>`;
        if (k === 'dash' && errN) return `<i class="dk-b err" title="ผิดพลาด/โดนแบน ${errN} บัญชี"><b>${errN}</b></i>`;
        if (k === 'set' && sysBad) return `<i class="dk-b err" title="api.lua หรือ Multi-instance ยังไม่พร้อม"><b>!</b></i>`;
        return '';
    };
    const run = runMode === 'none'
        ? '<span class="dk dk-run dk-ghost" aria-hidden="true"><span class="dk-ic"></span><span class="dk-t">&nbsp;</span></span>'
        : `<button class="dk dk-run ${runMode}" type="button" data-run="${runMode}" data-tip="${runMode === 'stop' ? 'หยุดทุกบัญชีที่กำลังทำงาน' : 'เริ่มทุกบัญชีที่ว่าง'}">
             <span class="dk-ic">${runMode === 'stop' ? ICON.stop(18) : ICON.play(18)}</span>
             <span class="dk-t">${runMode === 'stop' ? `หยุด (${busyN})` : `เริ่ม (${idleN})`}</span></button>`;
    dock.innerHTML = NAV.map(([k, label, ic, key]) => `
        <button class="dk${k === 'dash' ? ' dk-home' : ''}${S.view === k ? ' on' : ''}" type="button" data-go="${k}"
                aria-label="${label}" ${S.view === k ? 'aria-current="page"' : ''} data-tip="${label} (${key})">
          <span class="dk-ic">${ICON[ic](k === 'dash' ? 24 : 20)}${badge(k)}</span>
          <span class="dk-t">${label}</span>
        </button>`).join('') + run;
    dock.querySelectorAll('[data-go]').forEach(el => el.onclick = () => { go(el.dataset.go); window.flashDock?.(); });
    const rb = dock.querySelector('[data-run]');
    if (rb) rb.onclick = () => {
        rb.dataset.run === 'stop' ? homeStopAll() : launchAccounts(S.accounts.map(a => a.id));
        window.flashDock?.();
    };
    placeDockPill();
    window.flashDock?.();
}
/* แถบ active ของ dock เลื่อนตามปุ่มที่เลือก (วัดตำแหน่งจากปุ่มจริง) */
function placeDockPill() {
    const dock = $('#dock'), on = dock.querySelector('.dk.on');
    if (!on) { dock.style.setProperty('--io', 0); return; }
    dock.style.setProperty('--ix', on.offsetLeft + 'px');
    dock.style.setProperty('--it', on.offsetTop + 'px');
    dock.style.setProperty('--iw', on.offsetWidth + 'px');
    dock.style.setProperty('--ih', on.offsetHeight + 'px');
    dock.style.setProperty('--io', 1);
}
addEventListener('resize', placeDockPill);
document.fonts?.ready.then(placeDockPill);

// ปุ่มลัด 1–5 สลับหน้า (ไม่ทำงานตอนพิมพ์ในช่องกรอก/เปิด modal)
document.addEventListener('keydown', e => {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.target.isContentEditable) return;
    if (document.querySelector('#modal-root .overlay')) return;
    const n = NAV.find(x => x[3] === e.key);
    if (n && S.view !== n[0]) go(n[0]);
});

/* ======================================================================
   ACT — ปุ่มทุกปุ่มในหน้า (#main) ใช้ data-act="ชื่อ" [data-id] [data-v] แล้วมาลงที่นี่ที่เดียว
   (ผูกครั้งเดียวแบบ delegate → ไม่ต้องผูก/ยกเลิกใหม่ทุกครั้งที่หน้าถูก patch)
   ====================================================================== */
/* ======================================================================
   อัปเดตแอป — ตรวจ GitHub Releases · แจ้งเตือน · กดเพื่อติดตั้ง (backend: core/updater.py)
   S.upd = { ver, configured, busy, res }  ·  res = ผลจาก update_check()
   ====================================================================== */
const updSig = () => { const u = S.upd || {}; return [u.busy || '', u.res ? (u.res.ok ? u.res.latest + (u.res.newer ? 'N' : '') : 'E' + u.res.error) : '', u.ver || ''].join('|'); };

function updCardHtml(s) {
    const u = S.upd || {}, r = u.res, tg = UI.tg, fr = UI.fr;
    const note = r && r.ok && r.newer && r.notes ? `<div class="hint">${ICON.info(14)}<span style="white-space:pre-wrap">${esc(r.notes.split('\n').slice(0, 8).join('\n'))}</span></div>` : '';
    let status, ctl;
    if (u.busy === 'check') { status = 'กำลังตรวจ…'; ctl = `<button class="btn" type="button" disabled>กำลังตรวจ…</button>`; }
    else if (u.busy === 'install') { status = 'กำลังโหลดและติดตั้ง… แอปจะรีสตาร์ตเอง'; ctl = `<button class="btn pri" type="button" disabled>กำลังติดตั้ง…</button>`; }
    else if (r && r.ok && r.newer) { status = `มีเวอร์ชันใหม่ <b class="mono">v${esc(r.latest)}</b>`; ctl = `<button class="btn pri" type="button" data-act="upd-install">${ICON.refresh(13)} อัปเดตเลย</button>`; }
    else if (r && r.ok) { status = 'ใช้เวอร์ชันล่าสุดแล้ว'; ctl = `<button class="btn" type="button" data-act="upd-check">ตรวจอีกครั้ง</button>`; }
    else if (r) { status = esc(r.error || 'ตรวจไม่สำเร็จ'); ctl = `<button class="btn" type="button" data-act="upd-check">ลองใหม่</button>`; }
    else { status = u.configured === false ? 'ยังไม่ได้ตั้ง UPDATE_REPO ใน core/version.py' : 'ยังไม่ได้ตรวจ'; ctl = `<button class="btn" type="button" data-act="upd-check">ตรวจอัปเดต</button>`; }
    return `
      ${fr('เวอร์ชันที่ใช้อยู่', 'ตรวจจาก GitHub Releases', `<span class="mono">v${esc(u.ver || '?')}</span>`)}
      ${fr('สถานะ', status, ctl)}
      ${fr('ตรวจอัตโนมัติตอนเปิดแอป', 'แจ้งเตือนเมื่อมีเวอร์ชันใหม่ · ไม่ติดตั้งเองจนกว่าจะกดอัปเดต', tg('auto_update_check', s.auto_update_check !== false))}
      ${note}`;
}

async function updCheck(manual) {
    S.upd = S.upd || {};
    if (S.upd.busy) return;
    S.upd.busy = 'check'; if (S.view === 'set') rerender();
    let r;
    try { r = await api('update_check'); } catch (e) { r = { ok: false, error: 'ตรวจไม่สำเร็จ' }; }
    S.upd.busy = ''; S.upd.res = r;
    if (r && r.ok && r.newer) toast(`มีเวอร์ชันใหม่ v${r.latest} — ไปที่ ตั้งค่า → อัปเดตแอป เพื่อติดตั้ง`, 'info', 8000);
    else if (manual) toast(r && r.ok ? 'ใช้เวอร์ชันล่าสุดแล้ว' : ((r && r.error) || 'ตรวจอัปเดตไม่สำเร็จ'), r && r.ok ? 'ok' : 'err');
    if (S.view === 'set') rerender();
}

async function updInstall() {
    const u = S.upd = S.upd || {};
    if (u.busy || !(u.res && u.res.ok && u.res.newer)) return;
    let force = false;
    u.busy = 'install'; rerender();
    let r = await api('update_install', false).catch(() => ({ ok: false, error: 'ติดตั้งไม่สำเร็จ' }));
    if (r && r.busy) {
        u.busy = ''; rerender();
        const go_ = await ask(`มี ${r.busy} บัญชีกำลังรันอยู่ — อัปเดตแล้วแอปจะรีสตาร์ต และ Roblox ที่เปิดค้างอาจถูกปิดโดยระบบเก็บกวาด ควรหยุดบัญชีก่อน ต้องการอัปเดตต่อเลยไหม?`, { confirm: true, ok: 'อัปเดตต่อ' });
        if (!go_) return;
        u.busy = 'install'; rerender();
        r = await api('update_install', true).catch(() => ({ ok: false, error: 'ติดตั้งไม่สำเร็จ' }));
    }
    if (!(r && r.ok)) { u.busy = ''; toast((r && r.error) || 'ติดตั้งอัปเดตไม่สำเร็จ', 'err', 6000); rerender(); }
}

async function updInit() {
    S.upd = S.upd || {};
    try { const i = await api('app_version'); S.upd.ver = i.version; S.upd.configured = i.configured; } catch (e) { return; }
    if (S.upd.configured && (S.set ? S.set.auto_update_check !== false : true)) updCheck(false);
}

const ACT = {
    /* นำทาง */
    go: el => go(el.dataset.v),
    'upd-check': () => updCheck(true),
    'upd-install': () => updInstall(),
    tab: el => { const v = el.dataset.v; S.accFilter = (S.accFilter === v && v !== 'ALL') ? 'ALL' : v; if (S.view !== 'acc') return go('acc'); rerender(); },
    'add-account': el => openAddMenu(el),

    /* บัญชี (แถว) */
    start: el => launchAccounts([+el.dataset.id]),
    stop: el => stop(+el.dataset.id),
    view: el => viewInGame(+el.dataset.id),
    copy: el => copyCred(+el.dataset.id),
    async edit(el) {
        const id = +el.dataset.id, acc = S.accounts.find(x => x.id === id);
        if (!acc) return;
        const patch = await askAccount(acc);
        if (!patch) return;
        await api('set_account', id, patch);
        toast('บันทึกแล้ว', 'ok', 1800);
        poll();
    },

    async pin(el) {
        const id = +el.dataset.id, a = S.accounts.find(x => x.id === id);
        if (!a) return;
        a.pinned = !a.pinned;
        applyAccountOrder();
        rerender();
        toast(a.pinned ? `ปักหมุด ${a.name} แล้ว` : `เลิกปักหมุด ${a.name}`, 'ok', 1500);
        try { await api('set_account', id, { pinned: a.pinned }); } catch (e) { }
        poll();
    },

    /* บัญชี (เลือกหลายรายการ) */
    sel: (el, e) => toggleSel(+el.dataset.id, e && e.shiftKey),
    'sel-mode': () => setSelMode(!S.selMode),
    'sel-all': () => {
        const vis = accVisible(), all = vis.length && vis.every(a => S.sel.has(a.id));
        vis.forEach(a => all ? S.sel.delete(a.id) : S.sel.add(a.id));
        if (autoExitSel()) return;
        paintSel();
    },
    'sel-clear': () => setSelMode(false),
    'clear-filter': () => { S.accFilter = 'ALL'; S.accSearch = ''; rerender(); },
    'search-clear': () => { S.accSearch = ''; rerender(); },
    'check-health': () => runHealthCheck(null),
    'bulk-check': () => runHealthCheck([...S.sel]),
    'bulk-open': () => S.sel.size && launchAccounts([...S.sel]),
    async 'bulk-stop'() {
        const act = S.accounts.filter(a => S.sel.has(a.id) && running(a));
        if (!act.length) return toast('ไม่มีบัญชีที่ทำงานอยู่', 'warn');
        for (const a of act) { try { await api('stop', a.id); } catch (e) { } }
        toast(`หยุด ${act.length} บัญชี`, 'ok', 2000);
        S.sel.clear(); if (!autoExitSel()) paintSel(); poll();
    },
    async 'bulk-delete'() {
        const ids = [...S.sel];
        if (!ids.length) return;
        const yes = await askDelete(ids.map(id => S.accounts.find(x => x.id === id)));
        if (!yes) return;
        const r = await api('delete_bulk', ids);
        if (r && r.ok) toast(`ลบ ${r.deleted} บัญชี${r.errors?.length ? ` · ${r.errors.length} ล้มเหลว` : ''}`, r.deleted ? 'ok' : 'warn', 2600);
        S.sel.clear(); S.selMode = false; rerender(); poll();
    },

    /* คิว */
    pause: async () => { await api('set_paused', !S.paused); poll(); },
    async 'cancel-all'() {
        const n = S.jobs.filter(j => j.state === 'PENDING').length;
        if (!n) return;
        if (!await ask(`ยกเลิก ${n} งานที่ยังไม่เริ่ม?`, { confirm: true, ok: 'ยกเลิกทั้งหมด' })) return;
        const r = await api('cancel_all_pending');
        if (r?.ok) toast(`ยกเลิก ${r.count} งาน`, 'ok', 2000);
        poll();
    },
    async 'cancel-job'(el) {
        const id = +el.dataset.id, r = await api('cancel_job', id);
        r?.ok ? toast(`ยกเลิกงาน #${id}`, 'ok', 1800) : toast(r?.error || 'ยกเลิกไม่สำเร็จ', 'err', 2500);
        poll();
    },

    /* หน้าต่าง Roblox (ตั้งค่า) */
    'apply-layout': () => applyLayoutNow(false),
    async 'minimize-all'() {
        const r = await api('minimize_all');
        r && r.ok ? toast(`ย่อหน้าต่าง ${r.placed}/${r.total} ตัว`, 'ok', 1800) : toast('ไม่มีบัญชีที่อยู่ในเกมให้ย่อ', 'warn', 2200);
    },

    /* คอนโซล */
    lvl: el => { S.filter = el.dataset.v; rerender(); },
    'csl-raw': () => { CslState.showRaw = !CslState.showRaw; rerender(); },
    'copy-view': () => copyLogs('view'),
    'copy-all': () => copyLogs('all'),
    lp: () => { S.lp = !S.lp; rerender(); },
    'clear-log': () => { if (S.logs.length) S.clearSeq = S.logs[S.logs.length - 1].i || 0; S.logs = []; rerender(); },
    'csl-tag-clear': () => { CslState.tagFilter = ''; rerender(); },
    'csl-jump': el => { CslState.tagFilter = el.dataset.tag; S.filter = 'IMPORTANT'; rerender(); },
    'csl-search-clear': () => { CslState.search = ''; rerender(); },

    /* ตั้งค่า */
    async 'test-notify'() {
        clearTimeout(_saveT); await flushSave();
        const r = await api('test_notify');
        if (!r || !r.ok) toast((r && r.error) || 'ทดสอบไม่สำเร็จ', 'warn', 2500);
    },
    'kill-rbx': () => api('kill_roblox').then(r => {
        toast(r.ok ? `ปิด Roblox ${r.killed} ตัว · พร้อมแล้ว` : `ปิด ${r.killed} ตัว`, r.ok ? 'ok' : 'warn', 3000);
        poll();
    }),
    'accent-reset': () => setAccent(DEFAULT_ACCENT),
    'map-default'(el) { S.set.place_id = num(el.dataset.id); save(); rerender(); },
    async 'map-refresh'(el) {
        const pid = num(el.dataset.id);
        el.disabled = true;
        const info = await fetchMapInfo(pid);
        el.disabled = false;
        if (!info) { toast('อัปเดตไม่สำเร็จ — ตรวจอินเทอร์เน็ตแล้วลองใหม่', 'warn', 3000); return; }
        libUpsert(pid, info); save(); rerender();
        toast(`อัปเดต: ${info.name || 'Place ' + pid}`, 'ok', 2000);
    },
    async 'map-del'(el) {
        const pid = num(el.dataset.id), m = libGet(pid); if (!m) return;
        const users = S.accounts.filter(a => num(a.place_id) === pid);
        const msg = `ลบ “${m.name || 'Place ' + pid}” ออกจากคลัง?`
            + (users.length ? `\nมี ${users.length} บัญชีเลือกแมพนี้อยู่ — จะกลับไปใช้แมพเริ่มต้น (Global)` : '')
            + (num(S.set.place_id) === pid ? '\nแมพนี้เป็นแมพเริ่มต้นอยู่ — จะเหลือว่าง' : '');
        if (!await ask(msg, { confirm: true, ok: 'ลบ' })) return;
        S.set.maps = mapLib().filter(x => x.id !== pid);
        if (num(S.set.place_id) === pid) S.set.place_id = 0;
        users.forEach(a => { a.place_id = 0; api('set_account', a.id, { place_id: 0 }).catch(() => { }); });
        save(); rerender(); poll();
    },
};
$('#main').addEventListener('click', e => {
    const el = e.target.closest('[data-act]');
    if (!el || el.disabled || !ACT[el.dataset.act]) return;
    ACT[el.dataset.act](el, e);
});

async function applyLayoutNow(quiet) {
    try {
        clearTimeout(_saveT); await flushSave();            // ใช้ค่าตารางล่าสุดที่เพิ่งแก้
        const r = await api('apply_layout');
        if (r && r.ok) toast(`จัดตาราง ${S.set.grid_cols ?? 8}×${S.set.grid_rows ?? 6} แล้ว (${r.placed}/${r.total})`, 'ok', 2000);
        else if (!quiet) toast((r && r.error) || 'จัดไม่สำเร็จ', 'warn', 3000);
    } catch (e) { if (!quiet) toast('จัดไม่สำเร็จ: ' + e, 'err'); }
}
async function runHealthCheck(ids) {
    const r = await api('check_health', ids);
    if (!r || !r.ok) { toast((r && r.error) || 'ตรวจไม่สำเร็จ', 'warn', 2500); return; }
    toast(`กำลังตรวจ ${r.count} บัญชี…`, 'ok', 2000);
    poll();
}
/* ======================================================================
   ACTIONS
   ====================================================================== */
function go(v) {
    if (v !== 'acc' && S.selMode) { S.selMode = false; S.sel.clear(); }
    S.view = v; rerender();
}

async function launchAccounts(ids) {
    const idle = ids.filter(id => {
        const a = S.accounts.find(x => x.id === id);
        return a && ['IDLE', 'ERROR', 'COOLDOWN'].includes(a.state);
    });
    if (!idle.length) { toast('ไม่มีบัญชีที่ว่างให้เปิด', 'warn'); return; }

    const hasPlace = num(S.set.place_id) > 0 || idle.some(id => {
        const a = S.accounts.find(x => x.id === id);
        return a && num(a.place_id) > 0;
    });
    if (!hasPlace) {
        toast('ยังไม่ได้ตั้ง Place ID — ไปที่ตั้งค่า', 'err', 5000);
        go('set'); return;
    }

    try {
        const r = await api('launch', idle);
        const names = idle.map(i => S.accounts.find(x => x.id === i)?.name).filter(Boolean);
        const preview = names.slice(0, 3).join(', ') + (names.length > 3 ? `… +${names.length - 3}` : '');
        toast(`เพิ่ม ${r?.activated || idle.length} งาน: ${preview}`, 'ok', 4000);
    } catch (e) { toast('เปิดไม่สำเร็จ: ' + e, 'err'); }
    poll();
}

async function stop(id) {
    try { await api('stop', id); } catch (e) { }
    poll();
}

async function bulkImport() {
    const r = await askBulkLogin();
    if (r?.summary) {
        const ok = r.summary.filter(x => x.status === 'ok').length;
        const fail = r.summary.filter(x => x.status === 'error').length;
        if (ok || fail) {
            toast(`สำเร็จ ${ok} บัญชี${fail ? ` · ล้มเหลว ${fail}` : ''}`, ok ? 'ok' : 'warn', 4000);
        }
    }
    poll();
}

async function addAccount(mode) {
    let r;
    try {
        if (mode === 'Cookie') {
            const c = await ask('วาง .ROBLOSECURITY cookie', { secret: true });
            if (!c) return;
            r = await api('add_cookie', c);
        } else if (mode === 'Import ไฟล์') {
            const c = await ask('วาง cookie บรรทัดละ 1 บัญชี', { multi: true });
            if (!c) return;
            r = await api('add_many', c);
        } else if (mode === 'Browser login') {
            toast('เปิดหน้าต่าง Login…', 'info');
            r = await api('browser_login');
        } else {
            const q = await api('quick_begin');
            if (q.error) { toast(q.error, 'err'); return; }
            await ask(`ใส่โค้ด ${q.code} ที่ roblox.com/crossdevicelogin/ConfirmCode\nบนอุปกรณ์ที่ล็อกอินอยู่ แล้วกดตกลง`);
            r = await api('quick_finish');
        }
    } catch (e) { r = { ok: false, error: String(e) }; }
    toast(r?.ok ? 'เพิ่มสำเร็จ: ' + r.added : 'ไม่สำเร็จ: ' + (r?.error || 'unknown'),
        r?.ok ? 'ok' : 'err');
    poll();
}

let _saveT = 0, _saving = false, _saveAgain = false, _saveEnd = 0;
function save() {
    clearTimeout(_saveT);
    _saveT = setTimeout(flushSave, 300);
}
async function flushSave() {
    _saveT = 0;
    if (_saving) { _saveAgain = true; return; }
    _saving = true;
    try { await api('save_settings', JSON.parse(JSON.stringify(S.set))); } catch (e) { }
    _saving = false;
    _saveEnd = Date.now();
    applyAccent();
    if (_saveAgain) { _saveAgain = false; save(); }
}
function settingsDirty() {
    return !!_saveT || _saving || _saveAgain || (Date.now() - _saveEnd < 1500);
}
/** หยุดทุกบัญชีที่กำลังทำงาน (ปุ่ม "หยุดทั้งหมด" บน titlebar + หน้าหลัก) */
async function homeStopAll() {
    const ids = S.accounts.filter(a => a.active || ['QUEUED', 'AUTHENTICATING', 'LAUNCHING', 'LOADING', 'IN_GAME', 'RECONNECTING'].includes(a.state)).map(a => a.id);
    if (!ids.length) { toast('ไม่มีบัญชีที่กำลังทำงาน', 'warn', 2000); return; }
    await Promise.allSettled(ids.map(id => api('stop', id)));
    toast(`หยุด ${ids.length} บัญชีแล้ว`, 'ok', 2200);
    poll();
}


/* ══════════════════════════════════════════════════════════════════════
   15-dock-autohide
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 15-dock-autohide.js — Dock bar โผล่เมื่อเมาส์ใกล้ขอบล่าง */

(() => {
  const dock = document.getElementById('dock');
  if (!dock) return;

  const TRIGGER = 80;
  const HIDE_DELAY = 900;
  let hideT = 0;

  const show = () => {
    clearTimeout(hideT);
    dock.classList.add('show');
  };
  const scheduleHide = () => {
    clearTimeout(hideT);
    hideT = setTimeout(() => {
      if (!dock.matches(':hover')) dock.classList.remove('show');
    }, HIDE_DELAY);
  };

  document.addEventListener('mousemove', e => {
    const near = e.clientY >= innerHeight - TRIGGER;
    if (near || dock.matches(':hover')) show();
    else scheduleHide();
  }, { passive: true });

  dock.addEventListener('mouseenter', show);
  dock.addEventListener('mouseleave', scheduleHide);

  window.flashDock = () => { show(); scheduleHide(); };

  document.addEventListener('keydown', e => {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName) || e.target.isContentEditable) return;
    if (/^[1-6]$/.test(e.key)) window.flashDock();
  });

})();


/* ══════════════════════════════════════════════════════════════════════
   13-boot
   ══════════════════════════════════════════════════════════════════════ */
/* P4NG UI · 13-boot.js — titlebar + boot sequence (ไฟล์สุดท้าย — เริ่มแอป) */

/* ======================================================================
   TITLEBAR
   ====================================================================== */
document.querySelectorAll('[data-wc]').forEach(b => {
    b.onclick = () => api('window_ctl', b.dataset.wc).catch(() => { });
});

/* ======================================================================
   BOOT  (v2 — โหลดจริงทีละขั้น · เห็นความคืบหน้า · เตรียมทุกอย่างก่อนเข้าแอป)
   ====================================================================== */
const BOOT_STEPS = [
    // [id, ชื่อขั้น, น้ำหนักของแถบ %]  (ผลรวม = 100)
    ['load',  'โหลดส่วนประกอบ UI',             12],    // ทำเสร็จแล้วโดย loader ใน index.html
    ['api',   'เชื่อมต่อระบบ',                 5],
    ['clean', 'ปิด Roblox ที่ค้างอยู่',          8],
    ['vault', 'ปลดล็อก vault',                 6],
    ['data',  'โหลดข้อมูลบัญชีและการตั้งค่า',    12],
    ['maps',  'โหลดข้อมูลแมพ',                  20],
    ['imgs',  'โหลดรูปโปรไฟล์และไอคอน',         20],
    ['ui',    'เตรียมทุกหน้าให้พร้อม',            17],
];

async function boot() {
    const $st = () => document.getElementById('boot-status');
    const $bf = () => document.getElementById('boot-bar-fill');
    const $hn = () => document.getElementById('boot-hint');
    const $bs = () => document.getElementById('boot-screen');
    const $pc = () => document.getElementById('boot-pct');
    const sleep = ms => new Promise(r => setTimeout(r, ms));
    const frame = () => new Promise(r => requestAnimationFrame(() => r()));

    // ── รายการขั้นตอน ──
    const list = document.getElementById('boot-steps');
    list.innerHTML = BOOT_STEPS.map(([id, label]) => `
        <li data-step="${id}" class="bs-pending">
          <i class="bs-ic"></i><span class="bs-t">${label}</span><em class="bs-d"></em>
        </li>`).join('');
    const stepEl = id => list.querySelector(`[data-step="${id}"]`);
    window.gsap && gsap.from(list.children, { opacity: 0, x: -10, duration: 0.35, stagger: 0.04, ease: 'power2.out', clearProps: 'all' });
    const weight = Object.fromEntries(BOOT_STEPS.map(([id, , w]) => [id, w]));
    const prog = Object.fromEntries(BOOT_STEPS.map(([id]) => [id, 0]));   // 0..1 ต่อขั้น

    // % ที่แสดง วิ่งตามเป้าหมายอย่างนุ่ม ๆ — GSAP tween บน object กลาง (ไม่มี fallback → ตั้งค่าตรง ๆ)
    const shown = { v: window.__uiLoad ? window.__uiLoad.share : 0 };
    const paint = () => {
        const pc = $pc(), bf = $bf();
        if (pc) pc.textContent = Math.round(shown.v);
        if (bf) bf.style.width = shown.v + '%';
    };
    const goTo = pct => {
        if (!window.gsap) { shown.v = pct; paint(); return; }
        gsap.to(shown, { v: pct, duration: 0.45, ease: 'power2.out', overwrite: true, onUpdate: paint });
    };
    const refreshPct = () => goTo(BOOT_STEPS.reduce((t, [id, , w]) => t + w * prog[id], 0));
    const setSt = msg => { const a = $st(); if (a && msg) a.textContent = msg; };
    const setHint = msg => { const h = $hn(); if (h) h.textContent = msg || ''; };

    const begin = (id, msg) => {
        const el = stepEl(id);
        el.className = 'bs-active';
        setSt(msg || el.querySelector('.bs-t').textContent + '…');
    };
    const detail = (id, txt) => { stepEl(id).querySelector('.bs-d').textContent = txt || ''; };
    const part = (id, f) => { prog[id] = Math.max(0, Math.min(1, f)); refreshPct(); };
    const finish = async (id, cls = 'bs-done', txt) => {
        const el = stepEl(id);
        el.className = cls;
        if (txt !== undefined) detail(id, txt);
        prog[id] = 1; refreshPct();
        await sleep(140);          // ให้เห็นติ๊กถูกของแต่ละขั้น
    };

    // เปิดแอป: การ์ดโหลดหดเลือน → หน้าจอโหลดจาง → titlebar / การ์ดหน้าแรก / dock ไหลเข้ามาซ้อนกัน (ไม่ตัดฉับ)
    const hide = () => {
        const el = $bs();
        if (!el) return;
        const done = () => { el.style.display = 'none'; el.style.visibility = 'hidden'; };
        if (!window.gsap) { el.classList.add('out'); setTimeout(done, 500); return; }
        window.flashDock?.();
        gsap.timeline({ onComplete: done })
            .to('.boot-inner', { opacity: 0, y: -18, scale: .95, duration: .4, ease: 'power2.in' })
            .to(el, { opacity: 0, duration: .6, ease: 'power1.inOut' }, '-=.15')
            .from('#titlebar', { y: -30, opacity: 0, duration: .55, ease: 'power3.out', clearProps: 'all' }, '<')
            .from('#main > *', { y: 30, scale: .98, opacity: 0, duration: .75, stagger: .08, ease: 'power3.out', clearProps: 'opacity,transform' }, '<.05');
    };
    let current = 'api';
    const abort = (msg, hint) => {
        const el = stepEl(current);
        if (el) el.className = 'bs-err';
        setSt(msg);
        setHint(hint || '');
        clearTimeout(safety);
        setTimeout(hide, 4000);
    };
    const safety = setTimeout(() => {
        console.warn('[P4NG] boot safety timeout — force hide');
        hide();
    }, 60000);
    const run = (id, msg) => { current = id; begin(id, msg); };

    try {
        // 0 ── ส่วนประกอบ UI (loader ใน index.html โหลดให้แล้ว)
        const L = window.__uiLoad || { total: 0, failed: [] };
        prog.load = 1;
        stepEl('load').className = L.failed.length ? 'bs-warn' : 'bs-done';
        detail('load', L.failed.length ? `ขาด ${L.failed.length} ไฟล์` : `${L.total} ไฟล์`);
        if (L.failed.length) {
            setHint('โหลดไม่ครบ: ' + L.failed.join(', '));
            toast('โหลดไลบรารีไม่ครบ — รัน python tools/fetch_vendor.py แล้วเปิดใหม่', 'warn', 8000);
        }

        // 1 ── เชื่อม API
        run('api');
        const t0poll = Date.now();
        while (!hasCore() && Date.now() - t0poll < 5000) await sleep(100);
        if (!hasCore()) throw new Error('API ไม่พร้อม (รอ 5 วิ)');
        await finish('api');

        // 2 ── เคลียร์ Roblox ค้าง
        run('clean');
        try {
            const kr = await withTimeout(api('boot_cleanup'), 15000);
            if (kr && kr.killed) {
                detail('clean', `${kr.killed} ตัว`);
                setHint(kr.async ? 'กำลังปิด Roblox ที่ค้างอยู่เบื้องหลัง จะพร้อมในอีกสักครู่'
                                 : 'เคลียร์ Roblox ที่ค้างอยู่เรียบร้อย');
            }
            if (kr && kr.ok === false) {
                toast('Multi-instance ยังไม่พร้อม: ' + (kr.reason || ''), 'warn', 6000);
                await finish('clean', 'bs-warn', 'ไม่พร้อม');
            } else await finish('clean');
        } catch (e) {
            console.warn('[P4NG] boot_cleanup:', e);
            toast('ปิด Roblox ที่ค้างอยู่ไม่สำเร็จ — ลองกดปุ่ม "ปิด Roblox" เอง', 'warn', 5000);
            await finish('clean', 'bs-warn', 'ข้าม');
        }

        // 3 ── vault
        run('vault');
        let ok = false;
        try {
            ok = await api('unlock', '__p4ng_auto__');
        } catch (e) {
            console.error('[P4NG] unlock error:', e);
            throw new Error('unlock ล้มเหลว: ' + (e?.message || e));
        }
        while (!ok) {
            setSt('รอรหัสผ่าน vault…');
            const pw = await ask(
                'vault.enc เปิดไม่ได้ — ไฟล์อาจเสีย หรือเป็นไฟล์จากโปรแกรมรุ่นเก่า\n' +
                '• ใส่รหัสเดิม (ถ้าเคยตั้ง) → กู้ cookie เดิมกลับมา\n' +
                '• เว้นว่างแล้วกดตกลง → สร้าง vault ใหม่ (ไฟล์เดิมถูกสำรองเป็น .bak)',
                { secret: true, ok: 'ตกลง' });
            if (pw === null) {
                abort('ยกเลิก — vault ไม่ได้ปลดล็อก',
                      'กด F5 เพื่อเริ่มใหม่ หรือปิดแอปแล้วเปิดใหม่');
                return;
            }
            if (pw === '') {
                ok = await api('reset_vault');
                if (ok) toast('สร้าง vault ใหม่แล้ว', 'ok', 4000);
            } else {
                ok = await api('unlock', pw);
                if (ok) toast('ปลดล็อกสำเร็จ', 'ok', 3500);
                else toast('รหัสไม่ถูกต้อง', 'err', 2500);
            }
        }
        await finish('vault');

        // 4 ── state + settings
        run('data');
        const s0 = await api('state');
        if (!s0 || !s0.accounts) throw new Error('state() ตอบผิดรูปแบบ');
        Object.assign(S.set, s0.settings || {});
        S.cfgCrc = s0.cfg_crc || 0;
        if (!Array.isArray(S.set.account_order)) S.set.account_order = [];
        applyAccent();
        loadState(s0);
        Object.assign(S.gameCache, loadGameInfoCache());
        await finish('data', 'bs-done', `${S.accounts.length} บัญชี`);

        // 5 ── คลังแมพ: อ่านจาก settings.json ได้เลย (ไม่ต้องโหลดจากเว็บ)
        //      ย้ายแมพเก่าที่ยังไม่อยู่ในคลัง (Global + ของแต่ละบัญชี) เข้าคลังให้ครั้งเดียว — รอบต่อไปไม่ดึงอีก
        run('maps');
        const pids = new Set();
        if (num(S.set.place_id)) pids.add(num(S.set.place_id));
        S.accounts.forEach(a => { const pid = num(a.place_id) || num(S.set.place_id); if (pid) pids.add(pid); });
        mapLib().forEach(m => pids.add(m.id));
        let libDirty = false;
        const missing = [...pids].filter(pid => !libGet(pid));
        missing.filter(pid => S.gameCache[pid]).forEach(pid => { libDirty = libUpsert(pid, S.gameCache[pid]) || libDirty; });
        const need = missing.filter(pid => !libGet(pid));
        if (need.length) {
            let done = 0;
            const upd = () => { part('maps', done / need.length); detail('maps', `${done}/${need.length}`); setSt(`ย้ายแมพเข้าคลัง… (${done}/${need.length})`); };
            upd();
            await Promise.allSettled(need.map(pid =>
                withTimeout(fetchMapInfo(pid), 8000).catch(() => null).then(info => {
                    if (info) libDirty = libUpsert(pid, info) || libDirty;
                    done++; upd();
                })));
        }
        if (libDirty) { clearTimeout(_saveT); await flushSave(); }
        await finish('maps', 'bs-done', pids.size ? `${mapLib().length} แมพในคลัง` : 'ไม่มี');

        // 6 ── รูปทั้งหมด (avatar + ไอคอน/แบนเนอร์แมพ) โหลดเข้า cache ของ browser ล่วงหน้า
        run('imgs');
        const urls = new Set();
        S.accounts.forEach(a => a.avatar_url && urls.add(a.avatar_url));
        pids.forEach(pid => { const g = mapInfo(pid); if (g) { g.icon && urls.add(g.icon); g.banner && urls.add(g.banner); } });
        const imgList = [...urls];
        if (imgList.length) {
            let n = 0;
            const upd = () => { part('imgs', n / imgList.length); detail('imgs', `${n}/${imgList.length}`); setSt(`โหลดรูป… (${n}/${imgList.length})`); };
            upd();
            await Promise.all(imgList.map(u => new Promise(res => {
                const im = new Image();
                const fin = () => { n++; upd(); res(); };
                im.onload = im.onerror = fin;
                setTimeout(() => { if (!im.complete) fin(); }, 6000);      // รูปช้าเกิน 6 วิ ไม่รอ
                im.src = u;
            })));
            await finish('imgs', 'bs-done', `${imgList.length} รูป`);
        } else await finish('imgs', 'bs-done', 'ไม่มี');

        // 7 ── ฟอนต์ + สร้างทุกหน้าไว้นอกจอหนึ่งรอบ (layout/ภาพ/สไตล์พร้อมก่อนผู้ใช้กดเข้า)
        run('ui');
        try {
            await withTimeout(Promise.all([
                document.fonts.load('400 14px "Noto Sans Thai"'), document.fonts.load('600 14px "Noto Sans Thai"'),
                document.fonts.load('700 14px "Noto Sans Thai"'), document.fonts.load('400 12px "JetBrains Mono"'),
            ]).then(() => document.fonts.ready), 4000);
        } catch (e) { /* ฟอนต์ช้า — ไม่ขวาง */ }
        const keys = Object.keys(Views);
        const ghost = document.createElement('div');
        ghost.setAttribute('aria-hidden', 'true');
        ghost.style.cssText = 'position:fixed;left:-99999px;top:0;width:1200px;visibility:hidden;pointer-events:none';
        document.body.appendChild(ghost);
        for (let i = 0; i < keys.length; i++) {
            setSt(`เตรียมหน้า ${keys[i]}…`);
            try { ghost.innerHTML = Views[keys[i]].html(); } catch (e) { console.warn('[P4NG] preload view', keys[i], e); }
            part('ui', (i + 1) / keys.length);
            detail('ui', `${i + 1}/${keys.length}`);
            await frame();
        }
        ghost.remove();
        _lastKey = '';
        _lastView = S.view;                 // render แรกไม่เล่นแอนิเมชันเข้า — hide() เป็นคนเปิดฉากเอง
        S.ready = true;
        render();
        await finish('ui', 'bs-done', `${keys.length} หน้า`);

        // เสร็จ
        clearTimeout(safety);
        goTo(100);
        setSt('พร้อมใช้งาน');
        setHint('');
        await sleep(380);
        hide();
        toast('พร้อมทำงาน', 'ok', 2600);
        pollLoop();

    } catch (e) {
        console.error('[P4NG] boot failed:', e);
        abort('ผิดพลาด: ' + (e?.message || e),
              'ลองปิดแอปแล้วเปิดใหม่ · กด F12 เพื่อดู log');
    }
}

// ── start ──
if (hasCore()) boot();
else window.addEventListener('pywebviewready', boot);


/* ── 19d parallax: พื้นหลังเลื่อนตามเมาส์ scroll ─────────────────────────
   กริดเลื่อนช้ากว่าเนื้อหา (~40%) แสง accent เลื่อนช้ากว่านั้นอีก · ใช้ค่า lerp ให้ลื่นต่อเนื่อง
   หน้าที่ไม่มีอะไรให้ scroll (scrollHeight <= clientHeight) → target = 0 พื้นหลังไม่ขยับ */
(() => {
  const main = document.getElementById('main');
  if (!main) return;
  const root = document.documentElement;
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const GRID = 54, GRID_SPEED = .4;
  let sy = 0, gp = 0, raf = 0;                       // ค่าที่แสดงอยู่ (ถูก lerp เข้าหาเป้าหมาย)

  const target = () => {
    const max = main.scrollHeight - main.clientHeight;
    if (max <= 4 || reduce.matches) return { y: 0, p: 0 };
    return { y: main.scrollTop, p: Math.min(1, main.scrollTop / max) };
  };
  const tick = () => {
    raf = 0;
    const t = target();
    sy += (t.y - sy) * .14;
    gp += (t.p - gp) * .14;
    if (Math.abs(t.y - sy) < .3) sy = t.y;
    if (Math.abs(t.p - gp) < .002) gp = t.p;
    root.style.setProperty('--gy', (-((sy * GRID_SPEED) % GRID)).toFixed(2) + 'px');
    root.style.setProperty('--gp', gp.toFixed(4));
    if (sy !== t.y || gp !== t.p) raf = requestAnimationFrame(tick);
  };
  const kick = () => { if (!raf) raf = requestAnimationFrame(tick); };

  main.addEventListener('scroll', kick, { passive: true });
  window.addEventListener('resize', kick);
  new MutationObserver(kick).observe(main, { childList: true });   // เปลี่ยนหน้า → ความสูงเปลี่ยน → คำนวณใหม่
  reduce.addEventListener?.('change', kick);
})();


/* ══════════════════════════════════════════════════════════════════════
   19d · เมนูคลิกขวา (context menu) — ลดปุ่มบนหน้าจอ
   ══════════════════════════════════════════════════════════════════════ */
let _ctx = null;
function closeCtx() {
    if (!_ctx) return;
    _ctx.remove(); _ctx = null;
    document.removeEventListener('mousedown', _ctxAway, true);
    document.removeEventListener('keydown', _ctxKey, true);
    removeEventListener('blur', closeCtx);
    removeEventListener('resize', closeCtx);
    $('#main')?.removeEventListener('scroll', closeCtx);
}
function _ctxAway(e) { if (_ctx && !_ctx.contains(e.target)) closeCtx(); }
function _ctxKey(e) { if (e.key === 'Escape') { e.stopPropagation(); closeCtx(); } }

/* items: { ic, t, fn, danger?, disabled?, hint? } | { sep: 1 } | { head: 'ข้อความหัวเมนู' } */
function openCtx(x, y, items) {
    closeCtx();
    const m = document.createElement('div');
    m.className = 'ctx';
    m.innerHTML = items.map((it, i) => it.sep ? '<i class="ctx-sep"></i>'
        : it.head ? `<div class="ctx-head">${esc(it.head)}</div>`
        : `<button type="button" class="ctx-i${it.danger ? ' danger' : ''}" data-i="${i}"${it.disabled ? ' disabled' : ''}>
             ${it.ic ? ICON[it.ic](14) : '<span class="ctx-nic"></span>'}<span>${esc(it.t)}</span>${it.hint ? `<small>${esc(it.hint)}</small>` : ''}</button>`).join('');
    m.style.visibility = 'hidden';
    document.body.appendChild(m);
    const w = m.offsetWidth, h = m.offsetHeight, M = 8;
    m.style.left = Math.max(M, Math.min(x, innerWidth - w - M)) + 'px';
    m.style.top = Math.max(M, Math.min(y, innerHeight - h - M)) + 'px';
    m.style.visibility = '';
    m.onclick = e => {
        const b = e.target.closest('.ctx-i');
        if (!b || b.disabled) return;
        const it = items[+b.dataset.i];
        closeCtx();
        try { it.fn && it.fn(); } catch (err) { console.error(err); }
    };
    m.oncontextmenu = e => e.preventDefault();
    _ctx = m;
    requestAnimationFrame(() => m.classList.add('in'));
    document.addEventListener('mousedown', _ctxAway, true);
    document.addEventListener('keydown', _ctxKey, true);
    addEventListener('blur', closeCtx);
    addEventListener('resize', closeCtx);
    $('#main')?.addEventListener('scroll', closeCtx, { passive: true });
}

function accMenuItems(a) {
    const run = running(a), id = String(a.id), fake = { dataset: { id } };
    return [
        { head: a.name },
        run ? { ic: 'stop', t: 'หยุด', fn: () => ACT.stop(fake) } : { ic: 'play', t: 'เริ่ม', fn: () => ACT.start(fake) },
        { ic: 'view', t: 'ดูหน้าต่างเกม', disabled: !run, fn: () => ACT.view(fake) },
        { sep: 1 },
        { ic: 'star', t: a.pinned ? 'เลิกปักหมุด' : 'ปักหมุดไว้บนสุด', fn: () => ACT.pin(fake) },
        { ic: 'edit', t: 'แก้ไขบัญชี…', fn: () => ACT.edit(fake) },
        { ic: 'copy', t: 'คัดลอก user:password', disabled: !a.has_pw, fn: () => ACT.copy(fake) },
        { ic: 'shield', t: 'ตรวจสถานะ cookie', fn: () => runHealthCheck([a.id]) },
        { ic: 'sel', t: S.sel.has(a.id) ? 'ยกเลิกเลือก' : 'เลือกบัญชีนี้', fn: () => { if (S.view === 'acc' && !S.selMode) setSelMode(true); toggleSel(a.id, false); } },
        { sep: 1 },
        { ic: 'trash', t: 'ลบบัญชี…', danger: true, fn: async () => {
            const yes = await askDelete([a]);
            if (!yes) return;
            const r = await api('delete_account', a.id);
            r && r.ok ? (toast(`ลบ ${a.name} แล้ว`, 'ok', 2200), poll()) : toast((r && r.error) || 'ลบไม่สำเร็จ', 'err', 3500);
        } },
    ];
}
ACT['acc-menu'] = (el) => {
    const a = S.accounts.find(x => x.id === +el.dataset.id);
    if (!a) return;
    const r = el.getBoundingClientRect();
    openCtx(r.right - 4, r.bottom + 4, accMenuItems(a));
};

document.addEventListener('contextmenu', e => {
    if (!e.target.closest || e.target.closest('input, textarea, .csl-row, .ctx')) return;
    const card = e.target.closest('.acard[data-row]');
    if (card) {
        const a = S.accounts.find(x => x.id === +card.dataset.row);
        if (a) { e.preventDefault(); openCtx(e.clientX, e.clientY, accMenuItems(a)); }
        return;
    }
    const job = e.target.closest('.row[data-job]');
    if (job) {
        e.preventDefault();
        const id = +job.dataset.job, j = S.jobs.find(x => x.id === id);
        openCtx(e.clientX, e.clientY, [
            { head: `งาน #${id}` },
            { ic: 'close', t: j && j.state === 'RUNNING' ? 'ยกเลิกงานที่กำลังรัน' : 'ยกเลิกงานนี้', danger: true, fn: () => ACT['cancel-job']({ dataset: { id: String(id) } }) },
        ]);
    }
});

if (hasCore()) setTimeout(updInit, 6000);   // ตรวจอัปเดตหลังแอปพร้อมใช้งาน (เงียบ ๆ)
