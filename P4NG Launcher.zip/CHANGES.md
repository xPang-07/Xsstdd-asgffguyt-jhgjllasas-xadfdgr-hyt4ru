# Update 25 — api.lua จับการหลุดแม่นขึ้น · เก็บกวาด Roblox ที่ซ่อนในถาด · ระบบอัปเดตอัตโนมัติ (GitHub Releases)
- **ui/api.lua**: จับการหลุด 3 ทาง (ErrorMessageChanged + ดัก ErrorPrompt ใน CoreGui + poll GetErrorCode) · กรอง false positive (`IGNORED_CODES`/`IGNORED_MESSAGES`) · reason ใช้ข้อความจาก prompt จริง (ตัด 200 ตัวอักษร) · โหมดลดภาระเครื่อง (ค่าเริ่มต้นเปิด ปิดด้วย `getgenv().P4NG_LOWGFX = false`, จำกัด FPS ด้วย `P4NG_FPS`) · heartbeat 10 วิ + ถอยห่างเมื่อ launcher ไม่ตอบ (ต้อง < `BEAT_LOST` 25 วิ)
- **Roblox ที่ซ่อนในถาด**: process ที่ไม่ผูกบัญชีและไม่มีหน้าต่างที่มองเห็นต่อเนื่อง `HIDDEN_SECS` (10 วิ) และเปิดมานาน ≥ `HIDDEN_MIN_AGE` (20 วิ) จะถูก end task · `window_snapshot` คืนค่าที่ 3 (`any_visible`) (`core/app.py`, `core/roblox.py`)
- **ระบบอัปเดต**: `core/version.py` (VERSION/UPDATE_REPO/UPDATE_TOKEN) · `core/updater.py` (ตรวจ → โหลด → ตรวจ sha256/กัน zip-slip/จำกัดโดเมน GitHub) · `core/apply_update.py` (ตัวช่วยแยกกระบวนการ: รอแอปปิด → สำรอง → เขียนทับ → pip ถ้า requirements เปลี่ยน → เปิดใหม่ · ข้าม `data/` `portable.txt`) · UI: ตั้งค่า → อัปเดตแอป + toast ตอนเปิดแอป (ปิดได้ `auto_update_check`) · ถามยืนยันถ้ามีบัญชีกำลังรัน
- **ออกเวอร์ชัน**: แก้ `VERSION` → `python tools/make_release.py` → อัปโหลด zip เป็น asset ของ Release (tag `v<VERSION>`) ใน repo ปล่อยไฟล์สาธารณะที่ชื่อสุ่ม แล้วตั้ง `UPDATE_REPO` ให้ชี้ไปที่ repo นั้น
- ไฟล์: `ui/api.lua` · `core/app.py` · `core/roblox.py` · `core/config.py` · `core/version.py` · `core/updater.py` · `core/apply_update.py` · `main.py` · `ui/app.js` · `tools/make_release.py` · ทดสอบ: py_compile/node --check, ตัวเขียนไฟล์ทับ + zip-slip บน Linux · ยังไม่ได้ลองบน Windows/pywebview และกับ GitHub จริง

# Update 24 — สไตล์ hiwdo (ลด glow) · ปักหมุด · โหมดเลือกใหม่ · การ์ดกะทัดรัด
- **ลด glow ทั้งแอป (ดู `ui/app.css` หมวด 24)**: พื้นม่วงดำอมไวน์ + กริดจาง + แสงไวน์จางด้านซ้ายจุดเดียว (เดิมมีแสงบน/ล่าง/ซ้ายหลายชั้น) · ตัดวงเรือง/pulse ของจุดสถานะ · พื้นผิวแบน ขอบบาง · ปุ่มหลักเป็นปุ่มขอบสี accent (ไม่ทึบ) · สี accent เริ่มต้นเป็นโรส `#e8456b` (เพิ่ม preset "โรส" ในตั้งค่า → ธีมสี; ผู้ที่เคยเลือกสีไว้แล้วค่าเดิมยังอยู่ กด "คืนค่าเริ่มต้น" เพื่อใช้โรส)
- **โหมดเลือกบัญชี**: เมื่อไม่มีบัญชีไหนถูกเลือก (เลิกติ๊กใบสุดท้าย / เลือกทั้งหมดแล้วกดซ้ำ / "เลือกตาม…" แล้วไม่มีผล / เหตุผลอื่นที่ทำให้เหลือ 0) จะ**ออกจากโหมดเลือกทันที** · ช่องเลือกเปลี่ยนจากวงกลมเป็นสี่เหลี่ยมมนเล็กมุมขวาบนการ์ด (ปกติจาง · hover โผล่ · โหมดเลือกเห็นทุกใบ · เลือกแล้วเติมสี accent + เครื่องหมายถูก)
- **ปักหมุด (ดาว)**: ปุ่มดาวต่อท้ายชื่อบัญชี (หน้าหลัก + หน้าบัญชี) และเมนูคลิกขวา/⋯ · บัญชีที่ปักขึ้นบนสุดเสมอ ลำดับในกลุ่มเดิมไม่เปลี่ยน · เก็บถาวรใน `accounts.json` (`pinned`) · ลำดับจัดหน้าต่าง Roblox (`_account_rank`) ใส่บัญชีที่ปักไว้ก่อนด้วย
- **การ์ดบัญชีใหม่ (กะทัดรัด)**: เอาแถบสีสถานะด้านบนออก → สถานะเป็นจุดสีมุมล่างขวาของรูป + ข้อความสถานะสีเดียวกันใต้ชื่อ · แมพและ CPU/RAM เป็นข้อความเล็กไม่มีกรอบ · ไม่มีเส้นคั่นเหนือปุ่ม · ไอคอน cookie แสดงเฉพาะเมื่อมีปัญหา · uid ย้ายไปอยู่ใน tooltip ของ "ID"
- ลบป้าย "แสดง x จาก y" ที่หัวหน้าบัญชี
- ไฟล์: `ui/app.js` · `ui/app.css` (หมวด 24 + ลบกฎช่องเลือกเก่า) · `core/app.py` · `core/config.py` · `main.py` (อนุญาต `pinned` ใน set_account) · ทดสอบด้วย headless Chromium + mock backend (ไม่มี JS error) · ยังไม่ได้ลองบน Windows/pywebview จริง

# Update 23 — หน้าบัญชี 5 การ์ดต่อแถวในหน้าต่างขนาดปกติ
- จุดตัดคอลัมน์เดิมลดเป็น 4 ต่อแถวเมื่อกว้าง ≤ 1360px (หน้าต่างเริ่มต้น 1280 จึงเห็นแค่ 4) → ย้ายจุดตัด: **5 ต่อแถวเมื่อกว้าง ≥ 1120px** · 4 ต่อแถว 900–1119 · 3 ต่อแถว 680–899 · 2 ต่อแถว 460–679 · 1 ต่อแถว < 460
- การ์ดในหน้าบัญชีกะทัดรัดขึ้นให้พอดี 5 ช่อง: padding/อวาตาร์/ฟอนต์เล็กลงเล็กน้อย · "ID · uid" ลงบรรทัดใหม่เสมอ ไม่ดันชื่อ · ปุ่มเริ่ม/หยุดและปุ่มรองคงขนาดกดง่าย
- หน้าหลักไม่เปลี่ยน · แก้เฉพาะ `ui/app.css` (หมวด 23 ท้ายไฟล์)

# Update 22 — Fit-to-window: dialog ไม่ล้นหน้าต่าง + โหมดกะทัดรัดเมื่อหน้าต่างเตี้ย
- **แก้บั๊ก (จาก Update 21):** dialog แก้ไขบัญชีสูง 724px ตายตัว ทำให้ปุ่ม บันทึก/ยกเลิก ถูกตัดที่ขอบล่างเมื่อหน้าต่างเตี้ยกว่า ~800px (หน้าต่างหลักตั้ง min 980×640) → ใช้ความสูงอิงขนาดหน้าต่างจริง `calc(100vh - titlebar - 32px)` กับทุก dialog · เนื้อหาเลื่อนในกล่อง ส่วนหัว/ท้ายอยู่กับที่เสมอ
- **โหมดกะทัดรัดอัตโนมัติเมื่อสูง ≤ 780px:** ลด padding dialog · การ์ด "วิธีเข้าเกม" เป็นแนวนอน (ซ่อนบรรทัดอธิบาย) · modal ลบย่อรายการให้พอดี · หัวหน้า/hero/การ์ดตัวเลขเล็กลงเล็กน้อย · ≤ 680px ย่อเพิ่มอีกขั้น
- ไม่เปลี่ยนขนาดหน้าต่างเริ่มต้น (1280×800) และไม่ย่อ UI ทั้งแอป · ทดสอบที่ 1262×759, 980×640, 1280×800 · แก้เฉพาะ `ui/app.css` (หมวด 22 ท้ายไฟล์)

# Update 21 — modal ลบบัญชีแบบ "อันตราย" + การเชื่อมต่อที่อ่านง่าย
**modal ลบบัญชี (ใหม่ `askDelete`)** — ใช้ทั้ง 3 จุด: ปุ่มลบในหน้าแก้ไขบัญชี · เมนูคลิกขวา · ลบหลายบัญชี
- โทนแดงทั้งกล่อง: แถบแดงด้านบน · ไอคอนถังขยะมีวงพัลส์ · ข้อความ "การลบนี้ย้อนกลับไม่ได้" · ปุ่ม "ลบถาวร" แดงทึบ (เดิมเป็นปุ่มม่วงปกติ)
- แสดง **บัญชีที่จะถูกลบ** (อวาตาร์ ชื่อ ID/uid + ป้าย "กำลังทำงาน") — ลบหลายบัญชีเลื่อนดูรายการได้
- แสดง **"สิ่งที่จะเกิดขึ้น"** เป็นรายการ: ปิดเกมที่เปิดอยู่ · ลบ cookie/รหัสผ่านจาก vault · ลบออกจากรายการและคิวงาน · บัญชีบน Roblox ไม่ถูกลบ (ลบเฉพาะข้อมูลในแอป)
- กันเผลอ: โฟกัสเริ่มต้นอยู่ที่ "ยกเลิก" · กด Enter **ไม่**ลบ · ลบตั้งแต่ 2 บัญชีขึ้นไปต้องติ๊ก "ฉันเข้าใจว่ากู้คืนไม่ได้" ก่อนปุ่มลบจะกดได้
- จัดสัดส่วนใหม่: หัว (ไอคอน+ชื่อเรื่อง) · เนื้อหา · ท้าย (ปุ่มยกเลิก/ลบ ขนาดเท่ากัน ชิดขวา)

**การเชื่อมต่อ (หน้าแก้ไขบัญชี → แท็บเกม)**
- เดิมเป็นช่อง Private server + Join friend คู่กันโดยไม่อธิบาย → ตอนนี้เป็น **การ์ดเลือกวิธีเข้าเกม 3 แบบ**: เซิร์ฟเวอร์ปกติ · Private server · ตามเพื่อน (เลือกได้อย่างเดียว) ตรงกับลำดับที่ core ใช้จริง (ตามเพื่อน > private > ปกติ)
- Private server: วางลิงก์เต็มได้ → ระบบ **แยก privateServerLinkCode ให้เองและโชว์รหัสที่ตรวจพบ** (เดิมเก็บค่าที่วางไปตรง ๆ แล้ว core ส่งเป็น linkCode ทำให้ลิงก์เต็มเข้าเกมไม่ได้) · ลิงก์แบบ `share?code=` หรืออ่านรหัสไม่ได้ → เตือนทันที
- ตามเพื่อน: ช่อง @username + อธิบายกติกา 3 ข้อ (ตามไปแมพที่เพื่อนอยู่ · ต้องเป็นเพื่อนกัน · หาไม่เจอ → เซิร์ฟเวอร์ปกติ) และจาง "เกมปลายทาง" ให้รู้ว่าแมพไม่ถูกใช้
- ตรวจก่อนบันทึก: โหมด private ที่ลิงก์ว่าง/ผิด หรือโหมดเพื่อนที่ไม่กรอกชื่อ → ไม่บันทึก + แจ้งเตือน · บันทึกเฉพาะค่าของโหมดที่เลือก (อีกช่องถูกล้าง)
- dialog แก้ไขบัญชีสูงขึ้น (580 → 724px) ให้พอดีกับเนื้อหาใหม่ โดยจอเตี้ยกว่านั้นจะเลื่อนในกล่อง

ไฟล์ที่แก้: `ui/app.js` (askDelete · ส่วน connMode ใน askAccount) · `ui/app.css` (หมวด 21 ท้ายไฟล์ + ความสูง .dialog.ae) · ไม่แตะ `core/` และ `main.py` · ทดสอบด้วย Chromium + mock เท่านั้น

# Update 20 — ไม่มีโหมดแล้ว · หน้าบัญชี 5 ต่อแถว · คลังแมพ
- **หน้าบัญชี**: ลบแท็บกรอง (ทั้งหมด/ออนไลน์/รอคิว/…) ออก เหลือช่องตัวเลข 4 ช่องด้านบน (ทั้งหมด · ออนไลน์ · ว่าง · ต้องดูแล) ที่กดกรองได้ (กดซ้ำ = กลับเป็นทั้งหมด) · 1 แถว = **5 บัญชี** (จอแคบลดเป็น 4/3/2/1) · ตัดแถวข้อความสถานะ ("รอ api.lua แจ้งเข้าเกม" ฯลฯ) ออกจากการ์ด
- **ยกเลิกโหมด ฟาร์ม/ปกติ ทั้งระบบ**: ทุกบัญชีใช้ค่าเดียวกันและตั้งได้ตลอด — FPS รายบัญชี + Auto-reconnect แสดงเสมอ · จัดหน้าต่าง/ย่ออัตโนมัติใช้กับทุกบัญชี · โปรไฟล์ทรัพยากรในตั้งค่าใช้งานจริงแล้ว (เดิมฟาร์มล็อก Ultra Low) · `normal_quality` → `quality` (1–10, ค่าเริ่มต้น 1) · ลบ chip โหมด, ปุ่มสลับโหมด (การ์ด/เมนูคลิกขวา/แถบเลือกหลายบัญชี), `set_mode`, `set_mode_bulk` · settings schema 6 ลบ `mode`/`normal_quality` ให้เอง · `mode` ใน accounts.json ถูกเมินตอนโหลด
- **คลังแมพ (ตั้งค่า → คลังแมพ)**: เพิ่มแมพด้วยปุ่มเลือกเกม หรือวางลิงก์/Place ID ครั้งเดียว → เก็บ ชื่อ/รูป/ผู้สร้าง ไว้ใน `settings.json` (`maps`) · ดาว = แมพเริ่มต้น (Global) · รีเฟรชข้อมูล · ลบ (บัญชีที่ใช้แมพนั้นจะกลับไปใช้ Global) · หน้าแก้ไขบัญชี → เกม เลือกจากคลังได้ทันที ไม่โหลดจากเว็บ Roblox · ทุกที่ที่แสดงแมพอ่านจากคลัง ไม่มี request ตอนเปิดหน้า/การ์ดอีก · ตอนเปิดแอปครั้งแรกหลังอัปเดต แมพเดิม (Global + ของแต่ละบัญชี) จะถูกย้ายเข้าคลังให้อัตโนมัติครั้งเดียว
- **20b**: หน้าแก้ไขบัญชี → เกม ตัดตัวเลือก "ใช้แมพ Global" ออก — เปิดมาจะเลือกแมพเริ่มต้นให้เลย (มีป้าย "ค่าเริ่มต้น") · ถ้าเลือกเท่าแมพเริ่มต้น บัญชีจะตามค่าเริ่มต้นต่อไป
- ไฟล์: `core/app.py`, `core/config.py`, `main.py`, `ui/app.js`, `ui/app.css` (หมวด 19f)
- ทดสอบด้วย Chromium + mock backend (ไม่มี error) · ยังไม่ได้ลองบน Windows/pywebview จริง

- **19e (รอบรีวิว 2)**:
  - การ์ดบัญชีสูงเท่ากันเสมอ: ทุกใบมีแถวคำอธิบาย + CPU/RAM ความสูงคงที่ (ไม่รัน = ช่องจาง "CPU —") ไม่กระโดดตอนเริ่ม/หยุด · ตัวเลขท้ายแท็บกรองอยู่กึ่งกลางแนวตั้ง
  - **คลิกขวา**: การ์ดบัญชี (เริ่ม/หยุด · ดูหน้าต่าง · สลับโหมด · แก้ไข · คัดลอก · ตรวจ cookie · เลือก · ลบ) · งานในคิว (ยกเลิก) · แถว log (คัดลอก · กรอง tag · ค้นหา) · บนการ์ดเหลือแค่ปุ่ม เริ่ม/หยุด + ปุ่ม ⋯ (เปิดเมนูเดียวกัน) · ปุ่ม แก้ไข/ดู/คัดลอก ถูกย้ายเข้าเมนู · ปุ่ม × ในแถวคิวถูกถอด
  - **ตั้งค่า → หน้าต่าง Roblox**: สวิตช์ "ย่อหน้าต่างอัตโนมัติ" (`auto_minimize`, ปิดเป็นค่าเริ่มต้น) ย่อหน้าต่างบัญชีโหมดฟาร์มลง taskbar หลังเข้าเกมและจัดตารางเสร็จ · ปุ่ม "ย่อทั้งหมด" · เกมไม่ถูกปิด (`core/system.py: minimize`, `core/app.py: minimize_account/minimize_all`, `main.py: minimize_all`)
  - **คอนโซล**: ค่าเริ่มต้นแสดงเฉพาะที่สำคัญ (INFO/WARN/ERROR) · "ละเอียดทั้งหมด" รวม DEBUG · แถบ "ต้องดู" สรุป WARN/ERROR ล่าสุด 3 เรื่อง (คลิกเพื่อกรอง) · แถวใหม่ เวลา · ระดับ · tag · ข้อความ (ตัดเลขลำดับ/ชื่อระดับซ้ำออก) · log จากหลังบ้านละเอียดขึ้น: ทุกการเปลี่ยนสถานะแสดง `เดิม → ใหม่` + ระยะเวลา, PID, เวลารวมจนเข้าเกม, Place/โหมด/ครั้งที่ลองของทุกงาน, ผลงานคิวพร้อมเวลาที่ใช้, สัญญาณจากบัญชีที่ไม่รู้จัก
  - **คิว**: ลบส่วน "เสร็จล่าสุด" (ประวัติ) ออก
- **19d**: พื้นหลังเลื่อนตามเมาส์ scroll (parallax) — กริดเลื่อนตาม ~40% ของระยะ scroll แสง accent ค่อย ๆ ลอยขึ้นตามความคืบหน้า · ใช้ lerp ให้ลื่น · หน้าที่ไม่มีอะไรให้ scroll พื้นหลังนิ่งเหมือนเดิม · เคารพ reduced-motion · แก้เฉพาะ `ui/app.css` (ท้ายไฟล์) และ `ui/app.js` (ท้ายไฟล์)

# Update 19 — Premium Black: dock ใหม่ · หน้าหลักใหม่ · บัญชีเป็นการ์ด · ถอดกระจก/aurora ออก
- **ถอด Update 18 (Future Glass) ออกทั้งหมด**: aurora, ขอบไล่เฉด, spotlight ตามเมาส์, แสงเรือง, dock magnify · พื้นเป็นดำเรียบ (`--bg #09090b`) การ์ดแบน ขอบบาง
- **Dock ใหม่**: แท่งดำเรียบ · ไอคอน + ชื่อเรียงแนวนอน · หน้าที่เลือกมีพื้นสว่างขึ้น + ไอคอนสี accent · ตัวเลขเป็นป้ายเล็กต่อท้ายชื่อ · ปุ่ม เริ่ม/หยุด ทั้งหมดเป็นปุ่มสีเขียว/แดงแยกชัด · ยังลอยล่างและซ่อนเอง · ปุ่มลัด 1–5 เหมือนเดิม · จอแคบ (<820px) แสดงชื่อเฉพาะหน้าที่เลือก
- **หน้าหลักใหม่**: หัวหน้า → แบนเนอร์ (สัดส่วนเดิม 6:1 ไม่ครอป) → **แผงภาพรวมแผงเดียว** (ซ้าย = จำนวนในเกม + fleet bar · ขวา = CPU / RAM / คิว / ต้องดูแล 4 ช่อง) → การ์ดบัญชี | สถานะระบบ + เหตุการณ์ล่าสุด · ไม่มี hero ซ้อนทับแบนเนอร์แล้ว
- **บัญชีเป็นกล่อง (การ์ด)** แทนแถวแนวนอน ทั้งหน้าหลัก (กะทัดรัด) และหน้าบัญชี (เต็ม): avatar + ชื่อ + ป้ายสถานะ/cookie → โหมด/แมพ → CPU·RAM → ปุ่ม เริ่ม/หยุด ใหญ่ + แก้ไข/ดู(/คัดลอก) · เส้นสีบนสุดการ์ด = สถานะ · grid ปรับจำนวนคอลัมน์ตามความกว้างอัตโนมัติ
- โหมดเลือกบัญชี: วงกลมเลือกอยู่มุมขวาบนของการ์ด · คลิกที่การ์ด / Shift+คลิก / Ctrl+A / Esc / แถบเครื่องมือล่าง ทำงานเหมือนเดิม
- **19b (แก้ตามรีวิว)**: avatar ไม่มีพื้นหลังสีหลังรูป · วงกลมเลือกบัญชีอยู่กึ่งกลางแนวตั้งของ avatar · 1 แถว = 4 บัญชี (จอแคบลดเป็น 3/2/1) และหน้าหลักย้ายสถานะระบบ+เหตุการณ์ไปไว้ล่างเป็น 2 คอลัมน์เพื่อให้การ์ดเต็มความกว้าง · แบนเนอร์แสดงเสมอ (ลบสวิตช์ในตั้งค่า, ปุ่ม ×, action `hide-banner`; ค่า `show_banner` ใน config ไม่ถูกใช้แล้ว) · พื้นหลังใหม่: ดำ + กริดละเอียดจางลง + แสง accent บาง ๆ (นิ่ง ไม่มี animation) · ลบ tooltip ตอน hover ชื่อบัญชี

- **19c (รอบสอง)**: หน้าหลักกลับเป็นแบบเดิม — บัญชี 3 ต่อแถว + สถานะระบบ/เหตุการณ์ล่าสุดอยู่คอลัมน์ขวา (หน้าบัญชียัง 4 ต่อแถว) · ปุ่มเลือกบัญชีเป็นวงกลมมุมขวาบนของการ์ดเสมอ (hover/โหมดเลือก) เลิกใช้กล่องมืดทับ avatar ที่ทำให้วงกลมเบี้ยว · พื้นหลังโทนม่วงดำ + กริด 54px ทั้งหน้า + แสงจางล่างกลาง (อ้างอิงภาพ Hiwdo) · **เปิดแอปแบบไม่มี cmd**: `run.vbs` (ดับเบิลคลิก ไม่มีหน้าต่างแวบเลย) หรือ `run.bat` (ใช้ pythonw) · `run_debug.bat` = เปิดแบบเห็น log · `main.py` เก็บ log ลง `data/launcher.log` เมื่อไม่มี console และใส่ `CREATE_NO_WINDOW` ให้ subprocess ทั้ง 3 จุด (picker / browser login / login-prefill)

- ไฟล์: `ui/index.html` (ลบ `#aurora`) · `ui/app.css` (ตัดหมวด 18 · เพิ่มหมวด 19) · `ui/app.js` (`accRow`→`accCard`, `accActionsHtml`→`accCardActions`, `Views.dash` ใหม่, ลบบล็อก 18-fx) · ไม่แตะ `core/` และ `main.py`
- ทดสอบด้วย headless Chromium + mock backend (หน้าหลัก / บัญชี / โหมดเลือก / จอแคบ — ไม่มี error) · ยังไม่ได้ลองบน pywebview จริง

# Update 18 — Future Glass: UI พรีเมียม ล้ำสมัยขึ้น
- พื้นหลัง **aurora** 3 ก้อนเคลื่อนช้า ๆ (ตามสี accent) + กริดจางที่ขอบบน · titlebar กระจกเบลอ · ชื่อหน้าเป็นตัวอักษรไล่สี
- การ์ด/แถวบัญชี/ตัวเลข: **ขอบไล่เฉดแบบกระจก** + **แสง spotlight ตามเมาส์** + แถวบัญชียกขึ้นและเรืองสีตามสถานะตอน hover · ไอคอนสถิติและตัวเลขเรืองแสง · fleet bar ไล่เฉดมีแสง
- แบนเนอร์: มีแสงกวาดผ่านทุก ~9 วิ · ปุ่มหลักมีแสงวิ่งผ่านตอน hover · toggle/slider เรืองตาม accent
- **Dock (โครงเดิมครบ)**: กระจกเบลอ+ขอบไล่เฉด+แสงเรืองใต้ · **ไอคอนขยายตามเมาส์แบบ macOS** (ขยายเฉพาะไอคอน แถบ active ไม่เพี้ยน) · จุดแสงใต้หน้าที่เลือก · ไอคอนเริ่ม/หยุดเรืองเขียว/แดง
- dialog / toast / เมนู: กระจกเบลอ + เงาเรืองแสง
- เอฟเฟกต์ใช้ transform/opacity เป็นหลัก · หยุดเมื่อหน้าต่างถูกซ่อน (`html.is-hidden`) และเมื่อระบบตั้งค่าลดการเคลื่อนไหว
- ไฟล์: `ui/index.html` (+`#aurora`), `ui/app.css` (หมวด 18), `ui/app.js` (บล็อก 18-fx ท้ายไฟล์) · ย้อนกลับ = ลบ 3 ส่วนนี้ · ทดสอบด้วย Chromium+mock เท่านั้น

# Update 17 — จัดหน้าหลักใหม่ (Hero แบนเนอร์ + Dashboard 2 คอลัมน์) · คง Dock ลอยล่างไว้เหมือนเดิม
- **Dock ไม่เปลี่ยนโครงสร้าง**: ลอยล่าง · ซ่อนเอง · หน้าหลักอยู่กลาง · ปุ่มเริ่ม/หยุดท้ายสุด · ปุ่มลัด 1–5 เหมือนเดิม (เพิ่มแค่ความหรู: ไล่เฉดกระจก + เรืองแสงตาม accent)
- `banner-wide.png` ย้ายจากหน้า "บัญชี" ไปเป็น hero บนสุดของ **หน้าหลัก** · การ์ดภาพรวมซ้อนขอบล่างแบนเนอร์ · สวิตช์ `show_banner` เปลี่ยนชื่อเป็น "แบนเนอร์หน้าหลัก"
- หน้าหลัก: แบนเนอร์ → ภาพรวม → การ์ดตัวเลขมีไอคอน → 2 คอลัมน์ (บัญชี | สถานะระบบ + เหตุการณ์ล่าสุด) · <1100px คอลัมน์ขวาลงไปอยู่ใต้รายการ
- ทุกหน้า: ชื่อหน้าชิดซ้าย + คำอธิบายใต้ชื่อ (`UI.head(..., { sub })`) · `UI.stats` รองรับไอคอน · ปุ่มหลักไล่สี · การ์ด/แถวไล่เฉดนุ่มขึ้น
- ไฟล์ที่แก้: `ui/app.js`, `ui/app.css` (หมวด 17 ท้ายไฟล์) · ไม่แตะ `core/` และ `main.py` · ทดสอบด้วย Chromium + mock เท่านั้น

# Update 16 — แบนเนอร์เต็มความกว้างบนหน้าบัญชี
- เพิ่ม `ui/img/banner-wide.png` (2400×400, 6:1) แสดงบนสุดของหน้า "บัญชี" (`.brand-strip`) แนวเดียวกับ Storm Launcher
- ปุ่ม × (โผล่ตอน hover) ซ่อนแบนเนอร์ · เปิดคืนที่ ตั้งค่า → แอป → "แบนเนอร์หน้าบัญชี" (`show_banner`, ค่าเริ่มต้นเปิด)
- ต้นฉบับแก้ได้ในอาร์ตบอร์ด "Banner strip 6:1" · ส่งออก PNG ทับไฟล์เดิมได้เลย
- แบนเนอร์ 2:1 เดิมยังอยู่ในการ์ด "เกี่ยวกับ"

# Update 15 — โลโก้ใหม่
- แทน `ui/img/logo.png` (512×512, โปร่งใสที่มุม) และ `ui/img/logo.ico` (16/32/48/64/128/256) ด้วยโลโก้ "P จากตารางหน้าต่าง + จุดเขียวออนไลน์"
- ขนาด ≤64 px ใช้เวอร์ชันเฉพาะ (ตัว P ใหญ่ขึ้น ตัดช่องจางออก) เพื่อให้อ่านออกที่ 16–32 px
- ใช้อัตโนมัติที่: แถบชื่อหน้าต่าง, favicon, หน้า boot, หัวการ์ด overlay แจ้งเตือน
- `main.py`: ตั้งไอคอนแถบงาน/Alt-Tab จาก `logo.ico` (`_set_app_icon` ผ่าน WM_SETICON) และตั้ง AppUserModelID = `P4NG.Launcher` ให้แยกกลุ่มจากไอคอน python · ยังไม่ได้ทดสอบบน Windows จริง
- ถ้า build exe: ใช้ `--icon ui/img/logo.ico`

# Update 14 — แบนเนอร์แอป
- เพิ่ม `ui/img/banner.png` (1600×800, 2:1) แสดงบนสุดของการ์ด "เกี่ยวกับ" ในหน้าตั้งค่า (`.about-banner`)
- ต้นฉบับแก้ไขได้ที่ artifact แบนเนอร์ (Banner 2:1) · ถ้าแก้แล้วให้ส่งออกเป็น PNG ทับไฟล์เดิม

# Update 13 — Performance รอบสอง

- `pids()` ไม่วนทุกโปรเซสในเครื่องอีก: ใช้ `psutil.pids()` + อ่านชื่อเฉพาะ PID ใหม่ · ตรวจชื่อ PID ที่เป็น Roblox ซ้ำกัน PID reuse · สแกนเต็มทุก 10 วิ · `wait_new_pid` สแกนเต็มทุก ~3 วิ (เดิมเรียกทุก 0.5 วิ)
- `save_accounts()` แบบ debounce 0.4 วิ (รวมการเรียกติดกัน) + เซฟตอนปิดแอปผ่าน `flush_pending` · `_prefetch_avatars` เซฟครั้งเดียวหลังดึงครบ (เดิมเขียนไฟล์ต่อบัญชี)
- `state()`: `jobs` / `done` รวมใน `acc_sig` เดียวกับบัญชี → ไม่เปลี่ยนก็ไม่ส่ง
- UI: poll ที่ไม่มีอะไรเปลี่ยน (บัญชี/คิว/log/settings/ธงสถานะ) ข้าม `render()` และ sort ทั้งรอบ (หน้าคิวยัง render ทุกรอบเพราะมีตัวนับถอยหลัง)
- CSS: `content-visibility: auto` ที่แถวบัญชี (ข้าม layout/paint แถวนอกจอ)
- api.lua: heartbeat เริ่มแบบสุ่มหน่วง 0–3 วิ + ถอยห่างสูงสุด +10 วิ เมื่อ launcher ไม่ตอบ (ยังต่ำกว่า BEAT_LOST 25 วิ)
- ทดสอบด้วย mock: pids cache (steady/ใหม่/reuse/หายไป/สแกนเต็ม), state delta 5 กรณี, UI ไม่มี error · ยังไม่ได้วัดบน Windows จริง

# Update 12 — Roblox ตกค้างเหลือสวิตช์เดียว · ลดงานเบื้องหลัง (ลดอาการกระตุกเป็นจังหวะ)

**UX: การ์ด "Roblox ที่ตกค้าง"**
- เหลือสวิตช์เดียว `auto_clean` (ปิด Roblox ที่ค้างหน้า Home / ย่ออยู่ / ไม่ผูกบัญชี อัตโนมัติ) แทน 4 ตัวเลือก + ปุ่ม Kill Now + ปุ่มดู Instances
- ค่าที่เคยปรับได้กลายเป็นค่าคงที่: สแกนทุก 5 วิ, ค้าง Home ระหว่างโหลดได้ 60 วิ, ยืนยัน Home 2 วิ
- settings schema 5: ย้ายค่าเดิมอัตโนมัติ (เปิด ถ้าตัวใดตัวหนึ่งเคยเปิด) และลบ key เก่า
- บัญชีที่กำลังเล่นไม่ถูกแตะ · orphan ที่แอปเปิดเองยังถูกปิดแม้ปิดสวิตช์ (เหมือนเดิม)

**Performance**
- `_sweep`: EnumWindows รอบเดียวต่อสแกน (`roblox.window_snapshot`) แทนเรียกแยกต่อ PID สองครั้ง · และ **ข้ามทั้งหมดเมื่อทุกบัญชีมี heartbeat ปกติ** (ทดสอบด้วย mock: 0 ครั้ง)
- `state()`: แคช crc ของ settings (คำนวณใหม่เมื่อ save หรือทุก 3 วิ) · ไม่ส่งรายการบัญชีซ้ำถ้าไม่เปลี่ยน (`acc_sig`) · cpu/ram ปัดเป็นจำนวนเต็ม
- poll ช้าลงเป็น 2 วิ ที่หน้าตั้งค่า/คิว
- `arrange`: ข้ามหน้าต่างที่อยู่ตำแหน่ง/ขนาดถูกแล้ว (ไม่ SetWindowPos ซ้ำ) → เปิดหลายบัญชีติดกันแล้วหน้าต่างเดิมไม่กระตุก
- ไม่ได้แก้: `pids()` ยังวนดูโปรเซสทั้งเครื่อง (ต้องใช้หา Roblox ที่ผู้ใช้เปิดเอง) · ยังไม่ได้วัดบน Windows จริง

# Update 11 — Grid เดียว · dropdown/color picker · เลือกบัญชี · modal แท็บ

**จัดหน้าต่าง → กลายเป็นการตั้งค่า**
- ลบหน้า "จัดหน้าต่าง" (dock เหลือ 5 หน้า, ปุ่มลัด 1–5) · เหลือโหมด grid โหมดเดียว (ลบ cascade/stack/minimize)
- **ตั้งค่า → หน้าต่าง Roblox**: ตัวเลือกตารางแบบกดบน grid 10×10 (กำหนดเองได้ถึง 40), ขนาดช่อง (dropdown: 160×120 … 640×480 + กำหนดเอง), จัดอัตโนมัติ, จัดเดี๋ยวนี้
- **บัญชีแรกอยู่มุมซ้ายบนเสมอ** แล้วเรียงซ้าย→ขวา, บน→ล่าง ตามลำดับในหน้าบัญชี (`core/system.py: arrange`) · ตารางใหญ่เกินจอ = ย่อช่องตามสัดส่วน · เกินจำนวนช่อง = วนกลับช่องแรกแล้วเหลื่อมทแยง
- config schema 4: `grid_cols/grid_rows/cell_w/cell_h` (ค่าเริ่มต้น 8×6, 200×150) · key `layout` ถูกลบอัตโนมัติ

**Style**
- `DD` dropdown กลาง (แทน `<select>` ที่แต่งไม่ได้) — ใช้ที่คอนโซล (กรอง tag, มีช่องค้นหา) และขนาดช่อง · คีย์บอร์ด ↑↓ Enter Esc
- `ColorPicker` แทน `<input type=color>` — พื้นที่ S/V + Hue + HEX + ปิเปต · ปุ่ม "กำหนดเอง" ในธีมสี
- แก้บั๊ก: ป้าย "ยังไม่ตั้งแมพ" ใช้ class `.empty` ชนกับ empty-state จนกลายเป็นกล่องใหญ่ → เปลี่ยนเป็น `.chip.none`

**เลือกบัญชี**: ปุ่ม "เลือก" เปิดโหมดเลือก · วงกลมเลือกซ้ายแถว (hover ที่ avatar ก็เลือกได้) · คลิกแถวเพื่อเลือก, Shift+คลิก = ช่วง, Ctrl+A, Esc · "เลือกตาม…" (ว่าง/ในเกม/ต้องดูแล/ฟาร์ม/ปกติ/กลับด้าน) · แถบเครื่องมือลอยล่างจอ (`#selbar`) · เลือกแล้วไม่ rebuild รายการ

**อื่น ๆ**: เลือกแมพ — map card ใช้ token ธีม + หน้า picker ของ Roblox ใส่สีตาม accent แบบ flat (ปุ่ม "ใช้แมพนี้" คำนวณสีตัวอักษรอัตโนมัติ) · Overlay แจ้งเตือนเป็นสไตล์ Windows toast (หัวแอป · เวลา · ปุ่มปิดตอน hover · รูปพร้อมไอคอนสถานะ) · modal แก้ไขบัญชีสูงคงที่ แบ่งแท็บ เกม / การทำงาน / Script, ปุ่มลบย้ายไปท้าย modal

ทดสอบด้วย headless Chromium + mock backend (ไม่มี error) · ส่วน Win32 (วางหน้าต่างจริง) ต้องลองบน Windows

# Update 10 — Design system เดียวทั้งแอป

**แก้บั๊ก**
- เลือกสีธีมแล้วปุ่มที่เลือกไม่ขึ้นทันที ต้องออก-เข้าหน้าตั้งค่าใหม่ — สาเหตุ: ปุ่มสีเรียก `render()` แต่หน้าตั้งค่าใช้แคช key เดิมเลยไม่วาดซ้ำ
  ตอนนี้ทุกทางเข้า (swatch / color picker / ช่อง hex / คืนค่าเริ่มต้น) ผ่าน `setAccent()` → `applyAccent()` ซึ่งอัปเดตทั้งสีและสถานะ "เลือกอยู่" ทันที (`02-ui-kit`)

**ฟอนต์** — Noto Sans Thai (UI) + JetBrains Mono (ตัวเลข/ID/เวลา/log) ตามภาพอ้างอิง · GRID 8px · RADII 6/10/14 · ACCENT #9D7BFF
(`ui/fonts/` เปลี่ยนจาก IBM Plex เป็น Noto Sans Thai, overlay.html ก็ใช้ฟอนต์ใหม่)

**Redesign ให้ทุกหน้าเป็นภาษาเดียวกัน**
- `app.css` 4,895 → ~650 บรรทัด (เดิมซ้อน override 20+ ชั้น) · `app.js` 4,038 → ~3,090 บรรทัด
- ส่วนประกอบกลาง (ดูหัวไฟล์ `app.css` และ `02c-kit.js`): `.ph` หัวหน้า · `.stats` การ์ดตัวเลข · `.card` · `.row` แถวรายการ · `.fr` แถวตั้งค่า ·
  `.btn/.ibtn` · `.chip/.badge` · `.seg` · `.dialog` · `.empty`
- **หน้าหลักกับหน้าบัญชีใช้แถวเดียวกัน** (`06a-account-row.js`: compact / full) · คิว, ประวัติ, อินสแตนซ์ใช้ `.row` เดียวกัน
- ปุ่มทุกปุ่มใช้ `data-act="ชื่อ"` แล้วไปลงที่ `ACT` ใน `12-render-actions.js` ที่เดียว (ไม่มี bind ซ้ำทุกครั้งที่ patch)
- ลบ: ชั้น CSS ซ้อน, `16-nextgen.js` (รวมเข้า `renderDock`), `mapChipHtml/resChipsHtml` ที่ประกาศซ้ำ, `patchChipsForPlace` (โค้ดตาย)
- ธีมสี: เหลือสีหลักสีเดียว (flat ตาม design) — สีรอง/gradient เดิมถูกคำนวณให้เองเพื่อให้ overlay/หน้าเลือกเกมยังใช้ได้

# Fix pass — icons / tooltip / layout / vendor

- **Icon + tooltip ไม่ขึ้น:** `vendor.js` ใช้ `tippy-bundle.umd` ที่ *ไม่รวม Popper* → throw ตอนโหลด → Lucide ที่ตามหลังไม่ถูกรัน (`window.lucide` ไม่มี) ทั้งไอคอนและ tooltip พังพร้อมกัน
  แก้: เอา Tippy ออก เขียน tooltip เอง (`.p4-tip` ใน app.js/app.css, สกินเดิม, ใช้ `data-tip` เหมือนเดิม)
- **แก้ loop ไม่รู้จบของไอคอน:** `lucide.createIcons()` ทิ้ง `data-lucide` ไว้บน `<svg>` + MutationObserver → เรียกซ้ำจนหน้าค้าง (ไม่เคยโดนเพราะ lucide ไม่เคยโหลดได้) ตอนนี้สร้าง svg เองจาก `lucide.icons`
- **Layout default = grid ชิดขอบ:** ไม่มีช่องว่าง, ช่อง ≈ 4:3 (6 หน้าต่าง = 3x2), แถวสุดท้ายที่ไม่เต็มยืดเต็มความกว้าง; preview ในหน้า "จัดหน้าต่าง" ตรงกับของจริง; settings เก่า (schema<3) ถูกรีเซ็ตเป็น grid
- **Import แทนดาวน์โหลด:** `vendor.js` (GSAP+Lucide) แนบในโปรเจกต์แล้ว `run.bat` ไม่โหลดอะไรจากเน็ตอีก (`tools/fetch_vendor.py` เหลือไว้เป็นทางเลือกสร้างใหม่)

# P4NG Launcher — UI & performance pass

## Performance
- **Dashboard no longer re-renders every second.** The view key included each account's CPU/RAM, so any change
  rebuilt the whole dashboard with `innerHTML` (flicker, lost hover/tooltips, rebinding all handlers).
  CPU/RAM are now updated in place by the existing `patch()`. (`06-view-dash.js`)
- **Sidebar status no longer rebuilds every second.** Uptime was part of its cache key; now only that one text node updates. (`12-render-actions.js`)
- **Adaptive polling.** 1 s while accounts/queue are active (or on Console), 2.5 s when everything is idle, 4 s when the window is hidden. (`05-state.js`)
- **Infinite animations pause while the window is hidden/minimised** (`html.is-hidden`).
- **CSS: 21 files + 1 broken link → 1 minified file** (203 KB → ~142 KB). `index.html` referenced `css/98-table.css`, which doesn't exist (404 on every start).
- `content-visibility` / `contain` on list rows and cards so off-screen rows skip layout and paint; `backdrop-filter` is off on closed overlays.

## UI
- Visible keyboard focus ring (there was none).
- Thin custom scrollbars instead of fully hidden ones, so scrollable areas are discoverable.
- Tabular numerals so CPU/RAM/uptime digits don't jitter; desktop-style text selection (only in inputs, mono/log text).
- Clearer disabled buttons.

## Build step
CSS sources stay in `ui/css/`. After editing any of them run:

    python tools/build_css.py

(order is defined in that script; `104-polish.css` is the new last layer before `tw.css`).

## Not changed / worth a look
- `ui/js/08-accounts-drag.js` is never loaded by `index.html` and `bindAccDrag()` is never called — drag-to-reorder is dead code.
- `core/vault.py`: the vault key is derived from a hard-coded password (`AUTO_PW`), so `vault.enc` only protects against casual
  reading. Consider Windows DPAPI (`win32crypt.CryptProtectData`) so cookies are bound to the Windows user.
- Not run here: this is a Windows-only pywebview app, so I could only syntax-check (Python, JS, CSS brace balance), not launch it.

## Update 2
- **Removed the "api.lua → install to autoexec" card** from Settings, its click handler (`11-view-settings.js`) and the
  backend methods `install_script`, `_guess_autoexec`, `_pick_folder` (`main.py`). The heartbeat server and the
  `api.lua` status row in the sidebar are untouched (the launcher still depends on them).
- **Modal position fix.** The first pass added `contain: layout` to `#modal-root`/`#tip` and `content-visibility`/`contain: paint`
  to rows and cards. That turns them into containing blocks for `position: fixed` and clips shadows, which misplaced modals.
  Those rules are gone. Modals are now centred in the area below the 30 px titlebar, capped to the window height
  (including the edit-account modal), and no longer run two competing open animations.

## Update 3
- **👁 "view in game" button did nothing.** `viewInGame()` was called from the dashboard and the accounts list but never
  defined anywhere (ReferenceError). Added `viewInGame()` (`04-helpers.js`) and a backend `view_account(id)` (`main.py`)
  that restores/minimised-or-not and brings that account's Roblox window to the front. It shows a toast if the account
  isn't running or the window is gone.
- **Edit-account modal cards overlapping** (map banner over "FPS/Private server", Delete box over the script textarea).
  `.ae-body` is a height-limited flex column, so every card shrank and its content spilled over the next one. Cards no
  longer shrink; the modal body scrolls instead. (`104-polish.css`)

## Update 4
- Added `ui/api.lua` (the zip never contained it). Implements the protocol in `core/heartbeat.py`: heartbeat, disconnect,
  desc, and Auto-Exec fetch. `/api/script` now also returns `delay` (the "หน่วงก่อนรัน" setting) so the script waits as configured.

## Update 5
**Behaviour**
- **Normal mode:** when the game drops (kick / disconnect / process closed) the account is treated as *closed* — no reconnect,
  `active=False`, queue entries cancelled, state → IDLE. The accounts-page button flips from "exit game" back to "join game"
  (it is driven by `active`). Farm mode still auto-reconnects. (`core/app.py: reconnect`)
- **Roblox Home screen = end task.** "Home" is "not in any place", i.e. no `api.lua` heartbeat (it only reports `placeId` in-game):
  * window not tracked by any account → killed after 2 s of continuous Home (debounce so a launching window isn't hit);
  * `IN_GAME` account silent for > 25 s and showing Home → killed (+ reconnect in farm / close in normal mode) after 2 s;
  * `LAUNCHING/LOADING` (title is also "Roblox" while loading) → `stale_home_secs`, default lowered 60 → 30 s;
  * sweep rescans every 1 s while a Home window is waiting for confirmation (was a fixed 5 s). `api.lua` beats every 10 s.
- **Per-account Auto-Exec script is pre-filled.** `state()` only sends `has_script_override`, so the edit modal always showed an
  empty box; it now loads the saved code with `get_script_for_account`. Shared `codeEditor()` component (settings + modal):
  Lua header, "Custom / ใช้ Global" badge, line/char counter, clear button, Tab = 2 spaces, no ligatures.
- **Font:** code/mono stacks had JetBrains Mono (Latin only) without IBM Plex Sans Thai, so Thai fell back to a system font.
  Added Plex Thai to the stack (`.mono`, `.code`).

**UI**
- **Emoji → SVG icons everywhere** (dash, accounts, queue, layout, console, settings, import modal, toasts, injected map-picker
  buttons, backend log lines). New icons added to `02b-icons.js`; `modeLabel()` helper for farm/normal.
- **Dock bar replaces the left sidebar.** Order: บัญชี · คิว · **หน้าหลัก (always centre, raised)** · จัดหน้าต่าง · คอนโซล.
  Badges for account count / queue / problems, keyboard shortcuts **1–5**. Settings = gear in the titlebar.
  Titlebar now shows live status chips (in-game / opening / errors / queue paused / api.lua / multi-instance — click to jump)
  and a one-click **เริ่มทั้งหมด / หยุดทั้งหมด** that works from every page. Social links + version moved to Settings → เกี่ยวกับ.
- `homeStopAll()` (the dashboard "stop all" button) was never defined — added.

**Dead code removed**
- JS: `08-accounts-drag.js` (never loaded), `crash()`, duplicate `showInstancesModal` (defined twice), `#fab-add` handling, sidebar/NAV_GROUPS code, `S.t0`.
- Python: `fetch_avatar`, `roblox_status`, `sweep_orphans`, `roblox_process_count`, `debug_crash`, `sweep_once`, `search_games`,
  `is_visible_window`, `Vault.rekey`; unused imports; unused config keys (`normal_fps`, `farm_step`, `script_dir`).
- CSS: 577 rules with no remaining user in JS/HTML/Python (`tools/prune_css.py`) — bundle 203 KB → ~94 KB.

**Tooling:** `python tools/prune_css.py` (drop unused rules) then `python tools/build_css.py` (bundle + minify).
Verified in headless Chromium with a mock backend: no JS errors; dock, titlebar, dashboard, edit modal and settings rendered and checked by screenshot.
Not verifiable here (needs Windows + Roblox): process kill / Home detection timing, window focus.

## Update 6
- **Titlebar = app name + version + window buttons only.** Status chips, the start/stop-all button and the settings gear were removed from it.
- **Settings moved into the dock** (ตั้งค่า, with a red "!" badge when api.lua's port or multi-instance isn't ready).
  **เริ่ม / หยุดทั้งหมด** is now the last dock button (still one click from any page; hidden placeholder keeps หน้าหลัก exactly centred).
  Shortcuts are 1–6 in dock order. Mode labels (ฟาร์ม/ปกติ · Auto-Exec) now render on one line.

## Update 7 — Next-gen UI
**Direction:** ink glass + a quiet accent. The accent colour (your Settings → accent) is now reserved for the primary
action and the active item instead of glowing on every border; everything else is neutral glass.

- **Fleet bar (new, dashboard hero).** One segmented bar shows the whole fleet at a glance — ในเกม / กำลังเริ่ม / ว่าง / ผิดพลาด —
  with live counts. Segment widths follow the number of accounts. (`fleetBar()` in `06-view-dash.js`)
- **Dock = floating glass island** with a sliding active pill (spring easing) that follows the page you open;
  neutral blur glass, no pink halo. (`105-dock.css` → `107-nextgen.css`, `js/16-nextgen.js`)
- **Aurora background** replaces the grid mesh: three soft lights tinted by your accent, drifting slowly; paused when the window is hidden.
- **Surfaces:** one consistent ink-glass treatment (bright top edge, softer shadow, smaller radius). `backdrop-filter` removed from
  list rows/cards (account cards, queue jobs) — cheaper to paint with many accounts. Dialogs get real glass.
- **Typography:** removed tracked-out ALL-CAPS labels on the dashboard; larger, tighter hero number.
- **Badges:** the expanding "sonar" ring (stretched and clipped on pill shapes) is replaced by a pulsing status dot.
- **BUG FIX — dashboard account table was broken.** `.dash-monitor / .dash-mon-head / .dash-mon-row / .dash-i-btn` had no layout
  rules left (only decoration survived the CSS prune), so every cell stacked vertically. Added the grid layout; below 860 px
  CPU/RAM columns collapse.
- `prefers-reduced-motion` respected (aurora, sheen, live dot, dock pill).

**Files:** new `ui/css/107-nextgen.css`, `ui/js/16-nextgen.js`; edited `ui/js/06-view-dash.js` (hero markup + `fleetBar`),
`ui/index.html` (one script tag), `tools/build_css.py` (adds the new layer). Run `python tools/build_css.py` after editing CSS —
`app.min.css` is already rebuilt in this zip. Do **not** run `prune_css.py` again without checking: it is what removed the table rules.
Backend (Python) is untouched.

## Update 8 — layout, loading, account page, Hiwdo background
**Bug fixes**
- **"ไม่มี farm ที่ IN_GAME ให้จัด" warning.** Two causes: (1) `main.py: launch()` queued `APPLY_LAYOUT` the moment you pressed start,
  before anyone was in game; (2) `arrange_now()` still filtered on `mode == "farm"`. Now: the pre-launch call is gone; the layout is queued
  after each farm account joins (only if Settings → จัดหน้าต่างอัตโนมัติ is on — that toggle was previously unused); "จัดเดี๋ยวนี้" arranges
  **every** in-game account regardless of mode; the automatic run is silent when nobody is in game. (`core/app.py`, `main.py`)
- Layout mode tabs: active tab was hard-coded purple `#c084fc` and inactive tabs used the dimmest grey → now white-on-accent / readable grey.
- "เหตุการณ์ล่าสุด" header was clipped at the window edge (`.dash-log-head` had no CSS). Log rows now use a fixed 6-column grid so
  #id / time / level / [tag] / message line up on every row.
- Dangling "·" after the mode label in dashboard rows.

**UI**
- **Page titles centred** on every page (บัญชี, คิวงาน, จัดหน้าต่าง, คอนโซล, ตั้งค่า): status on the left, actions on the right (`.ph` grid).
- **Background** back to the Hiwdo look: deep-navy base, 64 px grid mesh, accent glow top/bottom — also used on the loading screen.
- **Loading screen rewritten.** Real step checklist (connect · clean Roblox · vault · data · maps · images · pages), live % that eases to the
  real progress, per-step counts. It now waits for **all** maps (was first 3), preloads every avatar/icon/banner image, loads fonts, and
  builds every page once off-screen before it lets you in. (`js/13-boot.js`, `index.html`, `107-nextgen.css`)
- **Accounts page re-skinned** to match the dashboard: same stat tiles, pill filters, neutral CPU/RAM chips (red only when high), same icon
  buttons (green start / red stop), state-coloured left bar, no pink hover glow.

## Update 9 — calm glass
- **Table headings centred** (dashboard account table); the Status / CPU / RAM / Actions cells are centred under them.
- **More glass, still readable.** Large panels (hero, stat tiles, table, log, settings cards) are now translucent blur glass; list rows
  (account cards, queue jobs) are thin translucent fills without their own blur (cheap with many accounts). Background glows are a bit
  stronger so the glass is visible. Tune `--pane` / `--glass` at the top of `ui/css/108-calm.css`.
- **Dock numbers redesigned.** The grey circle over the icon is gone. Each count is a small solid chip floating at the icon's top-right
  corner: บัญชี = `ในเกม/ทั้งหมด` (green when someone is in game), คิว = job count (accent), หน้าหลัก = errors/bans (red),
  ตั้งค่า = `!` (red). Tooltip via `title`. (`.dk-b` had `data-tip`, and the global `[data-tip]{position:relative}` rule was pulling it out of place.)
- **Hover/active colours follow Settings → accent.** 128 hard-coded pink/purple literals (`#ec4899`, `#f472b6`, `#f43f5e`, `rgb(236 72 153 / …)`,
  `rgb(168 85 247 / …)` …) across 15 CSS files were replaced with `var(--ac / --ac-2 / --ac-3 / --ac-4)` or `color-mix()` of them.
  The `:root` defaults are now the app's default purple (they were pink, which showed until the accent was applied).
- **Toggle**: the round knob is exactly centred (a 1 px border was shifting the box; border removed, knob 16 px in a 40×22 track,
  3 px on every side) and flips instantly with no spring. The ON colour is the accent.
- **Toasts redesigned**: one neutral glass card, small round icon (only the glyph is coloured), 13 px message, quiet grey meta line,
  thin neutral progress line, short fade-in instead of the springy pop.
- Files: new `ui/css/108-calm.css`; edited `ui/js/12-render-actions.js` (dock badge markup), `tools/build_css.py`, 15 CSS files (recolour).
  `app.min.css` is rebuilt. Checked in headless Chromium with a mock backend: no JS errors; dashboard, settings, dock and toasts screenshotted.

## Update 7 — ไลบรารี + หน้าโหลด + รวมไฟล์
**ไลบรารี** (`python tools/fetch_vendor.py` ดาวน์โหลดแล้วรวมเป็น `ui/vendor.js` + `ui/vendor.css`; `run.bat` เรียกให้ครั้งแรก)
- **GSAP** — แถบ %, การเปิดแอปหลังโหลด (เลือนหน้าโหลด + titlebar/การ์ด/dock ไหลเข้า), เปลี่ยนหน้าแบบ stagger, modal สั่น
- **Tippy.js** — tooltip (`data-tip` เหมือนเดิม) แทนโค้ดเดิม ~55 บรรทัด
- **Lucide** — ไอคอนทั้งหมด `ICON.ชื่อ(px)` แทน SVG วาดเอง 40+ ตัว (เพิ่มไอคอน: เพิ่มบรรทัดใน `MAP` ที่ `02b-icons`)
- ลบ ripple, keyframes ที่ซ้ำ, CSS tooltip เดิม

**หน้าโหลด** — `index.html` โหลด `vendor.js` + `app.js` พร้อมแถบความคืบหน้า (0–12%) แล้ว `boot()` ต่อ (12–100%); ไฟล์ไหนโหลดไม่ได้จะแจ้งบนหน้าโหลด

**ลดไฟล์** — `js/*.js` 16 ไฟล์ → `app.js`, `css/*.css` 26 ไฟล์ + tailwind 4 ไฟล์ → `app.css`, ไม่มี build step แล้ว (แก้ `app.css`/`app.js` ตรงได้เลย; ส่วนหัวคอมเมนต์บอกที่มาเดิม). ฟอนต์ตัดน้ำหนัก 300 ที่ไม่ได้ใช้ + รวม `@font-face` เป็น `fonts/fonts.css`
  (ลบ `tools/build_css.py`, `tools/prune_css.py`, `package.json`, `tailwind.config.js`)

**จัดหน้าต่าง (grid)** — เลือกจำนวนคอลัมน์ให้ช่องใกล้ 4:3 และเหลือช่องว่างน้อย แล้วยืดหน้าต่างเต็มช่องเสมอ (6 หน้าต่าง → 3×2 เต็มจอ)
  ค่าเริ่มต้นยังเป็น `grid` — ถ้า `settings.json` เดิมของคุณเก็บ layout อื่นไว้ ให้กดเลือก "grid" ใหม่ในหน้าจัดหน้าต่างหนึ่งครั้ง

## UI/UX maintenance update (2026-10-10)
- Fixed tooltip lifecycle: cancel pending timers, hide immediately when the pointer leaves, avoid showing tips for stale/non-hovered elements, and hide when a hovered element is removed during rerender.
- Styled native dropdowns consistently with the dark theme, including option lists and focus/disabled states (covers the console tag filter).
- Improved toast icon optical centering and refreshed map/place cards to inherit the current accent/theme.
- Refined the notification overlay into a more native-window-like dark panel with a subtle status rail, cleaner hover state, and vertically centered icon.
- Changed grid window placement to use a consistent 200×150 target tile size (bounded by available monitor space), arranged contiguously and centered instead of stretching each Roblox window to fill the monitor cell. Adjust `TILE_W` / `TILE_H` in `core/system.py` to change the target dimensions.
